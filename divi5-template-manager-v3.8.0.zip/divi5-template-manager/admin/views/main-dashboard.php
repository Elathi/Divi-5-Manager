<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php
// Pull all data
$tm          = Divi5_Template_Manager::get_instance();
$current_status = isset( $_GET['status'] ) && sanitize_text_field( $_GET['status'] ) === 'trash' ? 'trash' : array( 'publish', 'draft', 'private', 'pending' );

$layouts_arr = $tm->layout_manager->get_layouts( array(
    'post_status' => $current_status
) );
$total       = count( $layouts_arr );
$hide_empty_cats = get_option( 'd5tm_hide_empty_cats', 'off' ) === 'on';

// Efficient batch term counting — single SQL query instead of N+1
$d5tm_count_cache_key = 'd5tm_sidebar_counts_' . ($current_status === 'trash' ? 'trash' : 'active');
$d5tm_term_counts = get_transient( $d5tm_count_cache_key );

if ( false === $d5tm_term_counts ) {
    global $wpdb;
    $d5tm_statuses_sql = $current_status === 'trash' ? "'trash'" : "'publish','draft','private','pending'";
    $d5tm_term_counts = $wpdb->get_results( "
        SELECT t.term_id, tt.taxonomy, COUNT(DISTINCT p.ID) as cnt
        FROM {$wpdb->terms} t
        INNER JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id
        INNER JOIN {$wpdb->term_relationships} tr ON tt.term_taxonomy_id = tr.term_taxonomy_id
        INNER JOIN {$wpdb->posts} p ON tr.object_id = p.ID
        WHERE p.post_type = 'et_pb_layout'
        AND p.post_status IN ($d5tm_statuses_sql)
        AND tt.taxonomy IN ('layout_category', 'layout_tag')
        GROUP BY t.term_id, tt.taxonomy
    " );
    set_transient( $d5tm_count_cache_key, $d5tm_term_counts, HOUR_IN_SECONDS );
}

// Build lookup maps: term_id => count
$d5tm_cat_count_map = array();
$d5tm_tag_count_map = array();
if ( ! empty( $d5tm_term_counts ) ) {
    foreach ( $d5tm_term_counts as $row ) {
        if ( $row->taxonomy === 'layout_category' ) {
            $d5tm_cat_count_map[ $row->term_id ] = (int) $row->cnt;
        } elseif ( $row->taxonomy === 'layout_tag' ) {
            $d5tm_tag_count_map[ $row->term_id ] = (int) $row->cnt;
        }
    }
}

// Fetch all categories
$categories_raw = get_terms( array(
    'taxonomy'   => 'layout_category',
    'hide_empty' => false,
    'orderby'    => 'name',
    'order'      => 'ASC',
) );

$categories = array();
if ( ! is_wp_error( $categories_raw ) && ! empty( $categories_raw ) ) {
    foreach ( $categories_raw as $cat ) {
        $cat->count = isset( $d5tm_cat_count_map[ $cat->term_id ] ) ? $d5tm_cat_count_map[ $cat->term_id ] : 0;
        if ( ! $hide_empty_cats || $cat->count > 0 ) {
            $categories[] = $cat;
        }
    }
}

// Fetch all tags
$layout_tags_raw = get_terms( array(
    'taxonomy'   => 'layout_tag',
    'hide_empty' => false,
    'orderby'    => 'name',
    'order'      => 'ASC',
) );

$layout_tags = array();
$tag_counts  = array();
if ( ! is_wp_error( $layout_tags_raw ) && ! empty( $layout_tags_raw ) ) {
    foreach ( $layout_tags_raw as $ltag ) {
        $tag_count = isset( $d5tm_tag_count_map[ $ltag->term_id ] ) ? $d5tm_tag_count_map[ $ltag->term_id ] : 0;
        if ( ! $hide_empty_cats || $tag_count > 0 ) {
            $ltag->count = $tag_count;
            $layout_tags[] = $ltag;
            $tag_counts[ $ltag->term_id ] = $tag_count;
        }
    }
}

// Fetch all types
$layout_types = get_terms( array(
    'taxonomy'   => 'layout_type',
    'hide_empty' => false,
    'orderby'    => 'name',
    'order'      => 'ASC',
) );

/**
 * Helper: Auto-assign colors to terms if missing
 */
if ( ! function_exists( 'd5tm_ensure_term_color' ) ) {
    function d5tm_ensure_term_color( $term ) {
        if ( ! $term ) return '#6366f1';
        $color = get_term_meta( $term->term_id, 'd5tm_color', true );
        if ( ! $color ) {
            $palette = array(
                '#6366f1', '#ec4899', '#f43f5e', '#f59e0b', '#10b981', '#06b6d4', '#3b82f6', '#8b5cf6',
                '#64748b', '#ef4444', '#f97316', '#84cc16', '#22c55e', '#14b8a6', '#0ea5e9', '#a855f7'
            );
            $color = $palette[ $term->term_id % count( $palette ) ];
            update_term_meta( $term->term_id, 'd5tm_color', $color );
        }
        return $color;
    }
}

// Ensure all categories have colors
if ( ! is_wp_error( $categories ) ) {
    foreach ( $categories as $cat ) { d5tm_ensure_term_color( $cat ); }
}
if ( ! is_wp_error( $layout_tags ) ) {
    foreach ( $layout_tags as $ltag ) { d5tm_ensure_term_color( $ltag ); }
}

// Fetch visibility settings
$show_builder      = get_option( 'd5tm_show_action_builder', 'on' ) === 'on';
$show_download     = get_option( 'd5tm_show_action_download', 'on' ) === 'on';
$show_quick_edit   = get_option( 'd5tm_show_action_quick_edit', 'on' ) === 'on';
$show_trash        = get_option( 'd5tm_show_action_trash', 'on' ) === 'on';
$tag_branding      = get_option( 'd5tm_tag_branding', 'on' ) === 'on';
$skeleton_branding = get_option( 'd5tm_skeleton_branding', 'off' ) === 'on';
?>

<div class="d5tm-wrap">
<div class="d5tm-app">

    <!-- ===== TOP HEADER ===== -->
    <header class="d5tm-header">
        <div class="d5tm-logo">
            <div class="d5tm-logo-icon">
                <i class="bi bi-grid-fill"></i>
            </div>
            Divi 5 Manager
        </div>

        <nav class="d5tm-header-tabs">
            <button class="d5tm-htab active" data-target="browse-tab" data-tooltip="<?php esc_attr_e( 'View and filter your library', 'divi5-tm' ); ?>"><i class="bi bi-collection"></i> <?php esc_html_e( 'Browse', 'divi5-tm' ); ?></button>

            <button class="d5tm-htab" data-target="import-tab" data-tooltip="<?php esc_attr_e( 'Upload and categorize Divi JSON files', 'divi5-tm' ); ?>"><i class="bi bi-cloud-upload"></i> <?php esc_html_e( 'Import', 'divi5-tm' ); ?></button>
            <button class="d5tm-htab" data-target="stats-tab" data-tooltip="<?php esc_attr_e( 'View layout statistics and analytics', 'divi5-tm' ); ?>">
                <i class="bi bi-bar-chart-line"></i>
                <?php esc_html_e( 'Stats', 'divi5-tm' ); ?>
            </button>
            <button class="d5tm-htab" data-target="settings-tab" data-tooltip="<?php esc_attr_e( 'Configure plugin preferences', 'divi5-tm' ); ?>">
                <i class="bi bi-sliders"></i>
                <?php esc_html_e( 'Settings', 'divi5-tm' ); ?>
            </button>
            <button class="d5tm-htab" data-target="changelog-tab" data-tooltip="<?php esc_attr_e( 'View latest version updates', 'divi5-tm' ); ?>">
                <i class="bi bi-clock-history"></i>
            </button>
        </nav>

        <div style="margin-left: auto; display: flex; align-items: center; gap: 15px;">
            <button class="d5tm-mobile-menu-btn" id="d5tm-mobile-menu-toggle" data-tooltip="<?php esc_attr_e( 'Toggle Sidebar', 'divi5-tm' ); ?>">
                <i class="bi bi-list"></i>
            </button>
            <button class="d5tm-help-btn" id="d5tm-help-trigger" data-tooltip="<?php esc_attr_e( 'Feature Guide & Help', 'divi5-tm' ); ?>">
                <i class="bi bi-question-circle"></i>
            </button>
            <button class="d5tm-theme-toggle" id="d5tm-theme-toggle" data-tooltip="<?php esc_attr_e( 'Toggle Light/Dark Mode', 'divi5-tm' ); ?>">
                <i class="bi bi-sun" id="d5tm-theme-icon"></i>
            </button>
            <span class="d5tm-header-count" data-tooltip="<?php esc_attr_e( 'Number of items in the current view', 'divi5-tm' ); ?>"><?php echo esc_html( $total ); ?> layouts</span>
        </div>
    </header>

    <!-- ===== BROWSE TAB ===== -->
    <div id="browse-tab" class="d5tm-tab active">
        <div class="d5tm-body">

            <!-- Sidebar -->
            <aside class="d5tm-sidebar" id="d5tm-sidebar">
                <div class="d5tm-sidebar-search">
                    <i class="bi bi-search"></i>
                    <input type="text" id="d5tm-sidebar-search-input" placeholder="Filter sidebar...">
                </div>
                <div class="d5tm-sidebar-section">
                    <div class="d5tm-sidebar-label" data-tooltip="<?php esc_attr_e( 'Main library navigation', 'divi5-tm' ); ?>">Browse</div>
                    <button class="d5tm-sidebar-link active" data-filter-type="cat" data-filter-val="all" data-tooltip="<?php esc_attr_e( 'Show all layouts and templates', 'divi5-tm' ); ?>">
                        <i class="bi bi-grid-fill"></i>
                        All Layouts
                        <span class="d5tm-sidebar-count"><?php echo esc_html( $total ); ?></span>
                    </button>
                    <?php
                    // Count favorites
                    $fav_count = 0;
                    foreach ( $layouts_arr as $fav_layout ) {
                        if ( get_post_meta( $fav_layout->ID, 'd5tm_favorite', true ) === '1' ) {
                            $fav_count++;
                        }
                    }
                    ?>
                    <button class="d5tm-sidebar-link d5tm-sidebar-fav-link" data-filter-type="fav" data-filter-val="fav" data-tooltip="<?php esc_attr_e( 'Show only favorited layouts', 'divi5-tm' ); ?>">
                        <i class="bi bi-star-fill"></i>
                        Favorites
                        <span class="d5tm-sidebar-count"><?php echo esc_html( $fav_count ); ?></span>
                    </button>
                </div>

                <?php if ( ! is_wp_error( $categories ) && ! empty( $categories ) ) : ?>
                <hr class="d5tm-sidebar-divider">
                <div class="d5tm-sidebar-section">
                    <div class="d5tm-sidebar-label" data-tooltip="<?php esc_attr_e( 'Filter by layout category', 'divi5-tm' ); ?>">Categories</div>
                    <?php foreach ( $categories as $cat ) : 
                        $cat_color = get_term_meta( $cat->term_id, 'd5tm_color', true );
                    ?>
                        <div class="d5tm-sidebar-item-wrap">
                            <button class="d5tm-sidebar-link" data-filter-type="cat" data-filter-val="<?php echo esc_attr( $cat->slug ); ?>">
                                <i class="bi bi-folder" style="color: <?php echo esc_attr( $skeleton_branding ? $cat_color : '#cbd5e1' ); ?>;"></i>
                                <?php echo esc_html( $cat->name ); ?>
                                <span class="d5tm-sidebar-count"><?php echo esc_html( $cat->count ); ?></span>
                            </button>
                            <?php if ( $skeleton_branding ) : ?>
                                <input type="color" class="d5tm-term-color-picker" 
                                       value="<?php echo esc_attr( $cat_color ); ?>" 
                                       data-term-id="<?php echo esc_attr( $cat->term_id ); ?>"
                                       data-tooltip="<?php esc_attr_e( 'Change Category Color', 'divi5-tm' ); ?>">
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if ( ! is_wp_error( $layout_types ) && ! empty( $layout_types ) ) : ?>
                <hr class="d5tm-sidebar-divider">
                <div class="d5tm-sidebar-section">
                    <div class="d5tm-sidebar-label" data-tooltip="<?php esc_attr_e( 'Filter by layout type', 'divi5-tm' ); ?>">Types</div>
                    <?php foreach ( $layout_types as $ltype ) : ?>
                        <div class="d5tm-sidebar-item-wrap">
                            <button class="d5tm-sidebar-link" data-filter-type="type" data-filter-val="<?php echo esc_attr( $ltype->slug ); ?>">
                                <i class="bi <?php echo esc_attr( Divi5_Template_Manager::get_type_icon( $ltype->name ) ); ?>"></i>
                                <?php echo esc_html( $ltype->name ); ?>
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if ( ! is_wp_error( $layout_tags ) && ! empty( $layout_tags ) ) : ?>
                <hr class="d5tm-sidebar-divider">
                <div class="d5tm-sidebar-section">
                    <div class="d5tm-sidebar-label" data-tooltip="<?php esc_attr_e( 'Filter by layout tags', 'divi5-tm' ); ?>">Tags</div>
                    <?php foreach ( $layout_tags as $ltag ) : 
                        $tag_color = get_term_meta( $ltag->term_id, 'd5tm_color', true );
                    ?>
                        <div class="d5tm-sidebar-item-wrap">
                            <button class="d5tm-sidebar-link" data-filter-type="tag" data-filter-val="<?php echo esc_attr( $ltag->slug ); ?>">
                                <i class="bi bi-tag" style="color: <?php echo esc_attr( $tag_branding ? $tag_color : '#cbd5e1' ); ?>;"></i>
                                <?php echo esc_html( $ltag->name ); ?>
                                <span class="d5tm-sidebar-count"><?php echo esc_html( isset( $tag_counts[ $ltag->term_id ] ) ? $tag_counts[ $ltag->term_id ] : 0 ); ?></span>
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </aside>

            <!-- Main content -->
            <main class="d5tm-main">
                <!-- Toolbar -->
                <div class="d5tm-toolbar">
                    <div class="d5tm-toolbar-tabs">
                        <a href="?page=divi5-template-manager" class="d5tm-tab-btn <?php echo esc_attr( $current_status !== 'trash' ? 'active' : '' ); ?>" data-tooltip="<?php esc_attr_e( 'Browse published layouts', 'divi5-tm' ); ?>">Active</a>
                        <a href="?page=divi5-template-manager&status=trash" class="d5tm-tab-btn <?php echo esc_attr( $current_status === 'trash' ? 'active' : '' ); ?>" data-tooltip="<?php esc_attr_e( 'View items in trash', 'divi5-tm' ); ?>">Trash</a>
                        <button type="button" class="d5tm-tab-btn d5tm-action-refresh" data-tooltip="<?php esc_attr_e( 'Refresh Dashboard', 'divi5-tm' ); ?>" style="padding: 6px 10px; cursor: pointer;">
                            <i class="bi bi-arrow-clockwise"></i>
                        </button>
                        <button type="button" class="d5tm-tab-btn d5tm-action-health-check" data-tooltip="<?php esc_attr_e( 'Run Layout Health Check', 'divi5-tm' ); ?>" style="padding: 6px 10px; cursor: pointer;">
                            <i class="bi bi-heart-pulse"></i>
                        </button>
                    </div>
                    <div class="d5tm-search-box" data-tooltip="<?php esc_attr_e( 'Search by layout title...', 'divi5-tm' ); ?>">
                        <i class="bi bi-search"></i>
                        <input type="text" id="d5tm-search-input" placeholder="Search layouts...">
                    </div>
                    <div class="d5tm-toolbar-filters">
                        <div class="d5tm-view-toggle" data-tooltip="<?php esc_attr_e( 'Switch view mode', 'divi5-tm' ); ?>">
                            <button type="button" class="d5tm-view-btn active" data-view="grid" data-tooltip="<?php esc_attr_e( 'Grid View', 'divi5-tm' ); ?>"><i class="bi bi-grid-3x3-gap"></i></button>
                            <button type="button" class="d5tm-view-btn" data-view="list" data-tooltip="<?php esc_attr_e( 'List View', 'divi5-tm' ); ?>"><i class="bi bi-list-ul"></i></button>
                            <button type="button" class="d5tm-view-btn" data-view="gallery" data-tooltip="<?php esc_attr_e( 'Gallery View', 'divi5-tm' ); ?>"><i class="bi bi-image"></i></button>
                        </div>
                        <select class="d5tm-filter-select" id="d5tm-grid-cols" data-tooltip="<?php esc_attr_e( 'Adjust grid columns', 'divi5-tm' ); ?>">
                            <option value="auto">Auto Grid</option>
                            <option value="1">1 Column</option>
                            <option value="2">2 Columns</option>
                            <option value="3">3 Columns</option>
                            <option value="4">4 Columns</option>
                            <option value="5">5 Columns</option>
                        </select>

                        <select class="d5tm-filter-select" id="d5tm-sort-order" data-tooltip="<?php esc_attr_e( 'Change list order', 'divi5-tm' ); ?>">
                                <option value="name_asc">Sort: A-Z</option>
                                <option value="name_desc">Sort: Z-A</option>
                                <option value="date_desc">Sort: Newest First</option>
                                <option value="date_asc">Sort: Oldest First</option>
                        </select>
                    </div>
                    <div class="d5tm-toolbar-right">
                        <span class="d5tm-result-count" id="d5tm-count-label" style="margin-right: 12px;"><?php echo esc_html( $total ); ?> results</span>
                        <button type="button" class="d5tm-btn d5tm-btn-secondary d5tm-bulk-select-toggle" data-tooltip="<?php esc_attr_e( 'Toggle bulk selection mode', 'divi5-tm' ); ?>">
                            <i class="bi bi-check2-square"></i> Select
                        </button>
                    </div>
                </div>


                <!-- Grid -->
                <div class="d5tm-content-area">
                    <div class="d5tm-grid" id="d5tm-grid">
                        <?php if ( ! empty( $layouts_arr ) ) :
                            foreach ( $layouts_arr as $layout ) :
                                // Meta
                                $layout_cats  = get_the_terms( $layout->ID, 'layout_category' );
                                $layout_tags  = get_the_terms( $layout->ID, 'layout_tag' );
                                $layout_types = get_the_terms( $layout->ID, 'layout_type' );

                                $cat_slugs = $cat_names = $tag_slugs = $tag_names = $type_names = array();

                                if ( $layout_cats && ! is_wp_error( $layout_cats ) ) {
                                    foreach ( $layout_cats as $c ) {
                                        $cat_slugs[] = $c->slug;
                                        $cat_names[] = array( 'name' => $c->name, 'id' => $c->term_id );
                                    }
                                }

                                if ( $layout_tags && ! is_wp_error( $layout_tags ) ) {
                                    foreach ( $layout_tags as $t ) {
                                        $tag_slugs[] = $t->slug;
                                        $tag_names[] = array( 'name' => $t->name, 'id' => $t->term_id );
                                    }
                                }

                                if ( $layout_types && ! is_wp_error( $layout_types ) ) {
                                    foreach ( $layout_types as $ty ) {
                                        $type_names[] = array( 'name' => $ty->name, 'id' => $ty->term_id );
                                    }
                                }

                                $search_terms = array_merge( 
                                    array_column( $cat_names, 'name' ), 
                                    array_column( $tag_names, 'name' ),
                                    array_column( $type_names, 'name' )
                                );
                                $type_slugs = wp_list_pluck( $layout_types ?: array(), 'slug' );
                                $search_data = strtolower( $layout->post_title . ' ' . implode( ' ', $search_terms ) );
                                $cat_data    = implode( ' ', $cat_slugs );
                                $tag_data    = implode( ' ', $tag_slugs );
                                $type_data   = implode( ' ', $type_slugs );
                                $edit_link   = home_url( '/et_pb_layout/' . $layout->post_name . '/?et_fb=1&PageSpeed=off' );
                                $date_str    = get_the_date( 'M j, Y', $layout->ID );
                                
                                // Specific data for quick edit
                                $thumb_id = get_post_thumbnail_id($layout->ID) ?: 0;
                                $thumb_url = $thumb_id ? get_the_post_thumbnail_url($layout->ID, 'large') : '';
                                
                                // Build the preview URL exactly like Divi's own library does:
                                // Manually construct the permalink using post_name (get_permalink() returns false
                                // for non-publicly-queryable post types like et_pb_layout).
                                $preview_base = home_url( '/et_pb_layout/' . $layout->post_name . '/' );
                                $preview_url  = add_query_arg(
                                    array(
                                        'preview_id'    => $layout->ID,
                                        'preview_nonce' => wp_create_nonce( 'post_preview_' . $layout->ID ),
                                        'preview'       => 'true',
                                    ),
                                    $preview_base
                                );
                                ?>
                                <div class="d5tm-card <?php echo ( $current_status === 'trash' ) ? 'is-trashed' : ''; ?>"
                                    data-layout-id="<?php echo esc_attr( $layout->ID ); ?>"
                                    data-title="<?php echo esc_attr( $layout->post_title ); ?>"
                                    data-date="<?php echo esc_attr( strtotime( $layout->post_date ) ); ?>"
                                    data-status="<?php echo esc_attr( $layout->post_status ); ?>"
                                    data-thumbnail-id="<?php echo esc_attr( $thumb_id ); ?>"
                                    data-thumbnail-url="<?php echo esc_url( $thumb_url ); ?>"
                                    data-fav="<?php echo esc_attr( $is_fav ? '1' : '0' ); ?>"
                                    data-cats-json='<?php echo esc_attr( wp_json_encode( wp_list_pluck( $cat_names, 'id' ) ) ); ?>'
                                    data-tags-raw="<?php echo esc_attr( implode( ', ', array_column( $tag_names, 'name' ) ) ); ?>"
                                    data-preview-url="<?php echo esc_url( $preview_url ); ?>"
                                    data-search="<?php echo esc_attr( $search_data ); ?>"
                                    data-cats="<?php echo esc_attr( $cat_data ); ?>"
                                    data-tags="<?php echo esc_attr( $tag_data ); ?>"
                                    data-type="<?php echo esc_attr( $type_data ); ?>"
                                    <?php 
                                    $primary_cat = ( ! empty( $layout_cats ) && ! is_wp_error( $layout_cats ) ) ? array_values( $layout_cats )[0] : null;
                                    $brand_color = $primary_cat ? get_term_meta( $primary_cat->term_id, 'd5tm_color', true ) : '#6366f1';
                                    echo 'style="--d5tm-accent: ' . esc_attr( $brand_color ) . ';"';
                                    ?>>

                                    <!-- Selection Checkbox (Batch Editor) -->
                                    <div class="d5tm-card-select">
                                        <input type="checkbox" class="d5tm-card-checkbox" value="<?php echo esc_attr( $layout->ID ); ?>">
                                    </div>

                                    <?php
                                        $d5tm_thumb_mode = get_option( 'd5tm_thumbnail_mode', 'skeleton' );
                                        $d5tm_shimmer    = get_option( 'd5tm_skeleton_shimmer', 'on' );
                                        $has_thumb       = has_post_thumbnail( $layout->ID );
                                        $thumb_class     = ! $has_thumb && $d5tm_thumb_mode === 'skeleton' ? ' d5tm-thumb--skeleton' : '';
                                        
                                        // Explicit boolean check for shimmer
                                        if ( ! $has_thumb && $d5tm_thumb_mode === 'skeleton' && 'on' === $d5tm_shimmer ) {
                                            $thumb_class .= ' d5tm-shimmer-active';
                                        }
                                    ?>
                                    <div class="d5tm-thumb<?php echo esc_attr( $thumb_class ); ?>">

                                        <?php
                                        // Favorite button — uses post meta d5tm_favorite
                                        $is_fav = get_post_meta( $layout->ID, 'd5tm_favorite', true ) === '1';
                                        ?>
                                        <button type="button" class="d5tm-fav-btn <?php echo $is_fav ? 'is-fav' : ''; ?>" 
                                                data-id="<?php echo esc_attr( $layout->ID ); ?>"
                                                data-tooltip="<?php esc_attr_e( 'Toggle Favorite', 'divi5-tm' ); ?>">
                                            <i class="bi <?php echo $is_fav ? 'bi-star-fill' : 'bi-star'; ?>"></i>
                                        </button>

                                        <?php 
                                        $d5tm_lowq = get_option( 'd5tm_low_quality_preview', 'off' ) === 'on';
                                        $thumb_size = $d5tm_lowq ? 'medium' : 'large';
                                        $thumb_src = get_the_post_thumbnail_url( $layout->ID, $thumb_size );
                                        $full_src  = $d5tm_lowq ? get_the_post_thumbnail_url( $layout->ID, 'large' ) : '';
                                        ?>
                                        <?php if ( $has_thumb ) : ?>
                                            <img class="d5tm-thumb-img<?php echo $d5tm_lowq ? ' d5tm-thumb-lowq' : ''; ?>"
                                                src="<?php echo esc_url( $thumb_src ); ?>"
                                                <?php if ( $d5tm_lowq && $full_src ) : ?>
                                                data-full-src="<?php echo esc_url( $full_src ); ?>"
                                                <?php endif; ?>
                                                alt="<?php echo esc_attr( $layout->post_title ); ?>"
                                                loading="lazy">

                                        <?php elseif ( $d5tm_thumb_mode === 'skeleton' ) : ?>
                                            <!-- Generic skeleton shown by default -->
                                            <div class="d5tm-thumb-skeleton d5tm-skel-static">
                                                <?php echo D5TM_Skeleton_Generator::generate( $layout ); ?>
                                            </div>

                                            <!-- Live scrolling preview â€” injected by JS on card hover -->
                                            <div class="d5tm-thumb-live-wrap" aria-hidden="true">
                                                <!-- JS inserts <iframe> here on hover -->
                                            </div>

                                        <?php else : ?>
                                            <div class="d5tm-thumb-empty">
                                                <span class="dashicons dashicons-format-image"></span>
                                                <span>No preview</span>
                                            </div>
                                        <?php endif; ?>
                                        <!-- Hover Overlay: Centered Eye Only -->
                                        <div class="d5tm-thumb-overlay">
                                            <button type="button" class="d5tm-preview-overlay-btn d5tm-action-live-preview" data-id="<?php echo esc_attr( $layout->ID ); ?>" data-tooltip="<?php esc_attr_e( 'Quick Preview', 'divi5-tm' ); ?>">
                                                <i class="bi bi-eye"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Card Body -->
                                    <div class="d5tm-card-body">
                                        <div class="d5tm-card-title-row">
                                            <div class="d5tm-card-name" data-tooltip="<?php echo esc_attr( $layout->post_title ); ?>">
                                                <?php echo esc_html( $layout->post_title ); ?>
                                            </div>
                                            <div class="d5tm-card-footer-actions">

                                                <button type="button" class="d5tm-footer-icon d5tm-design-extract-btn" data-id="<?php echo esc_attr( $layout->ID ); ?>" data-tooltip="<?php esc_attr_e( 'Design Extract', 'divi5-tm' ); ?>">
                                                    <i class="bi bi-palette"></i>
                                                </button>

                                                <button type="button" class="d5tm-footer-icon d5tm-json-btn" data-id="<?php echo esc_attr( $layout->ID ); ?>" data-tooltip="<?php esc_attr_e( 'View JSON Structure', 'divi5-tm' ); ?>">
                                                    <i class="bi bi-code-slash"></i>
                                                </button>
                                                
                                                <?php if ( $current_status === 'trash' ) : ?>
                                                    <button type="button" class="d5tm-footer-icon d5tm-action-restore" data-tooltip="<?php esc_attr_e( 'Restore', 'divi5-tm' ); ?>">
                                                        <i class="bi bi-arrow-counterclockwise"></i>
                                                    </button>
                                                    <button type="button" class="d5tm-footer-icon d5tm-action-delete" style="color:#ef4444;" data-tooltip="<?php esc_attr_e( 'Delete Permanently', 'divi5-tm' ); ?>">
                                                        <i class="bi bi-trash3"></i>
                                                    </button>
                                                <?php else : ?>
                                                    <?php if ( $show_download ) : ?>
                                                        <button type="button" class="d5tm-footer-icon d5tm-download-btn d5tm-action-download" data-id="<?php echo esc_attr( $layout->ID ); ?>" data-tooltip="<?php esc_attr_e( 'Download JSON', 'divi5-tm' ); ?>">
                                                            <i class="bi bi-download"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                    <button type="button" class="d5tm-footer-icon d5tm-action-duplicate" data-id="<?php echo esc_attr( $layout->ID ); ?>" data-tooltip="<?php esc_attr_e( 'Duplicate Layout', 'divi5-tm' ); ?>">
                                                        <i class="bi bi-copy"></i>
                                                    </button>
                                                    <?php if ( $show_quick_edit ) : ?>
                                                        <button type="button" class="d5tm-footer-icon d5tm-action-quick-edit" data-id="<?php echo esc_attr( $layout->ID ); ?>" data-tooltip="<?php esc_attr_e( 'Quick Edit Labels', 'divi5-tm' ); ?>">
                                                            <i class="bi bi-pencil-square"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                    <?php if ( $show_trash ) : ?>
                                                        <button type="button" class="d5tm-footer-icon d5tm-action-trash" style="color:#ef4444;" data-id="<?php echo esc_attr( $layout->ID ); ?>" data-tooltip="<?php esc_attr_e( 'Move to Trash', 'divi5-tm' ); ?>">
                                                            <i class="bi bi-trash3"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div><!-- /.d5tm-card-title-row -->

                                        <!-- Date & Size -->
                                        <div class="d5tm-card-date" style="display: flex; align-items: center; gap: 8px;">
                                            <?php echo esc_html( $date_str ); ?>
                                            <span class="d5tm-size-indicator" data-tooltip="<?php esc_attr_e( 'Approximate layout size', 'divi5-tm' ); ?>">
                                                <i class="bi bi-hdd"></i>
                                                <?php echo esc_html( size_format( strlen( $layout->post_content ), 0 ) ); ?>
                                            </span>
                                        </div>

                                        <!-- Pills Row -->
                                        <div class="d5tm-meta-pills">
                                            <?php if ( ! empty( $cat_names ) ) : ?>
                                                <span class="d5tm-pill d5tm-pill-cat d5tm-clickable-filter" 
                                                      data-filter-type="cat" 
                                                      data-filter-val="<?php echo esc_attr( $cat_slugs[0] ); ?>"
                                                      data-tooltip="<?php echo esc_attr( $cat_names[0]['name'] ); ?>">
                                                    <i class="bi bi-folder"></i> <?php echo esc_html( $cat_names[0]['name'] ); ?>
                                                </span>
                                            <?php endif; ?>

                                            <?php if ( ! empty( $type_names ) ) : 
                                                $type_icon = Divi5_Template_Manager::get_type_icon( $type_names[0]['name'] );
                                            ?>
                                                <span class="d5tm-meta-icon d5tm-type-icon d5tm-clickable-filter" 
                                                      data-filter-type="type" 
                                                      data-filter-val="<?php echo esc_attr( $type_slugs[0] ); ?>"
                                                      data-tooltip="<?php echo esc_attr( $type_names[0]['name'] ); ?>">
                                                    <i class="bi <?php echo esc_attr( $type_icon ); ?>"></i>
                                                </span>
                                            <?php endif; ?>

                                            <?php if ( ! empty( $tag_names ) ) : 
                                                $all_tag_titles = wp_list_pluck( $tag_names, 'name' );
                                                $tag_tooltip = implode( ', ', $all_tag_titles );
                                            ?>
                                                <span class="d5tm-meta-icon d5tm-tag-icon d5tm-clickable-filter" 
                                                      data-filter-type="tag" 
                                                      data-filter-val="<?php echo esc_attr( $tag_slugs[0] ); ?>"
                                                      data-tooltip="<?php echo esc_attr( $tag_tooltip ); ?>">
                                                    <i class="bi bi-tag"></i>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach;
                        else : ?>
                        <div class="d5tm-empty-state">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 160" width="140" style="display:block; margin: 0 auto 20px;">
                                    <rect width="200" height="160" fill="none"/>
                                    <!-- Folder body -->
                                    <rect x="30" y="55" width="140" height="85" rx="8" fill="#e2e7ed"/>
                                    <!-- Folder tab -->
                                    <path d="M30 55 Q30 42 43 42 L82 42 Q90 42 94 50 L108 55Z" fill="#c8d0da"/>
                                    <!-- Dashed lines (empty content) -->
                                    <rect x="55" y="80" width="90" height="8" rx="4" fill="#c8d0da" opacity="0.7"/>
                                    <rect x="65" y="96" width="70" height="6" rx="3" fill="#c8d0da" opacity="0.5"/>
                                    <rect x="75" y="110" width="50" height="6" rx="3" fill="#c8d0da" opacity="0.35"/>
                                </svg>
                                <h3 style="color: var(--text-2); font-size: 1rem; font-weight: 600; margin-bottom: 6px;">Nothing Here</h3>
                                <p style="color: var(--text-3); font-size: 0.85rem;">No layouts match the current filter. Try a different category or search term.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div><!-- /.d5tm-body -->
    </div><!-- /#browse-tab -->

    <!-- Bulk Action Bar Wrapper (Anchored to Content Area) -->
    <div class="d5tm-bulk-bar-wrap" id="d5tm-bulk-bar-wrap">
        <div class="d5tm-bulk-bar">
            <div class="d5tm-bulk-bar-info">
                <span id="d5tm-bulk-count">0</span>
                <?php esc_html_e( 'layouts selected', 'divi5-tm' ); ?>
            </div>
            
            <div class="d5tm-bulk-bar-actions">
                <div class="d5tm-bulk-dropdown-wrap">
                    <button type="button" class="d5tm-btn d5tm-bulk-dropdown-trigger">
                        <i class="bi bi-folder-plus"></i>
                        <?php esc_html_e( 'Assign Category', 'divi5-tm' ); ?>
                        <i class="bi bi-chevron-up"></i>
                    </button>
                    <div class="d5tm-bulk-dropdown">
                        <?php foreach ( $categories as $cat ) : ?>
                            <button type="button" class="d5tm-bulk-assign-cat" data-cat-id="<?php echo esc_attr( $cat->term_id ); ?>">
                                <?php echo esc_html( $cat->name ); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>

                <button type="button" class="d5tm-btn" id="d5tm-bulk-rename">
                    <i class="bi bi-input-cursor-text"></i>
                    <?php esc_html_e( 'Rename', 'divi5-tm' ); ?>
                </button>

                <button type="button" class="d5tm-btn" id="d5tm-bulk-export">
                    <i class="bi bi-file-earmark-arrow-down"></i>
                    <?php esc_html_e( 'Export JSON', 'divi5-tm' ); ?>
                </button>

                <button type="button" class="d5tm-btn d5tm-btn-danger" id="d5tm-bulk-trash">
                    <i class="bi bi-trash3"></i>
                    <?php esc_html_e( 'Trash Selected', 'divi5-tm' ); ?>
                </button>

                <button type="button" class="d5tm-btn d5tm-bulk-cancel" id="d5tm-bulk-cancel">
                    <?php esc_html_e( 'Cancel', 'divi5-tm' ); ?>
                </button>
            </div>
        </div>
    </div>



    <!-- ===== IMPORT TAB ===== -->
    <div id="import-tab" class="d5tm-tab">
        <div id="d5tm-import-tab">
            <div class="d5tm-dropzone" id="d5tm-dropzone">
                <div class="d5tm-drop-icon">
                    <i class="bi bi-cloud-arrow-up"></i>
                </div>
                <h3>Drag & Drop your Divi 5 .json file here</h3>
                <p>Supports exported Divi Library JSON files. You can also upload matching thumbnail images.</p>
                <input type="file" id="d5tm-file-input" accept=".json,.jpg,.jpeg,.png,.webp" multiple style="display:none;">
                <button class="d5tm-upload-btn" id="d5tm-browse-btn">
                    <i class="bi bi-plus"></i>
                    Select File
                </button>
                <!-- File list preview -->
                <div id="d5tm-import-file-list" class="d5tm-import-file-list"></div>
                <!-- Import category pre-assignment -->
                <div id="d5tm-import-options" class="d5tm-import-options" style="display:none;">
                    <label class="d5tm-import-option-label">Assign category on import:</label>
                    <select id="d5tm-import-category" class="d5tm-filter-select">
                        <option value="">No category</option>
                        <?php if ( ! is_wp_error( $categories_raw ) && ! empty( $categories_raw ) ) : ?>
                            <?php foreach ( $categories_raw as $cat ) : ?>
                                <option value="<?php echo esc_attr( $cat->term_id ); ?>"><?php echo esc_html( $cat->name ); ?></option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <!-- Progress bar -->
                <div id="d5tm-import-progress" class="d5tm-import-progress" style="display:none;">
                    <div class="d5tm-progress-bar">
                        <div class="d5tm-progress-fill" id="d5tm-progress-fill"></div>
                    </div>
                    <span class="d5tm-progress-text" id="d5tm-progress-text">0%</span>
                </div>
                <div id="d5tm-upload-status"></div>
            </div>
        </div>
    </div>

    <!-- ===== STATS TAB ===== -->
    <div id="stats-tab" class="d5tm-tab">
        <div class="d5tm-stats-container">
            <div class="d5tm-stats-loading" id="d5tm-stats-loading">
                <i class="bi bi-arrow-repeat d5tm-spin"></i> Loading statistics...
            </div>
            <div id="d5tm-stats-content" style="display:none;">
                <!-- Overview Cards -->
                <div class="d5tm-stats-overview">
                    <div class="d5tm-stat-card">
                        <div class="d5tm-stat-value" id="d5tm-stat-total">0</div>
                        <div class="d5tm-stat-label">Total Layouts</div>
                        <i class="bi bi-layers d5tm-stat-icon"></i>
                    </div>
                    <div class="d5tm-stat-card">
                        <div class="d5tm-stat-value" id="d5tm-stat-published">0</div>
                        <div class="d5tm-stat-label">Published</div>
                        <i class="bi bi-check-circle d5tm-stat-icon" style="color: var(--green);"></i>
                    </div>
                    <div class="d5tm-stat-card">
                        <div class="d5tm-stat-value" id="d5tm-stat-draft">0</div>
                        <div class="d5tm-stat-label">Drafts</div>
                        <i class="bi bi-pencil d5tm-stat-icon" style="color: #f59e0b;"></i>
                    </div>
                    <div class="d5tm-stat-card">
                        <div class="d5tm-stat-value" id="d5tm-stat-trash">0</div>
                        <div class="d5tm-stat-label">In Trash</div>
                        <i class="bi bi-trash3 d5tm-stat-icon" style="color: #ef4444;"></i>
                    </div>
                </div>
                <!-- Category Breakdown -->
                <div class="d5tm-stats-grid">
                    <div class="d5tm-stats-panel">
                        <h3><i class="bi bi-folder"></i> Category Breakdown</h3>
                        <div id="d5tm-stats-categories" class="d5tm-stats-bars"></div>
                    </div>
                    <div class="d5tm-stats-panel">
                        <h3><i class="bi bi-box-seam"></i> Type Distribution</h3>
                        <div id="d5tm-stats-types" class="d5tm-stats-bars"></div>
                    </div>
                </div>
                <!-- Monthly Activity -->
                <div class="d5tm-stats-panel">
                    <h3><i class="bi bi-calendar3"></i> Monthly Activity</h3>
                    <div id="d5tm-stats-monthly" class="d5tm-stats-bars"></div>
                </div>
                <!-- Recent Layouts -->
                <div class="d5tm-stats-panel">
                    <h3><i class="bi bi-clock-history"></i> Recently Added</h3>
                    <div id="d5tm-stats-recent" class="d5tm-stats-recent-list"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== SETTINGS TAB ===== -->
    <div id="settings-tab" class="d5tm-tab">
        <?php include DIVI5_TM_PLUGIN_DIR . 'admin/views/settings-page.php'; ?>
    </div>

    <!-- ===== CHANGELOG TAB ===== -->
    <div id="changelog-tab" class="d5tm-tab">
        <?php include DIVI5_TM_PLUGIN_DIR . 'admin/views/changelog.php'; ?>
    </div>

    <!-- Quick Edit Modal -->
    <div id="d5tm-modal-overlay" class="d5tm-modal-overlay">
        <div class="d5tm-modal" id="d5tm-quick-edit-modal">
            <div class="d5tm-modal-header">
                <h2>Quick Edit Layout</h2>
                <button type="button" class="d5tm-modal-close" id="d5tm-modal-close-btn">&times;</button>
            </div>
            <div class="d5tm-modal-body">
                <form id="d5tm-quick-edit-form">
                    <input type="hidden" id="d5tm-qe-layout-id" name="layout_id" value="">
                    
                    <!-- Left Column: Settings -->
                    <div class="d5tm-qe-settings">
                        <div class="d5tm-form-group">
                            <label for="d5tm-qe-title">Title</label>
                            <input type="text" id="d5tm-qe-title" name="post_title" class="d5tm-input" required>
                        </div>

                        <div class="d5tm-form-group">
                            <label for="d5tm-qe-status">Status</label>
                            <select id="d5tm-qe-status" name="post_status" class="d5tm-input">
                                <option value="publish">Published</option>
                                <option value="draft">Draft</option>
                                <option value="private">Private</option>
                            </select>
                        </div>
                        
                        <div class="d5tm-form-group">
                            <label>Categories</label>
                            <div class="d5tm-qe-checkbox-scroll">
                                <?php
                                $all_cats = get_terms( array( 'taxonomy' => 'layout_category', 'hide_empty' => false ) );
                                if ( ! is_wp_error( $all_cats ) && ! empty( $all_cats ) ) {
                                    foreach ( $all_cats as $cat ) {
                                        echo '<label class="d5tm-checkbox-lbl">';
                                        echo '<input type="checkbox" name="layout_categories[]" value="' . esc_attr( $cat->term_id ) . '"> ';
                                        echo esc_html( $cat->name );
                                        echo '</label>';
                                    }
                                }
                                ?>
                            </div>
                        </div>

                        <div class="d5tm-form-group">
                            <label for="d5tm-qe-tags">Tags (comma separated)</label>
                            <input type="text" id="d5tm-qe-tags" name="layout_tags" class="d5tm-input">
                        </div>
                    </div>

                    <!-- Right Column: Thumbnail -->
                    <div class="d5tm-qe-thumbnail-wrapper">
                        <label>Preview Image</label>
                        <div class="d5tm-qe-thumbnail-box" id="d5tm-qe-thumbnail-box">
                            <input type="hidden" id="d5tm-qe-thumbnail-id" name="thumbnail_id" value="">
                            <img id="d5tm-qe-thumbnail-img" src="" style="display:none; width: 100%; height: 100%; object-fit: cover; border-radius: 4px;" alt="Preview">
                            <div class="d5tm-qe-thumbnail-placeholder" id="d5tm-qe-placeholder" style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; color: var(--text-3); background: var(--bg-2); border-radius: 4px;">
                                <i class="bi bi-image" style="font-size: 2rem; margin-bottom: 8px;"></i>
                                <span>No Preview Image</span>
                            </div>
                        </div>
                        <div class="d5tm-qe-thumbnail-actions">
                            <button type="button" class="d5tm-btn d5tm-btn-primary" id="d5tm-qe-set-thumb">Set Preview</button>
                            <button type="button" class="d5tm-btn d5tm-btn-danger" id="d5tm-qe-remove-thumb">Remove</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="d5tm-modal-footer">
                <span id="d5tm-qe-status-msg" class="d5tm-status-msg"></span>
                <button type="button" class="d5tm-btn d5tm-btn-secondary" id="d5tm-modal-cancel-btn">Cancel</button>
                <button type="button" class="d5tm-btn d5tm-btn-primary" id="d5tm-qe-save-btn">Update</button>
            </div>
        </div>
    </div>

    <!-- Feature Guide Modal -->
    <div id="d5tm-guide-modal" class="d5tm-modal-overlay">
        <div class="d5tm-modal d5tm-guide-modal">
            <div class="d5tm-modal-header">
                <h2><i class="bi bi-info-circle"></i> Feature Guide & Help</h2>
                <button type="button" class="d5tm-modal-close" id="d5tm-guide-close-btn">&times;</button>
            </div>
            <div class="d5tm-modal-body">
                <div class="d5tm-guide-container">
                    
                    <!-- Feature: Browsing -->
                    <div class="d5tm-guide-item">
                        <div class="d5tm-guide-icon"><i class="bi bi-collection"></i></div>
                        <div class="d5tm-guide-text">
                            <h3>Browse & Search</h3>
                            <p>Organize assets with a professional grid. The search bar now includes <strong>instant highlighting</strong>, and you can use <strong>Quick Sort</strong> (A-Z, Newest, etc.) in the toolbar.</p>
                        </div>
                    </div>

                    <!-- Feature: Interactive Tools -->
                    <div class="d5tm-guide-item">
                        <div class="d5tm-guide-icon"><i class="bi bi-keyboard"></i></div>
                        <div class="d5tm-guide-text">
                            <h3>Keyboard & Shortcuts</h3>
                            <p>Press <code>/</code> to focus search, <code>Esc</code> to reset filters. Every card now has a <strong>Copy ID</strong> button and a <strong>Live Preview</strong> full-screen mode.</p>
                        </div>
                    </div>

                    <!-- Feature: Visual Branding -->
                    <div class="d5tm-guide-item">
                        <div class="d5tm-guide-icon"><i class="bi bi-palette"></i></div>
                        <div class="d5tm-guide-text">
                            <h3>Branding & Shimmer</h3>
                            <p>Skeletons now feature a <strong>shimmer animation</strong>. Use the iOS-style toggle in Settings to switch between <strong>Gray Monochrome</strong> and <strong>Category Colors</strong>.</p>
                        </div>
                    </div>

                    <!-- Feature: Management -->
                    <div class="d5tm-guide-item">
                        <div class="d5tm-guide-icon"><i class="bi bi-folder-fill"></i></div>
                        <div class="d5tm-guide-text">
                            <h3>High-Efficiency Cards</h3>
                            <p>Actions like <strong>JSON Inspection, Download, Duplicate, and Trash</strong> are inline with the title for instant access. Each card also shows a <strong>Layout Size Indicator</strong> so you can spot heavy templates at a glance.</p>
                        </div>
                    </div>

                    <!-- Feature: Favorites -->
                    <div class="d5tm-guide-item">
                        <div class="d5tm-guide-icon"><i class="bi bi-star-fill" style="color:#f59e0b;"></i></div>
                        <div class="d5tm-guide-text">
                            <h3>Layout Favorites</h3>
                            <p>Star your most-used layouts with the <strong>favorite button</strong> (top-right corner of each card on hover). Use the <strong>Favorites</strong> link in the sidebar to quickly filter and find your go-to templates.</p>
                        </div>
                    </div>

                    <!-- Feature: Grid Controls -->
                    <div class="d5tm-guide-item">
                        <div class="d5tm-guide-icon"><i class="bi bi-grid-3x3-gap"></i></div>
                        <div class="d5tm-guide-text">
                            <h3>Responsive Grid</h3>
                            <p>Switch between <strong>1 to 5 columns</strong>. Your preference is saved automatically to localStorage, ensuring your layout remains identical across sessions.</p>
                        </div>
                    </div>

                    <!-- Feature: JSON Inspector -->
                    <div class="d5tm-guide-item">
                        <div class="d5tm-guide-icon"><i class="bi bi-code-slash"></i></div>
                        <div class="d5tm-guide-text">
                            <h3>JSON Power Inspector</h3>
                            <p>Click the <strong>code icon</strong> on any card to open the full JSON inspector with a tree view, search filtering, and smart Divi block expansion. The tree view now renders <strong>complete data</strong> including nested block attributes.</p>
                        </div>
                    </div>

                    <!-- Disclaimers -->
                    <div class="d5tm-guide-disclaimer">
                        <h4><i class="bi bi-exclamation-triangle"></i> Important Disclaimers</h4>
                        <ul>
                            <li><strong>Divi 5 Only:</strong> This plugin is built specifically for the Divi 5 modular architecture. Divi 4 layouts may not render correctly.</li>
                            <li><strong>Data Safety:</strong> Always export and backup your layouts before performing major migrations or batch deletions.</li>
                            <li><strong>Performance:</strong> Hover previews are lazy-loaded to keep your WordPress admin fast and light on memory.</li>
                        </ul>
                    </div>

                </div>
            </div>
            <div class="d5tm-modal-footer">
                <div class="d5tm-guide-footer-branding">
                    Built by <a href="https://elathi.xyz" target="_blank">Elathi Digital</a> &bull; <a href="https://divi.elathi.xyz" target="_blank">divi.elathi.xyz</a>
                </div>
                <button type="button" class="d5tm-btn d5tm-btn-primary" id="d5tm-guide-ok-btn">Got it, thanks!</button>
            </div>
        </div>
    </div>



    <!-- Unified JSON Inspector Modal -->
    <div id="d5tm-json-modal" class="d5tm-modal-overlay">
        <div class="d5tm-modal d5tm-modal-lg">
            <div class="d5tm-modal-header">
                <div class="d5tm-modal-header-left">
                    <i class="bi bi-code-square"></i>
                    <h2 id="d5tm-json-title-text">JSON Inspector</h2>
                </div>
                <div class="d5tm-modal-header-right">
                    <button type="button" class="d5tm-modal-close" id="d5tm-json-close-btn">&times;</button>
                </div>
            </div>
            
            <!-- JSON View Mode Tabs -->
            <div class="d5tm-json-view-tabs">
                <button type="button" class="d5tm-json-view-tab active" data-view="tree">
                    <i class="bi bi-diagram-3"></i> Tree
                </button>
                <button type="button" class="d5tm-json-view-tab" data-view="table">
                    <i class="bi bi-table"></i> Table
                </button>
                <button type="button" class="d5tm-json-view-tab" data-view="chart">
                    <i class="bi bi-bar-chart-line"></i> Chart
                </button>
                <button type="button" class="d5tm-json-view-tab" data-view="raw">
                    <i class="bi bi-code"></i> Raw
                </button>
            </div>

            <!-- JSON Toolbar -->
            <div class="d5tm-json-toolbar">
                <div class="d5tm-json-search-wrap">
                    <i class="bi bi-search"></i>
                    <input type="text" id="d5tm-json-search" placeholder="Search keys or values...">
                </div>
                <div class="d5tm-json-controls">
                    <button type="button" class="d5tm-json-ctrl-btn" id="d5tm-json-expand-all" data-tooltip="Expand All">
                        <i class="bi bi-arrows-expand"></i>
                    </button>
                    <button type="button" class="d5tm-json-ctrl-btn" id="d5tm-json-collapse-all" data-tooltip="Collapse All">
                        <i class="bi bi-arrows-collapse"></i>
                    </button>
                    <div class="d5tm-v-divider"></div>
                    <button type="button" class="d5tm-json-ctrl-btn d5tm-json-copy-btn" data-tooltip="Copy Raw JSON">
                        <i class="bi bi-clipboard"></i>
                    </button>
                </div>
            </div>

            <div class="d5tm-modal-body">
                <div id="d5tm-json-tree-container" class="d5tm-json-tree active">
                    <!-- High-Fidelity Tree Injected Here -->
                </div>
                <div id="d5tm-json-table-view" class="d5tm-json-table-view">
                    <!-- Flat key-value table rendered here -->
                </div>
                <div id="d5tm-json-chart-view" class="d5tm-json-chart-view">
                    <!-- Module chart rendered here -->
                </div>
                <div id="d5tm-json-raw-view" class="d5tm-json-raw-view">
                    <!-- Raw JSON with line numbers rendered here -->
                </div>
            </div>
            
            <div class="d5tm-modal-footer">
                <div id="d5tm-json-stats" class="d5tm-json-stats"></div>
                <button type="button" class="d5tm-btn d5tm-btn-primary" id="d5tm-json-ok-btn">Close</button>
            </div>
        </div>
    </div>

    <!-- Design Extract Modal -->
    <div id="d5tm-design-extract-modal" class="d5tm-modal-overlay d5tm-design-extract-modal">
        <div class="d5tm-modal">
            <div class="d5tm-modal-header">
                <div class="d5tm-modal-header-left">
                    <i class="bi bi-palette"></i>
                    <h2>Design Extract</h2>
                </div>
                <div class="d5tm-modal-header-right">
                    <button type="button" class="d5tm-modal-close" id="d5tm-de-close-btn">&times;</button>
                </div>
            </div>
            <div class="d5tm-modal-body" id="d5tm-de-content">
                <!-- Design extract content rendered here by JS -->
            </div>
            <div class="d5tm-modal-footer">
                <span style="font-size:0.82rem;color:var(--text-3);">Click any color swatch to copy its hex value</span>
                <button type="button" class="d5tm-btn d5tm-btn-primary" onclick="document.getElementById('d5tm-design-extract-modal').classList.remove('active');">Close</button>
            </div>
        </div>
    </div>

    <!-- Live Preview Modal -->

    <div id="d5tm-live-preview-modal" class="d5tm-lp-modal-overlay">
        <div class="d5tm-lp-modal">
            <div class="d5tm-lp-header">
                <div class="d5tm-lp-header-left">
                    <i class="bi bi-eye"></i>
                    <span id="d5tm-lp-title">Live Preview</span>
                </div>
                <div class="d5tm-lp-header-center">
                    <button type="button" class="d5tm-lp-device-btn active" data-device="desktop" data-tooltip="<?php esc_attr_e( 'Desktop View', 'divi5-tm' ); ?>">
                        <i class="bi bi-display"></i>
                    </button>
                    <button type="button" class="d5tm-lp-device-btn" data-device="tablet" data-tooltip="<?php esc_attr_e( 'Tablet View', 'divi5-tm' ); ?>">
                        <i class="bi bi-tablet"></i>
                    </button>
                    <button type="button" class="d5tm-lp-device-btn" data-device="mobile" data-tooltip="<?php esc_attr_e( 'Mobile View', 'divi5-tm' ); ?>">
                        <i class="bi bi-phone"></i>
                    </button>
                </div>
                <div class="d5tm-lp-header-right">
                    <button type="button" class="d5tm-lp-close-btn" id="d5tm-lp-close"><i class="bi bi-x-lg"></i></button>
                </div>
            </div>
            <div class="d5tm-lp-body">
                <div class="d5tm-lp-iframe-wrapper desktop">
                    <iframe id="d5tm-lp-iframe" src="" frameborder="0"></iframe>
                    <div class="d5tm-lp-loader">
                        <i class="bi bi-arrow-repeat d5tm-spin"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Toast Notification Container -->
    <div id="d5tm-toast-container" class="d5tm-toast-container"></div>

    <!-- Confirm Dialog -->
    <div id="d5tm-confirm-overlay" class="d5tm-modal-overlay">
        <div class="d5tm-modal" style="width: 420px;">
            <div class="d5tm-modal-header">
                <h2 id="d5tm-confirm-title"><i class="bi bi-exclamation-triangle"></i> Confirm Action</h2>
            </div>
            <div class="d5tm-modal-body">
                <p id="d5tm-confirm-message" style="color: var(--text-2); line-height: 1.6;"></p>
            </div>
            <div class="d5tm-modal-footer">
                <button type="button" class="d5tm-btn d5tm-btn-secondary" id="d5tm-confirm-cancel">Cancel</button>
                <button type="button" class="d5tm-btn d5tm-btn-danger" id="d5tm-confirm-ok">Confirm</button>
            </div>
        </div>
    </div>

    <!-- Health Check Modal -->
    <div class="d5tm-modal-overlay" id="d5tm-health-overlay">
        <div class="d5tm-modal" style="width:560px;">
            <div class="d5tm-modal-header">
                <h2><i class="bi bi-heart-pulse"></i> Layout Health Check</h2>
                <button type="button" class="d5tm-modal-close" id="d5tm-health-close">&times;</button>
            </div>
            <div class="d5tm-modal-body">
                <div id="d5tm-health-loading" style="text-align:center;padding:40px 0;">
                    <i class="bi bi-arrow-repeat d5tm-spin" style="font-size:24px;color:var(--accent);"></i>
                    <p style="margin-top:12px;color:var(--text-2);">Scanning layouts...</p>
                </div>
                <div id="d5tm-health-results" style="display:none;">
                    <div class="d5tm-health-score">
                        <div class="d5tm-health-score-ring">
                            <span id="d5tm-health-pct">0%</span>
                        </div>
                        <div class="d5tm-health-score-info">
                            <strong id="d5tm-health-healthy">0</strong> of <strong id="d5tm-health-total">0</strong> layouts are healthy
                        </div>
                    </div>
                    <div class="d5tm-health-issues">
                        <div class="d5tm-health-issue" data-issue="empty_content">
                            <div class="d5tm-health-issue-icon" style="background:#fef3c7;color:#92400e;"><i class="bi bi-file-earmark-minus"></i></div>
                            <div class="d5tm-health-issue-info">
                                <strong>Empty Content</strong>
                                <span id="d5tm-health-empty-count">0 layouts</span>
                            </div>
                            <ul class="d5tm-health-issue-list" id="d5tm-health-empty-list"></ul>
                        </div>
                        <div class="d5tm-health-issue" data-issue="no_category">
                            <div class="d5tm-health-issue-icon" style="background:#dbeafe;color:#1e40af;"><i class="bi bi-folder-x"></i></div>
                            <div class="d5tm-health-issue-info">
                                <strong>Missing Categories</strong>
                                <span id="d5tm-health-nocat-count">0 layouts</span>
                            </div>
                            <ul class="d5tm-health-issue-list" id="d5tm-health-nocat-list"></ul>
                        </div>
                        <div class="d5tm-health-issue" data-issue="oversized">
                            <div class="d5tm-health-issue-icon" style="background:#fee2e2;color:#991b1b;"><i class="bi bi-hdd"></i></div>
                            <div class="d5tm-health-issue-info">
                                <strong>Oversized (&gt;1MB)</strong>
                                <span id="d5tm-health-oversized-count">0 layouts</span>
                            </div>
                            <ul class="d5tm-health-issue-list" id="d5tm-health-oversized-list"></ul>
                        </div>
                        <div class="d5tm-health-issue" data-issue="no_type">
                            <div class="d5tm-health-issue-icon" style="background:#fce7f3;color:#9d174d;"><i class="bi bi-tag-x"></i></div>
                            <div class="d5tm-health-issue-info">
                                <strong>Orphaned (No Type)</strong>
                                <span id="d5tm-health-notype-count">0 layouts</span>
                            </div>
                            <ul class="d5tm-health-issue-list" id="d5tm-health-notype-list"></ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d5tm-modal-footer">
                <button type="button" class="d5tm-btn d5tm-btn-secondary" id="d5tm-health-recheck"><i class="bi bi-arrow-clockwise"></i> Re-check</button>
                <button type="button" class="d5tm-btn" id="d5tm-health-done">Done</button>
            </div>
        </div>
    </div>

    <!-- Bulk Rename Modal -->
    <div class="d5tm-modal-overlay" id="d5tm-rename-overlay">
        <div class="d5tm-modal" style="width:450px;">
            <div class="d5tm-modal-header">
                <h2><i class="bi bi-input-cursor-text"></i> Bulk Rename</h2>
                <button type="button" class="d5tm-modal-close" id="d5tm-rename-close">&times;</button>
            </div>
            <div class="d5tm-modal-body">
                <div class="d5tm-form-group">
                    <label>Mode</label>
                    <select class="d5tm-input" id="d5tm-rename-mode">
                        <option value="prefix">Add Prefix</option>
                        <option value="suffix">Add Suffix</option>
                        <option value="replace">Find &amp; Replace</option>
                    </select>
                </div>
                <div class="d5tm-form-group" id="d5tm-rename-value-group">
                    <label id="d5tm-rename-value-label">Prefix Text</label>
                    <input type="text" class="d5tm-input" id="d5tm-rename-value" placeholder="Enter prefix...">
                </div>
                <div class="d5tm-form-group" id="d5tm-rename-replace-group" style="display:none;">
                    <label>Replace With</label>
                    <input type="text" class="d5tm-input" id="d5tm-rename-replace" placeholder="Replacement text...">
                </div>
                <p style="color:var(--text-3);font-size:0.82rem;margin-top:8px;">
                    This will rename <strong id="d5tm-rename-count">0</strong> selected layouts.
                </p>
            </div>
            <div class="d5tm-modal-footer">
                <span class="d5tm-status-msg" id="d5tm-rename-status"></span>
                <button type="button" class="d5tm-btn d5tm-btn-secondary" id="d5tm-rename-cancel">Cancel</button>
                <button type="button" class="d5tm-btn" id="d5tm-rename-apply"><i class="bi bi-check-lg"></i> Apply Rename</button>
            </div>
        </div>
    </div>

</div><!-- /.d5tm-app -->
</div><!-- /.d5tm-wrap -->

