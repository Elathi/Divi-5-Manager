jQuery(document).ready(function ($) {

    // ===== Tab Switching (Header) =====
    $('.d5tm-htab').on('click', function () {
        const target = $(this).data('target');
        $('.d5tm-htab').removeClass('active');
        $(this).addClass('active');
        $('.d5tm-tab').removeClass('active');
        $('#' + target).addClass('active');
    });

    // ===== Filter Logic =====
    let activeFilterType = 'cat';
    let activeFilterVal  = 'all';
    let searchTerm       = '';

    function applyFilters() {
        let visible = 0;
        $('.d5tm-card').each(function () {
            const cardSearch   = $(this).data('search') || '';
            const categoryList = $(this).data('cats') || '';
            const tagList      = $(this).data('tags') || '';
            const typeList     = $(this).data('type') || '';
            const favStatus    = $(this).data('fav') || '0';

            const matchSearch = !searchTerm || cardSearch.indexOf(searchTerm) !== -1;

            let matchFilter = true;
            if (activeFilterVal !== 'all') {
                if (activeFilterType === 'fav') {
                    matchFilter = favStatus === 1 || favStatus === '1';
                } else if (activeFilterType === 'cat') {
                    matchFilter = (' ' + categoryList + ' ').indexOf(' ' + activeFilterVal + ' ') !== -1;
                } else if (activeFilterType === 'tag') {
                    matchFilter = (' ' + tagList + ' ').indexOf(' ' + activeFilterVal + ' ') !== -1;
                } else if (activeFilterType === 'type') {
                    matchFilter = (' ' + typeList + ' ').indexOf(' ' + activeFilterVal + ' ') !== -1;
                }
            }

            if (matchSearch && matchFilter) {
                $(this).show();
                visible++;
            } else {
                $(this).hide();
            }
        });
        $('#d5tm-count-label').text(visible + ' result' + (visible !== 1 ? 's' : ''));
        $('.d5tm-header-count').text(visible + ' layouts');
        if (visible === 0) {
            $('.d5tm-empty-state').show();
        } else {
            $('.d5tm-empty-state').hide();
        }
    }

    // Search
    $('#d5tm-search-input').on('input keyup', function () {
        searchTerm = $(this).val().trim().toLowerCase();
        applyFilters();
        highlightMatches(searchTerm);
    });

    // Sidebar navigation
    $(document).on('click', '.d5tm-sidebar-link[data-filter-type]', function () {
        $('.d5tm-sidebar-link').removeClass('active');
        $(this).addClass('active');
        activeFilterType = $(this).data('filter-type');
        activeFilterVal  = $(this).data('filter-val');
        applyFilters();
    });

    // Sidebar link click (general)
    $(document).on('click', '.d5tm-sidebar-link', function() {
        const $link = $(this);
        $('.d5tm-sidebar-link').removeClass('active');
        $link.addClass('active');

        activeFilterType = $link.data('filter-type');
        activeFilterVal  = $link.data('filter-val');
        applyFilters();
    });

    // Interactive card filtering (Click on pill/icon)
    $(document).on('click', '.d5tm-clickable-filter', function(e) {
        e.preventDefault();
        e.stopPropagation();

        const $btn = $(this);
        const type = $btn.data('filter-type');
        const val  = $btn.data('filter-val');

        // Find the matching sidebar link and trigger it
        const $sidebarLink = $('.d5tm-sidebar-link[data-filter-type="' + type + '"][data-filter-val="' + val + '"]');
        if ($sidebarLink.length) {
            $sidebarLink.trigger('click');
        } else {
            // Fallback: manually update if sidebar link is not found (e.g. hidden empty cats)
            activeFilterType = type;
            activeFilterVal  = val;
            $('.d5tm-sidebar-link').removeClass('active');
            applyFilters();
        }
    });

    // ===== Toast Notification System =====
    const $toastContainer = $('#d5tm-toast-container');

    function showToast(message, type = 'info', duration = 3000) {
        const iconMap = {
            success: 'bi-check-circle',
            error: 'bi-x-circle',
            warning: 'bi-exclamation-triangle',
            info: 'bi-info-circle'
        };
        const $toast = $('<div class="d5tm-toast d5tm-toast-' + type + '">' +
            '<i class="bi ' + (iconMap[type] || iconMap.info) + '"></i>' +
            '<span>' + message + '</span>' +
            '<button type="button" class="d5tm-toast-close"><i class="bi bi-x"></i></button>' +
        '</div>');

        $toastContainer.append($toast);
        setTimeout(() => $toast.addClass('active'), 10);

        $toast.find('.d5tm-toast-close').on('click', () => dismissToast($toast));

        if (duration > 0) {
            setTimeout(() => dismissToast($toast), duration);
        }
    }

    function dismissToast($toast) {
        $toast.removeClass('active');
        setTimeout(() => $toast.remove(), 300);
    }

    // ===== Confirm Dialog =====
    function showConfirm(title, message) {
        return new Promise((resolve) => {
            const $overlay = $('#d5tm-confirm-overlay');
            $('#d5tm-confirm-title').html('<i class="bi bi-exclamation-triangle"></i> ' + title);
            $('#d5tm-confirm-message').text(message);
            $overlay.addClass('active');

            $('#d5tm-confirm-ok').off('click').on('click', () => {
                $overlay.removeClass('active');
                resolve(true);
            });
            $('#d5tm-confirm-cancel').off('click').on('click', () => {
                $overlay.removeClass('active');
                resolve(false);
            });
        });
    }

    // ===== Toolbar Select Dropdowns (Sort & Grid View) =====
    const $sortSelect     = $('#d5tm-sort-order'); // Matched to HTML id
    const $gridColsSelect = $('#d5tm-grid-cols');
    const $grid           = $('#d5tm-grid');

    // Sort Layouts — supports name A-Z, Z-A, date newest, date oldest
    $sortSelect.on('change', function () {
        const sortVal = $(this).val();
        const $cards  = $grid.children('.d5tm-card').toArray();

        $cards.sort(function (a, b) {
            if (sortVal === 'name_asc') {
                const na = ($(a).data('title') || '').toString().toLowerCase();
                const nb = ($(b).data('title') || '').toString().toLowerCase();
                return na.localeCompare(nb);
            } else if (sortVal === 'name_desc') {
                const na = ($(a).data('title') || '').toString().toLowerCase();
                const nb = ($(b).data('title') || '').toString().toLowerCase();
                return nb.localeCompare(na);
            } else if (sortVal === 'date_desc') {
                return parseInt($(b).data('date') || 0) - parseInt($(a).data('date') || 0);
            } else if (sortVal === 'date_asc') {
                return parseInt($(a).data('date') || 0) - parseInt($(b).data('date') || 0);
            }
            return 0;
        });

        $.each($cards, function (i, card) { $grid.append(card); });
    });

    // Grid Columns Layout
    $gridColsSelect.on('change', function () {
        const cols = $(this).val();
        $grid.removeClass('cols-1 cols-2 cols-3 cols-4 cols-5');
        if (cols !== 'auto') {
            $grid.addClass('cols-' + cols);
        }
        localStorage.setItem('d5tm_grid_cols', cols);

        // Re-scale any visible iframes based on new card widths
        $('.d5tm-card').each(function() {
            const $wrapper = $(this).find('.d5tm-iframe-wrapper.active');
            if ($wrapper.length) {
                applyIframeScale($wrapper);
            }
        });
    });

    // Restore saved grid preference on load
    const savedGrid = localStorage.getItem('d5tm_grid_cols') || 'auto';
    if (savedGrid !== 'auto') {
        $gridColsSelect.val(savedGrid).trigger('change');
    }

    // ===== Live Hover Preview (static top-of-layout snapshot) =====
    let hoverTimer = null;

    // Source viewport width for the iframe (simulates desktop)
    const IFRAME_SRC_W = 1200;
    const IFRAME_SRC_H = 700;  // only capture above-the-fold portion

    function applyIframeScale( $wrap, $iframe ) {
        // Use actual rendered card dimensions
        let wrapW = $wrap.outerWidth();
        let wrapH = $wrap.outerHeight();

        // Fallbacks if DOM hasn't painted yet
        if ( ! wrapW || wrapW < 10 ) wrapW = $wrap.parent().outerWidth() || 220;
        if ( ! wrapH || wrapH < 10 ) wrapH = Math.round( wrapW * 0.75 ); // 4:3 fallback

        // Scale factor: fit the 1200px-wide source into the card width
        const scale = wrapW / IFRAME_SRC_W;

        // Work out how tall the source needs to be so the scaled result
        // matches the card height EXACTLY — eliminates the white gap.
        const srcH = Math.ceil( wrapH / scale );

        // Negative margins collapse the space that transform:scale() leaves
        // (scale doesn't shrink the layout footprint, only visually shrinks).
        const marginRight  = -( IFRAME_SRC_W - wrapW );  // horizontal leftover
        const marginBottom = -( srcH - wrapH );           // vertical leftover

        $iframe.css({
            height          : srcH + 'px',
            transform       : 'scale(' + scale + ')',
            'margin-right'  : marginRight  + 'px',
            'margin-bottom' : marginBottom + 'px'
        });
        // Do NOT set wrap height — live-wrap has inset:0 so it fills the card naturally
    }

    $(document).on('mouseenter', '.d5tm-card', function () {
        const $card = $(this);
        const $wrap = $card.find('.d5tm-thumb-live-wrap');
        if ( ! $wrap.length ) return;           // card has a custom image — skip

        const previewUrl = $card.data('preview-url');
        if ( ! previewUrl ) return;

        // 250ms delay prevents loads on fast mouse-sweep
        hoverTimer = setTimeout(function () {
            let $iframe;

            if ( ! $wrap.find('iframe').length ) {
                $iframe = $('<iframe/>', {
                    src          : previewUrl,
                    frameborder  : '0',
                    scrolling    : 'no',
                    'aria-hidden': 'true'
                });
                $wrap.append( $iframe );
            } else {
                $iframe = $wrap.find('iframe');
            }

            // Apply the correct scale so iframe fills 100% of the card width
            applyIframeScale( $wrap, $iframe );

            $card.find('.d5tm-skel-static').css('opacity', '0');
            $wrap.addClass('active');
        }, 250);
    });

    $(document).on('mouseleave', '.d5tm-card', function () {
        clearTimeout(hoverTimer);
        const $card = $(this);
        const $wrap = $card.find('.d5tm-thumb-live-wrap');
        if ( ! $wrap.length ) return;

        $wrap.removeClass('active');
        $card.find('.d5tm-skel-static').css('opacity', '1');

        // Destroy iframe after transition to free memory
        setTimeout(function () {
            if ( ! $wrap.hasClass('active') ) {
                $wrap.find('iframe').remove();
            }
        }, 320);
    });

    // ===== Import: Drag & Drop =====
    const $dropzone  = $('#d5tm-dropzone');
    const $fileInput = $('#d5tm-file-input');
    const $status    = $('#d5tm-upload-status');

    $('#d5tm-browse-btn').on('click', function (e) {
        e.preventDefault();
        $fileInput.trigger('click');
    });

    $dropzone.on('dragover', function (e) {
        e.preventDefault();
        $(this).addClass('dragover');
    }).on('dragleave drop', function (e) {
        e.preventDefault();
        $(this).removeClass('dragover');
        if (e.type === 'drop') {
            handleFiles(e.originalEvent.dataTransfer.files);
        }
    });

    $fileInput.on('change', function () {
        handleFiles(this.files);
    });

    function handleFiles(files) {
        if (!files || files.length === 0) return;

        let fileMap = {};
        let jsons = [];

        // Map files by base name
        Array.from(files).forEach(function(file) {
            let parts = file.name.split('.');
            let ext = parts.pop().toLowerCase();
            let base = parts.join('.');
            if (!fileMap[base]) fileMap[base] = {};
            fileMap[base][ext] = file;

            if (ext === 'json') jsons.push(base);
        });

        if (jsons.length === 0) {
            showStatus('Please upload at least one valid .json file.', 'error');
            return;
        }

        // Show file list preview
        const $fileList = $('#d5tm-import-file-list');
        $fileList.empty();
        jsons.forEach(base => {
            const hasImg = fileMap[base]['jpg'] || fileMap[base]['png'] || fileMap[base]['jpeg'] || fileMap[base]['webp'];
            $fileList.append('<div class="d5tm-import-file-item">' +
                '<i class="bi bi-filetype-json"></i> ' + base + '.json' +
                (hasImg ? ' <i class="bi bi-image" style="color:var(--green);"></i>' : '') +
            '</div>');
        });
        $('#d5tm-import-options').show();

        $('#d5tm-dashboard-grid').css('opacity', '0.5'); // dim grid during upload
        uploadSequentially(jsons, fileMap, 0);
    }

    function uploadSequentially(jsons, fileMap, index) {
        if (index >= jsons.length) {
            showStatus('All imports finished! Reloading...', 'success');
            $fileInput.val('');
            $('#d5tm-import-progress').hide();
            $('#d5tm-import-options').hide();
            $('#d5tm-import-file-list').empty();
            setTimeout(function () { location.reload(); }, 1500);
            return;
        }

        const base = jsons[index];
        const jsonFile = fileMap[base]['json'];
        const imgFile = fileMap[base]['jpg'] || fileMap[base]['png'] || fileMap[base]['jpeg'] || fileMap[base]['webp'];

        const formData = new FormData();
        formData.append('action', 'd5tm_import_layout');
        formData.append('nonce', d5tm_ajax.nonce);
        formData.append('file', jsonFile);
        if (imgFile) formData.append('thumbnail', imgFile);

        // Pass the category when uploading
        const importCat = $('#d5tm-import-category').val();
        if (importCat) formData.append('category_id', importCat);

        // Show progress
        $('#d5tm-import-progress').show();
        const pct = Math.round(((index + 1) / jsons.length) * 100);
        $('#d5tm-progress-fill').css('width', pct + '%');
        $('#d5tm-progress-text').text(pct + '%');

        showStatus('Uploading ' + (index + 1) + ' of ' + jsons.length + ': ' + base + '...', '');

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                uploadSequentially(jsons, fileMap, index + 1);
            },
            error: function () {
                uploadSequentially(jsons, fileMap, index + 1);
            }
        });
    }

    function showStatus(msg, type) {
        $status.text(msg).removeClass('success error');
        if (type) { $status.addClass(type); }
        else { $status.show(); }
    }

    // ===== Copy Layout Button =====
    $('.d5tm-copy-layout-btn').on('click', function (e) {
        e.preventDefault();
        const $btn = $(this);
        const layoutId = $btn.data('id');
        const originalText = $btn.html();

        // Loading state
        $btn.html('<i class="bi bi-arrow-repeat d5tm-spin"></i> Copying...');

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'd5tm_get_layout_data',
                nonce: d5tm_ajax.nonce,
                layout_id: layoutId
            },
            success: function (response) {
                if (response.success) {
                    const dataToCopy = response.data.layout_data;

                    // Fallback cross-page mechanism: Write to standard Divi local storage keys
                    try {
                        localStorage.setItem('divi_clipboard', dataToCopy);
                        localStorage.setItem('et_pb_templates_clipboard', dataToCopy);
                        localStorage.setItem('et_pb_recently_copied_module', dataToCopy);
                    } catch(err) {}

                    // Write strict plain text string to OS Clipboard
                    if (navigator.clipboard) {
                        navigator.clipboard.writeText(dataToCopy).then(function () {
                            showCopiedState($btn, originalText);
                        }).catch(function () {
                            fallbackCopyTextToClipboard(dataToCopy, $btn, originalText);
                        });
                    } else {
                        fallbackCopyTextToClipboard(dataToCopy, $btn, originalText);
                    }
                } else {
                    $btn.html('<i class="bi bi-exclamation-triangle"></i> Error');
                    setTimeout(function () { $btn.html(originalText); }, 2000);
                }
            },
            error: function () {
                $btn.html('<i class="bi bi-exclamation-triangle"></i> Error');
                setTimeout(function () { $btn.html(originalText); }, 2000);
            }
        });
    });

    function fallbackCopyTextToClipboard(text, $btn, originalText) {
        const textArea = document.createElement("textarea");
        textArea.value = text;

        // Avoid scrolling to bottom
        textArea.style.top = "0";
        textArea.style.left = "0";
        textArea.style.position = "fixed";

        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();

        try {
            document.execCommand('copy');
            showCopiedState($btn, originalText);
        } catch (err) {
            $btn.html('<i class="bi bi-exclamation-triangle"></i> Failed');
            setTimeout(function () { $btn.html(originalText); }, 2000);
        }

        document.body.removeChild(textArea);
    }

    function showCopiedState($btn, originalHtml) {
        $btn.html('<i class="bi bi-check-lg"></i> Copied!');
        $btn.addClass('copied');
        setTimeout(function () {
            $btn.html(originalHtml);
            $btn.removeClass('copied');
        }, 2000);
    }

    // ===== Light/Dark Theme Toggle =====
    const $themeToggleBtn = $('#d5tm-theme-toggle');
    const $wrapContainer  = $('.d5tm-wrap');

    // Default to dark, so if the user chose dark previously, add the class.
    const savedTheme = localStorage.getItem('d5tm_theme') || 'light';

    if (savedTheme === 'dark') {
        $wrapContainer.addClass('d5tm-theme-dark');
        $themeToggleBtn.find('i').attr('class', 'bi bi-moon-stars');
    }

    $themeToggleBtn.on('click', function() {
        const $icon = $(this).find('i');
        if ($wrapContainer.hasClass('d5tm-theme-dark')) {
            $wrapContainer.removeClass('d5tm-theme-dark');
            localStorage.setItem('d5tm_theme', 'light');
            $icon.attr('class', 'bi bi-sun');
        } else {
            $wrapContainer.addClass('d5tm-theme-dark');
            localStorage.setItem('d5tm_theme', 'dark');
            $icon.attr('class', 'bi bi-moon-stars');
        }
    });

    // ===== Quick Edit Modal & WP Media Uploader =====
    const $modalOverlay = $('#d5tm-modal-overlay');
    const $qeForm       = $('#d5tm-quick-edit-form');
    const $statusMsg    = $('#d5tm-qe-status-msg');
    let currentCard   = null; // To store reference to the card being edited
    let mediaFrame;

    // Open Modal
    $(document).on('click', '.d5tm-action-quick-edit', function(e) {
        e.preventDefault();
        e.stopPropagation(); // prevent card click

        $statusMsg.text('').removeClass('error');
        currentCard = $(this).closest('.d5tm-card');

        // Extract Data
        const layoutId     = currentCard.data('layout-id');
        const title        = currentCard.data('title');
        const status       = currentCard.data('status');
        const thumbId      = currentCard.data('thumbnail-id');
        const thumbUrl     = currentCard.data('thumbnail-url');
        const tagsRaw      = currentCard.data('tags-raw');

        // Ensure data-cats-json is a valid string, then parse
        const catsJsonStr = currentCard.attr('data-cats-json');
        let catsIds = [];
        if (catsJsonStr) {
            try {
                catsIds = JSON.parse(catsJsonStr);
            } catch(e) {
                console.error("Invalid cats json", catsJsonStr);
            }
        }

        // Populate Form
        $('#d5tm-qe-layout-id').val(layoutId);
        $('#d5tm-qe-title').val(title);
        $('#d5tm-qe-status').val(status);
        $('#d5tm-qe-tags').val(tagsRaw);

        // Checkboxes
        $('input[name="layout_categories[]"]').prop('checked', false);
        if (catsIds.length > 0) {
            catsIds.forEach(function(catId) {
                // Ensure the string literal properly wraps exactly inside double quotes for attribute selector
                $('input[name="layout_categories[]"][value="' + catId + '"]').prop('checked', true);
            });
        }

        // Thumbnail
        $('#d5tm-qe-thumbnail-id').val(thumbId);
        if (thumbId && thumbUrl) {
            $('#d5tm-qe-thumbnail-img').attr('src', thumbUrl).show();
            $('#d5tm-qe-placeholder').hide();
        } else {
            $('#d5tm-qe-thumbnail-img').attr('src', '').hide();
            $('#d5tm-qe-placeholder').show();
        }

        $modalOverlay.addClass('active');
    });

    // Close Modal
    $('#d5tm-modal-close-btn, #d5tm-modal-cancel-btn').on('click', function() {
        $modalOverlay.removeClass('active');
    });

    // Handle WP Media Uploader
    $('#d5tm-qe-set-thumb').on('click', function(e) {
        e.preventDefault();

        // If frame exists, open it.
        if (mediaFrame) {
            mediaFrame.open();
            return;
        }

        // Create a new media frame
        mediaFrame = wp.media({
            title: 'Select or Upload a Preview Image',
            button: { text: 'Use this image' },
            multiple: false
        });

        // When an image is selected
        mediaFrame.on('select', function() {
            const attachment = mediaFrame.state().get('selection').first().toJSON();
            $('#d5tm-qe-thumbnail-id').val(attachment.id);
            // Show the image
            const imgUrl = attachment.sizes && attachment.sizes.large ? attachment.sizes.large.url : attachment.url;
            $('#d5tm-qe-thumbnail-img').attr('src', imgUrl).show();
            $('#d5tm-qe-placeholder').hide();
        });

        mediaFrame.open();
    });

    // Remove Thumbnail
    $('#d5tm-qe-remove-thumb').on('click', function(e) {
        e.preventDefault();
        $('#d5tm-qe-thumbnail-id').val('-1'); // -1 flags deletion in PHP
        $('#d5tm-qe-thumbnail-img').attr('src', '').hide();
        $('#d5tm-qe-placeholder').show();
    });

    // Save Quick Edit via AJAX
    $('#d5tm-qe-save-btn').on('click', function(e) {
        e.preventDefault();
        const $btn = $(this);
        const formData = $qeForm.serializeArray();

        formData.push({ name: 'action', value: 'd5tm_quick_edit_layout' });
        formData.push({ name: 'nonce', value: d5tm_ajax.nonce });

        $btn.text('Updating...').prop('disabled', true);
        $statusMsg.text('').removeClass('error');

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    $statusMsg.text('Updated successfully!').css('color', 'var(--green)');

                    // Update DOM (Card Title)
                    if (currentCard) {
                        const newTitle = $('#d5tm-qe-title').val();
                        currentCard.data('title', newTitle);
                        currentCard.find('.d5tm-card-name').text(newTitle);

                        // Update Thumbnail locally
                        const thumbId = $('#d5tm-qe-thumbnail-id').val();
                        const thumbUrl = $('#d5tm-qe-thumbnail-img').attr('src');
                        currentCard.data('thumbnail-id', thumbId == '-1' ? '0' : thumbId);

                        if (thumbId == '-1' || !thumbUrl) {
                            // Revert to placeholder HTML inside the card
                            const $thumb = currentCard.find('.d5tm-thumb');
                            const $overlay = $thumb.find('.d5tm-thumb-overlay').detach();
                            $thumb.empty().append(`
                                <div class="d5tm-thumb-empty">
                                    <i class="bi bi-image"></i>
                                    <span>No preview</span>
                                </div>
                            `).append($overlay);
                        } else {
                            // Show new image in card
                            const $thumb = currentCard.find('.d5tm-thumb');
                            const $overlay = $thumb.find('.d5tm-thumb-overlay').detach();
                            const $img = $('<img class="d5tm-thumb-img" alt="Preview" loading="lazy">').attr('src', thumbUrl);
                            $thumb.empty().append($img).append($overlay);
                        }
                    }

                    setTimeout(function() {
                        $modalOverlay.removeClass('active');
                        $btn.text('Update').prop('disabled', false);
                    }, 1000);
                } else {
                    $statusMsg.text(response.data.message || 'Error occurred').css('color', 'var(--red)');
                    $btn.text('Update').prop('disabled', false);
                }
            },
            error: function() {
                $statusMsg.text('AJAX Error occurred').css('color', 'var(--red)');
                $btn.text('Update').prop('disabled', false);
            }
        });
    });

    // ===== Live Preview Modal =====
    const $lpModalOverlay = $('#d5tm-live-preview-modal');
    const $lpIframe       = $('#d5tm-lp-iframe');
    const $lpIframeWrap   = $('.d5tm-lp-iframe-wrapper');
    const $lpTitle        = $('#d5tm-lp-title');

    // Open Live Preview
    $(document).on('click', '.d5tm-action-live-preview', function(e) {
        e.preventDefault();
        e.stopPropagation();

        const $card     = $(this).closest('.d5tm-card');
        const previewUrl = $card.data('preview-url');
        const title      = $card.data('title');

        if (previewUrl) {
            $lpTitle.text('Preview: ' + title);

            // Setting src with a slight delay allows the modal transition to start smoothly
            setTimeout(function() {
                $lpIframe.attr('src', previewUrl);
            }, 100);

            $lpModalOverlay.addClass('active');

            // Reset to desktop view
            $('.d5tm-lp-device-btn').removeClass('active');
            $('.d5tm-lp-device-btn[data-device="desktop"]').addClass('active');
            $lpIframeWrap.removeClass('desktop tablet mobile').addClass('desktop');
        }
    });

    // Close Live Preview
    $('#d5tm-lp-close').on('click', function() {
        $lpModalOverlay.removeClass('active');

        // Clear iframe source after transition to stop background processes/videos
        setTimeout(function() {
            $lpIframe.attr('src', '');
        }, 300);
    });

    // Responsive Toggles
    $('.d5tm-lp-device-btn').on('click', function() {
        const device = $(this).data('device');

        // Update active class on buttons
        $('.d5tm-lp-device-btn').removeClass('active');
        $(this).addClass('active');

        // Update wrapper class for CSS transition max-width
        $lpIframeWrap.removeClass('desktop tablet mobile').addClass(device);
    });

    // Refresh Dashboard
    $('.d5tm-action-refresh').on('click', function(e) {
        e.preventDefault();
        const $icon = $(this).find('i');
        $icon.addClass('d5tm-spin');
        window.location.reload();
    });

    // ===== Action logic Helpers =====
    async function triggerActionHelper(action, layoutId, confirmMsg, successCallback) {
        if (confirmMsg) {
            const confirmed = await showConfirm('Confirm Action', confirmMsg);
            if (!confirmed) return;
        }

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: action,
                nonce: d5tm_ajax.nonce,
                layout_id: layoutId
            },
            success: function(response) {
                if (response.success) {
                    if (successCallback) successCallback(response);
                } else {
                    showToast(response.data.message || 'An error occurred', 'error');
                }
            },
            error: function() {
                showToast('An error occurred while communicating with the server', 'error');
            }
        });
    }

    // Move to Trash
    $(document).on('click', '.d5tm-action-trash', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const $card = $(this).closest('.d5tm-card');
        const layoutId = $card.data('layout-id');
        triggerActionHelper('d5tm_trash_layout', layoutId, 'Move this layout to the Trash?', function() {
            $card.fadeOut(300, function() { $(this).remove(); });
        });
    });

    // Restore
    $(document).on('click', '.d5tm-action-restore', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const $card = $(this).closest('.d5tm-card');
        const layoutId = $card.data('layout-id');
        triggerActionHelper('d5tm_restore_layout', layoutId, null, function() {
            $card.fadeOut(300, function() { $(this).remove(); });
        });
    });

    // Delete Permanently
    $(document).on('click', '.d5tm-action-delete', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const $card = $(this).closest('.d5tm-card');
        const layoutId = $card.data('layout-id');
        triggerActionHelper('d5tm_delete_layout', layoutId, 'WARNING: This will permanently delete the layout. Are you sure?', function() {
            $card.fadeOut(300, function() { $(this).remove(); });
        });
    });

    // Download Layout (JSON)
    $(document).on('click', '.d5tm-action-download', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const layoutId = $(this).closest('.d5tm-card').data('layout-id');
        const $icon = $(this).find('i');

        // Loading state
        $icon.removeClass('bi-download').addClass('bi-arrow-repeat d5tm-spin');

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'd5tm_download_layout',
                nonce: d5tm_ajax.nonce,
                layout_id: layoutId
            },
            success: function(response) {
                if (response.success) {
                    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(response.data.json);
                    const downloadAnchorNode = document.createElement('a');
                    downloadAnchorNode.setAttribute("href", dataStr);
                    downloadAnchorNode.setAttribute("download", response.data.filename);
                    document.body.appendChild(downloadAnchorNode); // required for firefox
                    downloadAnchorNode.click();
                    downloadAnchorNode.remove();
                } else {
                    showToast(response.data.message || 'Download failed', 'error');
                }
            },
            error: function() {
                showToast('A network error occurred.', 'error');
            },
            complete: function() {
                $icon.removeClass('bi-arrow-repeat d5tm-spin').addClass('bi-download');
            }
        });
    });

    // Duplicate Layout
    $(document).on('click', '.d5tm-action-duplicate', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const $card = $(this).closest('.d5tm-card');
        const layoutId = $card.data('layout-id');
        const $icon = $(this).find('i');

        $icon.removeClass('bi-copy').addClass('bi-arrow-repeat d5tm-spin');

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'd5tm_duplicate_layout',
                nonce: d5tm_ajax.nonce,
                layout_id: layoutId
            },
            success: function(response) {
                if (response.success) {
                    showToast('Layout duplicated: ' + response.data.new_title, 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showToast(response.data.message || 'Failed to duplicate layout', 'error');
                    $icon.removeClass('bi-arrow-repeat d5tm-spin').addClass('bi-copy');
                }
            },
            error: function() {
                showToast('Network error while duplicating layout', 'error');
                $icon.removeClass('bi-arrow-repeat d5tm-spin').addClass('bi-copy');
            }
        });
    });

    // ===== Feature Guide Modal handlers =====
    const $guideModal = $('#d5tm-guide-modal');

    $('#d5tm-help-trigger').on('click', function() {
        $guideModal.addClass('active');
    });

    $('#d5tm-guide-close-btn, #d5tm-guide-ok-btn').on('click', function() {
        $guideModal.removeClass('active');
    });

    $guideModal.on('click', function(e) {
        if ($(e.target).is($guideModal)) {
            $guideModal.removeClass('active');
        }
    });

    // ===== Global Tooltip System (Portal Implementation) =====
    const $globalTooltip = $('<div class="d5tm-global-tooltip"></div>').appendTo('body');

    $(document).on('mouseenter', '[data-tooltip]', function() {
        const $el = $(this);
        const text = $el.attr('data-tooltip');
        if (!text) return;

        $globalTooltip.text(text);

        const rect = this.getBoundingClientRect();
        const tipWidth = $globalTooltip.outerWidth();
        const tipHeight = $globalTooltip.outerHeight();

        // Default position: above (top)
        let top = rect.top - tipHeight - 12;
        let left = rect.left + (rect.width / 2) - (tipWidth / 2);
        let posClass = 'pos-top';

        // SMART FLIP: If too close to top of viewport, show below
        if (rect.top < tipHeight + 40) {
            top = rect.bottom + 12;
            posClass = 'pos-bottom';
        }

        $globalTooltip.css({
            top: top + 'px',
            left: left + 'px'
        }).removeClass('pos-top pos-bottom').addClass(posClass + ' active');
    });

    $(document).on('mouseleave', '[data-tooltip]', function() {
        $globalTooltip.removeClass('active');
    });

    // ===== Term Color Management =====
    $(document).on('change', '.d5tm-term-color-picker', function() {
        const $picker = $(this);
        const termId  = $picker.data('term-id');
        const color   = $picker.val();

        // Update Folder Icon Color Instantly
        $picker.closest('.d5tm-sidebar-item-wrap').find('i').css('color', color);

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'd5tm_update_term_color',
                nonce: d5tm_ajax.nonce,
                term_id: termId,
                color: color
            },
            success: function(response) {
                if (response.success) {
                    // Refresh if layout grid needs to reflect new skeleton colors
                    console.log('Term color updated successfully.');
                }
            }
        });
    });

    // ============================================================
    // v2.7.0 — UX Polish & Category Management
    // ============================================================

    // === [1] Search Highlighting ===
    function highlightMatches( term ) {
        $('.d5tm-card-name').each(function () {
            const $el = $(this);
            // Restore original text first
            const original = $el.data('original-text') || $el.text();
            $el.data('original-text', original);

            if (!term) {
                $el.html(original);
                return;
            }
            const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const regex   = new RegExp('(' + escaped + ')', 'gi');
            const highlighted = original.replace(regex, '<mark class="d5tm-highlight">$1</mark>');
            $el.html(highlighted);
        });
    }

    // === [2] Keyboard Shortcuts ===
    $(document).on('keydown', function (e) {
        const tag = document.activeElement.tagName.toLowerCase();
        if (tag === 'input' || tag === 'textarea' || tag === 'select') return;

        // '/' — Focus search
        if (e.key === '/') {
            e.preventDefault();
            const $search = $('#d5tm-search-input');
            if ($search.length) {
                $search.focus();
            }
        }

        // 'Escape' — Clear filters & search
        if (e.key === 'Escape') {
            $('#d5tm-search-input').val('').trigger('input');
            highlightMatches('');
            $('.d5tm-sidebar-link').removeClass('active');
            $('.d5tm-sidebar-link[data-filter-val="all"]').addClass('active');
            if (typeof applyFilters === 'function') {
                // Reset internal state
                searchTerm = '';
                activeFilterVal = 'all';
                activeFilterType = 'cat';
                applyFilters();
            }
        }
    });

    // === [3] Copy Layout ID ===
    $(document).on('click', '.d5tm-copy-id-btn', function () {
        const $btn = $(this);
        const id   = $btn.data('id');

        if (!navigator.clipboard) {
            // Fallback for older browsers
            const $temp = $('<input>');
            $('body').append($temp);
            $temp.val(id).select();
            document.execCommand('copy');
            $temp.remove();
        } else {
            navigator.clipboard.writeText(String(id));
        }

        // Visual feedback
        $btn.addClass('copied');
        const $icon = $btn.find('i');
        $icon.removeClass('bi-clipboard').addClass('bi-clipboard-check');
        setTimeout(function () {
            $btn.removeClass('copied');
            $icon.removeClass('bi-clipboard-check').addClass('bi-clipboard');
        }, 1800);
    });

    // === [4] Delete Empty Categories (Settings Page) ===
    $(document).on('click', '#d5tm-delete-empty-cats', async function () {
        const confirmed = await showConfirm(
            'Delete Empty Categories',
            'Are you sure you want to permanently delete ALL empty categories and tags?\n\nThis action cannot be undone.'
        );
        if (!confirmed) return;

        const $btn    = $(this);
        const $result = $('#d5tm-delete-cats-result');

        $btn.prop('disabled', true).html('<i class="bi bi-hourglass-split"></i> Deleting...');

        $.ajax({
            url:  d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'd5tm_delete_empty_cats',
                nonce:  d5tm_ajax.nonce
            },
            success: function (response) {
                $btn.prop('disabled', false).html('<i class="bi bi-trash3"></i> Delete All Empty Categories &amp; Tags');
                if (response.success) {
                    const cls = response.data.count > 0 ? 'd5tm-result-success' : 'd5tm-result-info';
                    $result
                        .removeClass('d5tm-result-success d5tm-result-info')
                        .addClass(cls)
                        .html('<i class="bi bi-' + (response.data.count > 0 ? 'check-circle' : 'info-circle') + '"></i> ' + response.data.message)
                        .show();
                } else {
                    $result.addClass('d5tm-result-info').html('<i class="bi bi-x-circle"></i> ' + (response.data ? response.data.message : 'An error occurred.')).show();
                }
            },
            error: function () {
                $btn.prop('disabled', false).html('<i class="bi bi-trash3"></i> Delete All Empty Categories &amp; Tags');
                $result.addClass('d5tm-result-info').html('<i class="bi bi-x-circle"></i> Network error. Please try again.').show();
            }
        });
    });

    // ============================================================
    // v3.0.0 — Batch Editor Logic
    // ============================================================

    let selectedIds = [];
    let isSelecting = false;

    function updateBulkBar() {
        if (selectedIds.length > 0) {
            $('#d5tm-bulk-count').text(selectedIds.length);
            $('#d5tm-bulk-bar-wrap').addClass('active');
        } else {
            $('#d5tm-bulk-bar-wrap').removeClass('active');
        }
    }

    // Toggle Select Mode
    $(document).on('click', '.d5tm-bulk-select-toggle', function() {
        isSelecting = !isSelecting;
        const $btn = $(this);

        if (isSelecting) {
            $btn.addClass('active').html('<i class="bi bi-x-circle"></i> Cancel Select');
            $('.d5tm-card').addClass('selecting');
        } else {
            $btn.removeClass('active').html('<i class="bi bi-check2-square"></i> Select');
            $('.d5tm-card').removeClass('selecting selected');
            $('.d5tm-card-checkbox').prop('checked', false);
            selectedIds = [];
            updateBulkBar();
        }
    });

    // Handle Individual Card Selection
    $(document).on('change', '.d5tm-card-checkbox', function() {
        const id = $(this).val();
        const $card = $(this).closest('.d5tm-card');

        if ($(this).is(':checked')) {
            if (selectedIds.indexOf(id) === -1) selectedIds.push(id);
            $card.addClass('selected');
        } else {
            selectedIds = selectedIds.filter(function(i) { return i !== id; });
            $card.removeClass('selected');
        }
        updateBulkBar();
    });

    // Bulk Dropdown Toggle
    $(document).on('click', '.d5tm-bulk-dropdown-trigger', function(e) {
        e.stopPropagation();
        $('.d5tm-bulk-dropdown').toggleClass('active');
    });

    $(document).click(function() {
        $('.d5tm-bulk-dropdown').removeClass('active');
    });

    // Bulk Cancel Btn — bind to both class and ID for robustness
    $(document).on('click', '.d5tm-bulk-cancel, #d5tm-bulk-cancel', function() {
        // Exit select mode and clear all selections
        isSelecting = false;
        $('.d5tm-bulk-select-toggle').removeClass('active').html('<i class="bi bi-check2-square"></i> Select');
        $('.d5tm-card').removeClass('selecting selected');
        $('.d5tm-card-checkbox').prop('checked', false);
        selectedIds = [];
        updateBulkBar();
    });

    // --- Bulk AJAX Actions ---

    async function runBulkAction(action, extraData, confirmMsg) {
        if (confirmMsg) {
            const confirmed = await showConfirm('Confirm Action', confirmMsg);
            if (!confirmed) return;
        }

        const $bar = $('.d5tm-bulk-bar');
        const originalContent = $bar.html();
        $bar.html('<div style="width:100%; text-align:center;"><i class="bi bi-arrow-repeat d5tm-spin"></i> Processing ' + selectedIds.length + ' items...</div>');

        const data = {
            action: action,
            ids: selectedIds,
            nonce: d5tm_ajax.nonce
        };
        $.extend(data, extraData);

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: data,
            success: function(response) {
                if (response.success) {
                    location.reload(); // Simplest way to refresh state
                } else {
                    showToast(response.data.message || 'Error executing bulk action.', 'error');
                    $bar.html(originalContent);
                    updateBulkBar();
                }
            },
            error: function() {
                showToast('Network error.', 'error');
                $bar.html(originalContent);
                updateBulkBar();
            }
        });
    }

    // Assign Category
    $(document).on('click', '.d5tm-bulk-assign-cat', function() {
        const termId = $(this).data('cat-id');
        runBulkAction('d5tm_batch_update', { term_id: termId, tax: 'layout_category' });
    });

    // Bulk Trash
    $(document).on('click', '.d5tm-bulk-trash', function() {
        runBulkAction('d5tm_batch_trash', {}, 'Are you sure you want to move ' + selectedIds.length + ' items to trash?');
    });

    // Bulk Export
    $(document).on('click', '#d5tm-bulk-export', function() {
        if (selectedIds.length === 0) {
            showToast('No layouts selected for export', 'warning');
            return;
        }

        const $btn = $(this);
        $btn.prop('disabled', true).html('<i class="bi bi-arrow-repeat d5tm-spin"></i> Exporting...');

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'd5tm_bulk_export',
                nonce: d5tm_ajax.nonce,
                ids: selectedIds
            },
            success: function(response) {
                if (response.success) {
                    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(response.data.json);
                    const downloadAnchor = document.createElement('a');
                    downloadAnchor.setAttribute("href", dataStr);
                    downloadAnchor.setAttribute("download", response.data.filename);
                    document.body.appendChild(downloadAnchor);
                    downloadAnchor.click();
                    downloadAnchor.remove();
                    showToast('Exported ' + selectedIds.length + ' layouts successfully', 'success');
                } else {
                    showToast(response.data.message || 'Export failed', 'error');
                }
            },
            error: function() {
                showToast('Network error during export', 'error');
            },
            complete: function() {
                $btn.prop('disabled', false).html('<i class="bi bi-file-earmark-arrow-down"></i> Export JSON');
            }
        });
    });

    // --- Unified JSON Inspector & Deep Dive Engine ---
    function renderJsonTree(data, $container) {
        $container.empty();
        const $root = buildTreeNode(data, "Layout Object");
        $container.append($root);
        updateJsonStats();
    }

    function buildTreeNode(val, key, depth) {
        depth = depth || 0;
        const MAX_DEPTH = 15;           // Increased from 12 for deep Divi structures
        const MAX_STRING_LEN = 50000;   // Increased from 5000 to show full Divi content
        const MAX_CHILDREN = 500;       // Increased from 200 for large layouts

        const $node = $('<div class="d5tm-tree-node"></div>');
        let type = typeof val;
        let isDiviBlock = false;

        // 1. Smart Block Detector: If string is a Divi Block, extract and parse it
        if (type === 'string' && val.trim().startsWith('<!-- wp:divi/')) {
            // Improved regex: greedy match for the JSON payload between the block comment markers
            // Uses [^] (any char including newline) instead of . with /s flag for broader compat
            const blockMatch = val.match(/<!--\s*wp:divi\/[^\s]+\s+(\{[\s\S]*\})\s*-->/);
            if (blockMatch && blockMatch[1]) {
                try {
                    // Unescape then parse — handle double-escaped quotes
                    let payloadStr = blockMatch[1].replace(/\\"/g, '"').replace(/\\\\/g, '\\');
                    // Try to find the actual valid JSON boundary (match braces)
                    let braceCount = 0, endIdx = -1;
                    for (let i = 0; i < payloadStr.length; i++) {
                        if (payloadStr[i] === '{') braceCount++;
                        else if (payloadStr[i] === '}') braceCount--;
                        if (braceCount === 0) { endIdx = i; break; }
                    }
                    if (endIdx > 0) {
                        payloadStr = payloadStr.substring(0, endIdx + 1);
                    }
                    const blockData = JSON.parse(payloadStr);
                    val = blockData; // Replace string with expanded object
                    type = 'object';
                    isDiviBlock = true;
                    $node.addClass('is-divi-block');
                } catch(e) {
                    console.log("Failed to deep-parse block: ", e);
                }
            }
        }

        // 2. Nested JSON String Detector (Backup) — try to auto-expand
        if (type === 'string' && depth < MAX_DEPTH && (val.trim().startsWith('{') || val.trim().startsWith('['))) {
            try {
                const parsed = JSON.parse(val);
                val = parsed;
                type = typeof val;
                $node.addClass('deep-parsed');
            } catch(e) {}
        }

        // 3. Handle Divi block content strings: detect multi-block content and show as expandable
        if (type === 'string' && val.indexOf('<!-- wp:') !== -1 && val.indexOf('-->') !== -1) {
            // This is a content string with one or more Gutenberg/Divi blocks
            // Parse all blocks and create a virtual object
            const blockRegex = /<!--\s*wp:([^\s]+)\s+(\{[\s\S]*?\})?\s*-->[\s\S]*?<!--\s*\/wp:\1\s*-->/g;
            let match;
            let blockIndex = 0;
            const blocks = {};
            const fullBlockRegex = /<!--\s*wp:([^\s\/]+)[^>]*-->[\s\S]*?<!--\s*\/wp:\1\s*-->/g;
            while ((match = fullBlockRegex.exec(val)) !== null) {
                const blockName = match[1];
                let blockData = null;
                // Try to parse the attributes
                const attrMatch = match[0].match(/<!--\s*wp:[^\s]+\s+(\{[\s\S]*?\})\s*-->/);
                if (attrMatch && attrMatch[1]) {
                    try {
                        let attrStr = attrMatch[1].replace(/\\"/g, '"').replace(/\\\\/g, '\\');
                        let braceCount = 0, endIdx = -1;
                        for (let i = 0; i < attrStr.length; i++) {
                            if (attrStr[i] === '{') braceCount++;
                            else if (attrStr[i] === '}') braceCount--;
                            if (braceCount === 0) { endIdx = i; break; }
                        }
                        if (endIdx > 0) attrStr = attrStr.substring(0, endIdx + 1);
                        blockData = JSON.parse(attrStr);
                    } catch(e) {}
                }
                blocks['Block ' + blockIndex + ': ' + blockName] = blockData || { _raw_length: match[0].length, _type: blockName };
                blockIndex++;
            }
            if (Object.keys(blocks).length > 0) {
                val = blocks;
                type = 'object';
                $node.addClass('is-divi-block');
            }
        }

        const isExpandable = (val !== null && type === 'object' && depth < MAX_DEPTH);

        if (isExpandable) {
            const $toggle = $('<span class="d5tm-tree-toggle"><i class="bi bi-caret-down-fill"></i></span>');
            $node.append($toggle);
            $toggle.on('click', function(e) { e.stopPropagation(); $node.toggleClass('collapsed'); });
        }

        if (key !== null) {
            $node.append('<span class="d5tm-tree-key">' + escapeHtml(String(key)) + '</span>');
        }

        if (val === null) {
            $node.append('<span class="d5tm-tree-null">null</span>');
        } else if (type === 'object') {
            const isArray = Array.isArray(val);
            const keys = Object.keys(val);
            const keyCount = keys.length;
            $node.append('<span class="d5tm-tree-bracket">' + (isArray ? '[' : '{') + '</span>');
            $node.append('<span class="d5tm-tree-summary">' + keyCount + ' item' + (keyCount !== 1 ? 's' : '') + '</span>');

            const $children = $('<div class="d5tm-tree-children"></div>');
            const renderCount = Math.min(keyCount, MAX_CHILDREN);
            for (let i = 0; i < renderCount; i++) {
                $children.append(buildTreeNode(val[keys[i]], keys[i], depth + 1));
            }
            if (keyCount > MAX_CHILDREN) {
                $children.append('<div class="d5tm-tree-node"><span class="d5tm-tree-summary" style="color:#f59e0b;">... and ' + (keyCount - MAX_CHILDREN) + ' more items (truncated)</span></div>');
            }
            $node.append($children);
            $node.append('<div class="d5tm-tree-bracket">' + (isArray ? ']' : '}') + '</div>');
        } else {
            let displayVal;
            if (type === 'string') {
                // Show more content in tree - use expandable for very long strings
                if (val.length > MAX_STRING_LEN) {
                    displayVal = '"' + escapeHtml(val.substring(0, MAX_STRING_LEN)) + '…" <span class="d5tm-tree-summary">(' + val.length + ' chars)</span>';
                } else if (val.length > 2000) {
                    // For strings between 2000-50000 chars, show first 2000 with expand button
                    displayVal = '"' + escapeHtml(val.substring(0, 2000)) + '…" <button class="d5tm-expand-content-btn" data-full="' + escapeAttr(val) + '">Show Full (' + val.length + ' chars)</button>';
                } else {
                    displayVal = '"' + escapeHtml(val) + '"';
                }
            } else {
                displayVal = escapeHtml(String(val));
            }
            $node.append('<span class="d5tm-tree-' + type + '">' + displayVal + '</span>');
        }

        return $node;
    }

    // HTML escape helper for safe tree rendering
    function escapeHtml(text) {
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }

    function updateJsonStats() {
        const nodes = $('.d5tm-tree-node').length;
        const blocks = $('.is-divi-block').length;
        $('#d5tm-json-stats').text(nodes + ' Nodes \u2022 ' + blocks + ' Divi Blocks Expanded');
    }

    // JSON View Mode Tabs (Tree / Table / Chart / Raw)
    let currentJsonData = null; // Store parsed JSON for all views

    $(document).on('click', '.d5tm-json-view-tab', function() {
        const $tab = $(this);
        const view = $tab.data('view');

        $('.d5tm-json-view-tab').removeClass('active');
        $tab.addClass('active');

        // Hide all views
        $('#d5tm-json-tree-container').removeClass('active').hide();
        $('#d5tm-json-table-view').removeClass('active').hide();
        $('#d5tm-json-chart-view').removeClass('active').hide();
        $('#d5tm-json-raw-view').removeClass('active').hide();
        $('#d5tm-json-viewer').hide();

        // Show selected view
        if (view === 'tree') {
            $('#d5tm-json-tree-container').addClass('active').show();
        } else if (view === 'table') {
            $('#d5tm-json-table-view').addClass('active').show();
            if (currentJsonData) renderJsonTable(currentJsonData, $('#d5tm-json-table-view'));
        } else if (view === 'chart') {
            $('#d5tm-json-chart-view').addClass('active').show();
            if (currentJsonData) renderJsonChart(currentJsonData, $('#d5tm-json-chart-view'));
        } else if (view === 'raw') {
            $('#d5tm-json-raw-view').addClass('active').show();
            if (currentJsonData) renderJsonRaw(currentJsonData, $('#d5tm-json-raw-view'));
        }
    });

    // JSON View Button Click
    $(document).on('click', '.d5tm-json-btn', function() {
        const id = $(this).data('id');
        const $modal = $('#d5tm-json-modal');
        const $tree = $('#d5tm-json-tree-container');

        $tree.empty().html('<div class="d5tm-loader-inline"><i class="bi bi-arrow-repeat d5tm-spin"></i> Analyzing metadata...</div>');
        $modal.fadeIn(200).addClass('active');

        // Reset to tree view tab
        $('.d5tm-json-view-tab').removeClass('active');
        $('.d5tm-json-view-tab[data-view="tree"]').addClass('active');

        $.ajax({
            url: d5tm_ajax.ajax_url, type: 'POST',
            data: { action: 'd5tm_get_layout_data', layout_id: id, nonce: d5tm_ajax.nonce },
            success: function(response) {
                if (response.success) {
                    const rawData = response.data.layout_data;
                    try {
                        currentJsonData = JSON.parse(rawData);
                        renderJsonTree(currentJsonData, $tree);
                        // Show tree by default
                        $tree.addClass('active').show();
                        $('#d5tm-json-table-view').removeClass('active').hide();
                        $('#d5tm-json-chart-view').removeClass('active').hide();
                        $('#d5tm-json-raw-view').removeClass('active').hide();
                    } catch(e) {
                        $tree.html('<div class="d5tm-alert d5tm-alert-error">Malformed JSON structure. Using raw view.</div>');
                        currentJsonData = null;
                    }
                }
            }
        });
    });

    // Toolbar Controls
    $('#d5tm-json-expand-all').on('click', function() { $('.d5tm-tree-node').removeClass('collapsed'); });
    $('#d5tm-json-collapse-all').on('click', function() { $('.d5tm-tree-node').addClass('collapsed'); });

    // JSON Search
    $('#d5tm-json-search').on('input', function() {
        const q = $(this).val().toLowerCase();
        $('.d5tm-tree-match').removeClass('d5tm-tree-match');
        if (!q) return;

        $('.d5tm-tree-key, .d5tm-tree-string, .d5tm-tree-number').each(function() {
            const $el = $(this);
            if ($el.text().toLowerCase().includes(q)) {
                $el.addClass('d5tm-tree-match');
                $el.parents('.collapsed').removeClass('collapsed');
            }
        });
    });

    // JSON Copy Button — uses stored data
    $('.d5tm-json-copy-btn').on('click', function() {
        const jsonStr = currentJsonData ? JSON.stringify(currentJsonData, null, 2) : '';
        if (jsonStr && navigator.clipboard) {
            navigator.clipboard.writeText(jsonStr);
        }
        const original = $(this).html();
        $(this).html('<i class="bi bi-check-lg"></i>');
        const $btn = $(this);
        setTimeout(function() { $btn.html(original); }, 2000);
    });

    // ===== JSON Table View Renderer =====
    function renderJsonTable(data, $container) {
        $container.empty();
        const rows = flattenJsonToRows(data, '');
        let html = '<table class="d5tm-json-table"><thead><tr>';
        html += '<th>Key</th><th>Type</th><th>Value</th>';
        html += '</tr></thead><tbody>';
        rows.forEach(function(row) {
            const indent = (row.key.match(/\//g) || []).length;
            const displayKey = row.key.split('/').pop();
            const typeColors = { string: '#ce9178', number: '#b5cea8', boolean: '#569cd6', null: '#569cd6', object: '#ffd700', array: '#ffd700' };
            const typeColor = typeColors[row.type] || '#d4d4d4';
            let displayVal = row.value;
            if (row.type === 'string' && displayVal.length > 200) {
                displayVal = escapeHtml(displayVal.substring(0, 200)) + '... <button class="d5tm-expand-content-btn" data-full="' + escapeAttr(row.value) + '">Show Full (' + row.value.length + ' chars)</button>';
            } else {
                displayVal = escapeHtml(displayVal);
            }
            html += '<tr>';
            html += '<td class="d5tm-table-key" style="padding-left:' + (12 + indent * 16) + 'px;">' + escapeHtml(displayKey) + '</td>';
            html += '<td class="d5tm-table-type" style="color:' + typeColor + ';">' + row.type + '</td>';
            html += '<td>' + displayVal + '</td>';
            html += '</tr>';
        });
        html += '</tbody></table>';
        $container.html(html);
    }

    function flattenJsonToRows(val, prefix) {
        const rows = [];
        if (val === null) {
            rows.push({ key: prefix || '(root)', type: 'null', value: 'null' });
        } else if (typeof val === 'object') {
            const keys = Object.keys(val);
            keys.forEach(function(k) {
                const fullKey = prefix ? prefix + '/' + k : k;
                if (val[k] !== null && typeof val[k] === 'object' && !Array.isArray(val[k]) && Object.keys(val[k]).length > 0 && Object.keys(val[k]).length < 20) {
                    rows.push.apply(rows, flattenJsonToRows(val[k], fullKey));
                } else {
                    let type = typeof val[k];
                    if (val[k] === null) type = 'null';
                    else if (Array.isArray(val[k])) type = 'array';
                    else if (typeof val[k] === 'object') type = 'object';
                    let displayVal = '';
                    if (val[k] === null) displayVal = 'null';
                    else if (typeof val[k] === 'object') displayVal = JSON.stringify(val[k]).substring(0, 300) + (JSON.stringify(val[k]).length > 300 ? '...' : '');
                    else displayVal = String(val[k]);
                    rows.push({ key: fullKey, type: type, value: displayVal });
                }
            });
        } else {
            rows.push({ key: prefix || '(root)', type: typeof val, value: String(val) });
        }
        return rows;
    }

    // Handle "Show Full" content expansion in table view
    $(document).on('click', '.d5tm-expand-content-btn', function() {
        const $btn = $(this);
        const fullText = $btn.attr('data-full');
        const $td = $btn.parent();
        $td.html('<pre style="white-space:pre-wrap;word-break:break-all;font-size:12px;max-height:300px;overflow-y:auto;background:var(--bg-3);padding:10px;border-radius:6px;margin:0;">' + escapeHtml(fullText) + '</pre>');
    });

    // ===== JSON Chart View Renderer =====
    function renderJsonChart(data, $container) {
        $container.empty();
        const modules = extractDiviModules(data);
        const total = modules.reduce(function(sum, m) { return sum + m.count; }, 0);

        if (modules.length === 0) {
            $container.html('<div style="text-align:center;padding:40px;color:var(--text-3);"><i class="bi bi-bar-chart" style="font-size:32px;display:block;margin-bottom:12px;"></i>No Divi modules detected in this layout.</div>');
            return;
        }

        const colors = ['#6366f1', '#ec4899', '#f59e0b', '#10b981', '#06b6d4', '#3b82f6', '#8b5cf6', '#ef4444', '#f97316', '#84cc16'];
        let html = '<h4 style="margin:0 0 16px;color:var(--text-2);font-size:0.9rem;"><i class="bi bi-bar-chart-line"></i> Module Distribution</h4>';
        html += '<div class="d5tm-json-chart-modules">';
        modules.forEach(function(mod, i) {
            const pct = Math.round((mod.count / total) * 100);
            const color = colors[i % colors.length];
            html += '<div class="d5tm-chart-module">';
            html += '<span class="d5tm-chart-module-name">' + escapeHtml(mod.name) + '</span>';
            html += '<div class="d5tm-chart-module-bar-wrap"><div class="d5tm-chart-module-bar" style="width:' + pct + '%;background:' + color + ';">' + (pct > 10 ? pct + '%' : '') + '</div></div>';
            html += '<span class="d5tm-chart-module-count">' + mod.count + '</span>';
            html += '</div>';
        });
        html += '</div>';

        // Structure summary
        html += '<div style="margin-top:24px;padding:16px;background:var(--bg-3);border-radius:8px;border:1px solid var(--border);">';
        html += '<h4 style="margin:0 0 10px;color:var(--text-2);font-size:0.85rem;"><i class="bi bi-info-circle"></i> Structure Summary</h4>';
        html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">';
        html += '<div style="font-size:0.82rem;color:var(--text-3);">Total Modules</div><div style="font-size:0.82rem;font-weight:600;color:var(--text);">' + total + '</div>';
        html += '<div style="font-size:0.82rem;color:var(--text-3);">Unique Types</div><div style="font-size:0.82rem;font-weight:600;color:var(--text);">' + modules.length + '</div>';
        html += '<div style="font-size:0.82rem;color:var(--text-3);">Content Size</div><div style="font-size:0.82rem;font-weight:600;color:var(--text);">' + formatBytes(JSON.stringify(data).length) + '</div>';
        html += '</div></div>';

        $container.html(html);
    }

    function extractDiviModules(data) {
        const moduleCounts = {};
        function walk(val) {
            if (!val || typeof val !== 'object') return;
            if (val.attrs && val.attrs.name) {
                const name = val.attrs.name || val.attrs.moduleName || 'Unknown';
                moduleCounts[name] = (moduleCounts[name] || 0) + 1;
            }
            // Also check for wp:divi blocks in content strings
            if (typeof val === 'string' && val.indexOf('<!-- wp:divi/') !== -1) {
                const blockMatches = val.match(/<!--\s*wp:divi\/([^\s]+)/g);
                if (blockMatches) {
                    blockMatches.forEach(function(m) {
                        const name = m.replace('<!-- wp:divi/', '').trim();
                        moduleCounts[name] = (moduleCounts[name] || 0) + 1;
                    });
                }
            }
            Object.keys(val).forEach(function(k) { walk(val[k]); });
        }
        walk(data);
        // Sort by count desc
        return Object.keys(moduleCounts)
            .map(function(name) { return { name: name, count: moduleCounts[name] }; })
            .sort(function(a, b) { return b.count - a.count; })
            .slice(0, 20); // Top 20
    }

    function formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    // ===== JSON Raw View Renderer =====
    function renderJsonRaw(data, $container) {
        $container.empty();
        const jsonStr = JSON.stringify(data, null, 2);
        const lines = jsonStr.split('\n');
        let html = '<pre>';
        lines.forEach(function(line, i) {
            html += '<span class="d5tm-json-line-num">' + (i + 1) + '</span>' + syntaxHighlightLine(escapeHtml(line)) + '\n';
        });
        html += '</pre>';
        $container.html(html);
    }

    function syntaxHighlightLine(line) {
        // Simple syntax highlighting for JSON
        return line
            .replace(/"([^"]+)"(\s*:)/g, '<span style="color:#9cdcfe;">"$1"</span>$2')
            .replace(/:\s*"([^"]*)"/g, ': <span style="color:#ce9178;">"$1"</span>')
            .replace(/:\s*(\d+\.?\d*)/g, ': <span style="color:#b5cea8;">$1</span>')
            .replace(/:\s*(true|false)/g, ': <span style="color:#569cd6;">$1</span>')
            .replace(/:\s*(null)/g, ': <span style="color:#569cd6;font-style:italic;">$1</span>');
    }

    function escapeAttr(text) {
        return text.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#039;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    // JSON Modal Close
    $('#d5tm-json-close-btn, #d5tm-json-ok-btn').on('click', function() {
        $('#d5tm-json-modal').fadeOut(200).removeClass('active');
    });

    // ===== Design Extract Feature (v3.7.0) =====
    $(document).on('click', '.d5tm-design-extract-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();

        const $card = $(this).closest('.d5tm-card');
        const layoutId = $card.data('layout-id');
        const $modal = $('#d5tm-design-extract-modal');

        // Show modal with loading
        $modal.addClass('active');
        $('#d5tm-de-content').html('<div style="text-align:center;padding:40px;"><i class="bi bi-arrow-repeat d5tm-spin" style="font-size:24px;"></i><p style="margin-top:12px;color:var(--text-3);">Extracting design data...</p></div>');

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'd5tm_get_layout_data',
                nonce: d5tm_ajax.nonce,
                layout_id: layoutId
            },
            success: function(response) {
                if (response.success) {
                    try {
                        const data = JSON.parse(response.data.layout_data);
                        renderDesignExtract(data, $('#d5tm-de-content'));
                    } catch(e) {
                        $('#d5tm-de-content').html('<div style="text-align:center;padding:40px;color:#ef4444;"><i class="bi bi-exclamation-triangle" style="font-size:24px;"></i><p>Failed to parse layout data.</p></div>');
                    }
                }
            },
            error: function() {
                $('#d5tm-de-content').html('<div style="text-align:center;padding:40px;color:#ef4444;"><i class="bi bi-exclamation-triangle" style="font-size:24px;"></i><p>Network error.</p></div>');
            }
        });
    });

    function renderDesignExtract(data, $container) {
        const colors = extractColors(data);
        const fonts = extractFonts(data);
        const modules = extractDiviModules(data);

        let html = '';

        // Color Palette Section
        html += '<div class="d5tm-de-section">';
        html += '<div class="d5tm-de-section-title"><i class="bi bi-palette"></i> Color Palette (' + colors.length + ')</div>';
        if (colors.length > 0) {
            html += '<div class="d5tm-de-colors-grid">';
            colors.forEach(function(color) {
                const textColor = isLightColor(color) ? '#000' : '#fff';
                html += '<div class="d5tm-de-color-swatch" style="background:' + color + ';" data-hex="' + color + '" data-tooltip="Click to copy ' + color + '" onclick="navigator.clipboard.writeText(\'' + color + '\');this.style.transform=\'scale(1.2)\';setTimeout(()=>this.style.transform=\'\',300);"></div>';
            });
            html += '</div>';
        } else {
            html += '<p style="color:var(--text-3);font-size:0.85rem;">No colors detected in this layout.</p>';
        }
        html += '</div>';

        // Fonts Section
        html += '<div class="d5tm-de-section">';
        html += '<div class="d5tm-de-section-title"><i class="bi bi-type"></i> Fonts Used (' + fonts.length + ')</div>';
        if (fonts.length > 0) {
            html += '<div class="d5tm-de-fonts-list">';
            fonts.forEach(function(font) {
                html += '<div class="d5tm-de-font-item">';
                html += '<span class="d5tm-de-font-preview" style="font-family:\'' + escapeHtml(font) + '\',sans-serif;">The quick brown fox</span>';
                html += '<span class="d5tm-de-font-name">' + escapeHtml(font) + '</span>';
                html += '</div>';
            });
            html += '</div>';
        } else {
            html += '<p style="color:var(--text-3);font-size:0.85rem;">No custom fonts detected.</p>';
        }
        html += '</div>';

        // Module Breakdown Section
        html += '<div class="d5tm-de-section">';
        html += '<div class="d5tm-de-section-title"><i class="bi bi-boxes"></i> Module Breakdown</div>';
        if (modules.length > 0) {
            const total = modules.reduce(function(s, m) { return s + m.count; }, 0);
            const colors = ['#6366f1', '#ec4899', '#f59e0b', '#10b981', '#06b6d4', '#3b82f6', '#8b5cf6', '#ef4444', '#f97316', '#84cc16'];
            html += '<div class="d5tm-de-modules-chart">';
            modules.forEach(function(mod, i) {
                const pct = Math.round((mod.count / total) * 100);
                const color = colors[i % colors.length];
                html += '<div class="d5tm-de-module-row">';
                html += '<span class="d5tm-de-module-name">' + escapeHtml(mod.name) + '</span>';
                html += '<div class="d5tm-de-module-bar-wrap"><div class="d5tm-de-module-bar" style="width:' + pct + '%;background:' + color + ';"></div></div>';
                html += '<span class="d5tm-de-module-count">' + mod.count + '</span>';
                html += '</div>';
            });
            html += '</div>';
        } else {
            html += '<p style="color:var(--text-3);font-size:0.85rem;">No Divi modules detected.</p>';
        }
        html += '</div>';

        $container.html(html);
    }

    function extractColors(data) {
        const colorSet = {};
        const colorRegex = /#[0-9a-fA-F]{3,8}/g;
        const rgbaRegex = /rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+/g;

        function walkColors(val) {
            if (!val || typeof val !== 'object' && typeof val !== 'string') return;
            if (typeof val === 'string') {
                // Extract hex colors
                const hexMatches = val.match(colorRegex);
                if (hexMatches) {
                    hexMatches.forEach(function(c) {
                        // Normalize 3-digit hex to 6-digit
                        if (c.length === 4) {
                            colorSet['#' + c[1]+c[1]+c[2]+c[2]+c[3]+c[3]] = true;
                        } else {
                            colorSet[c.toLowerCase()] = true;
                        }
                    });
                }
                // Extract rgb/rgba colors
                const rgbMatches = val.match(rgbaRegex);
                if (rgbMatches) {
                    rgbMatches.forEach(function(c) {
                        const nums = c.match(/\d+/g);
                        if (nums && nums.length >= 3) {
                            const hex = '#' + parseInt(nums[0]).toString(16).padStart(2,'0') + parseInt(nums[1]).toString(16).padStart(2,'0') + parseInt(nums[2]).toString(16).padStart(2,'0');
                            colorSet[hex] = true;
                        }
                    });
                }
                return;
            }
            if (typeof val === 'object') {
                // Specifically check known Divi color attribute keys
                const colorKeys = ['background_color', 'background_color__hover', 'text_color', 'text_color__hover', 'button_bg_color', 'button_text_color', 'link_color', 'overlay_color', 'border_color', 'header_bg_color', 'body_bg_color', 'accent_color'];
                Object.keys(val).forEach(function(k) {
                    if (colorKeys.indexOf(k) !== -1 && typeof val[k] === 'string' && val[k]) {
                        const hex = val[k].match(colorRegex);
                        if (hex) hex.forEach(function(c) { colorSet[c.toLowerCase()] = true; });
                    }
                    walkColors(val[k]);
                });
            }
        }
        walkColors(data);

        // Filter out common black/white/transparent and very short colors
        return Object.keys(colorSet).filter(function(c) {
            const lower = c.toLowerCase();
            return lower !== '#000' && lower !== '#000000' && lower !== '#fff' && lower !== '#ffffff' && lower !== '#00000000' && c.length >= 7;
        }).sort();
    }

    function extractFonts(data) {
        const fontSet = {};
        const fontRegex = /font[_-]?family[_a-z]*|header[_-]?font|body[_-]?font|title[_-]?font/gi;

        function walkFonts(val, key) {
            if (!val) return;
            if (typeof val === 'string') {
                if (key && key.match(fontRegex) && val && val !== 'inherit' && val !== 'none') {
                    // Clean up font value (remove fallbacks, quotes)
                    const primaryFont = val.split(',')[0].replace(/['"]/g, '').trim();
                    if (primaryFont) fontSet[primaryFont] = true;
                }
                return;
            }
            if (typeof val === 'object') {
                Object.keys(val).forEach(function(k) { walkFonts(val[k], k); });
            }
        }
        walkFonts(data, null);
        return Object.keys(fontSet);
    }

    function isLightColor(hex) {
        hex = hex.replace('#', '');
        if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
        const r = parseInt(hex.substring(0,2), 16);
        const g = parseInt(hex.substring(2,4), 16);
        const b = parseInt(hex.substring(4,6), 16);
        return (r * 299 + g * 587 + b * 114) / 1000 > 128;
    }

    // Design Extract Modal Close
    $('#d5tm-de-close-btn').on('click', function() {
        $('#d5tm-design-extract-modal').removeClass('active');
    });

    // ===== View Mode Toggle (Grid / List / Gallery) =====
    $(document).on('click', '.d5tm-view-btn', function() {
        const view = $(this).data('view');
        $('.d5tm-view-btn').removeClass('active');
        $(this).addClass('active');

        const $grid = $('#d5tm-grid');
        $grid.removeClass('d5tm-view-list d5tm-view-gallery');

        if (view === 'list') {
            $grid.addClass('d5tm-view-list');
        } else if (view === 'gallery') {
            $grid.addClass('d5tm-view-gallery');
        }
        // Grid is the default (no class needed)

        localStorage.setItem('d5tm_view_mode', view);
    });

    // Restore saved view mode
    const savedViewMode = localStorage.getItem('d5tm_view_mode') || 'grid';
    if (savedViewMode !== 'grid') {
        const $viewBtn = $('.d5tm-view-btn[data-view="' + savedViewMode + '"]');
        if ($viewBtn.length) {
            $viewBtn.trigger('click');
        }
    }

    // ===== Mobile Sidebar Toggle =====
    $('#d5tm-mobile-menu-toggle').on('click', function() {
        $('#d5tm-sidebar').toggleClass('d5tm-sidebar-open');
    });

    // Close sidebar when clicking outside on mobile
    $(document).on('click', function(e) {
        if ($(window).width() <= 900) {
            if (!$(e.target).closest('#d5tm-sidebar, #d5tm-mobile-menu-toggle').length) {
                $('#d5tm-sidebar').removeClass('d5tm-sidebar-open');
            }
        }
    });

    // ===== Sidebar Search Filter =====
    $('#d5tm-sidebar-search-input').on('input', function() {
        const term = $(this).val().trim().toLowerCase();
        $('.d5tm-sidebar-item-wrap').each(function() {
            const text = $(this).text().toLowerCase();
            $(this).toggle(text.indexOf(term) !== -1);
        });
        // Also show/hide section labels based on visible items
        $('.d5tm-sidebar-section').each(function() {
            const visibleItems = $(this).find('.d5tm-sidebar-item-wrap:visible').length;
            const hasLabel = $(this).find('.d5tm-sidebar-label').length > 0;
            if (hasLabel && term) {
                $(this).toggle(visibleItems > 0);
            } else {
                $(this).show();
            }
        });
    });

    // ===== Favorite Toggle (v3.6.0) =====
    $(document).on('click', '.d5tm-fav-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();

        const $btn = $(this);
        const layoutId = $btn.data('id');

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'd5tm_toggle_favorite',
                nonce: d5tm_ajax.nonce,
                layout_id: layoutId
            },
            success: function(response) {
                if (response.success) {
                    const isFav = response.data.favorite;
                    $btn.toggleClass('is-fav', isFav);
                    $btn.find('i').attr('class', isFav ? 'bi bi-star-fill' : 'bi bi-star');

                    // Update card data attribute
                    const $card = $btn.closest('.d5tm-card');
                    $card.attr('data-fav', isFav ? '1' : '0');

                    // Pop animation
                    $btn.addClass('pop');
                    setTimeout(function() { $btn.removeClass('pop'); }, 350);

                    // Toast
                    showToast(response.data.message, 'success', 2000);

                    // Update sidebar count
                    const favCount = $('.d5tm-card[data-fav="1"]:visible').length;
                    $('.d5tm-sidebar-fav-link .d5tm-sidebar-count').text(favCount);
                }
            },
            error: function() {
                showToast('Failed to toggle favorite', 'error');
            }
        });
    });

    // ===== Stats Tab =====
    let statsLoaded = false;

    // When stats tab is clicked, load data
    $(document).on('click', '.d5tm-htab[data-target="stats-tab"]', function() {
        if (!statsLoaded) {
            loadStats();
            statsLoaded = true;
        }
    });

    function loadStats() {
        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'd5tm_get_stats',
                nonce: d5tm_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    renderStats(response.data.stats);
                }
            },
            error: function() {
                showToast('Failed to load statistics', 'error');
            }
        });
    }

    function renderStats(stats) {
        $('#d5tm-stats-loading').hide();
        $('#d5tm-stats-content').show();

        // Overview numbers
        $('#d5tm-stat-total').text(stats.total);
        $('#d5tm-stat-published').text(stats.published);
        $('#d5tm-stat-draft').text(stats.draft);
        $('#d5tm-stat-trash').text(stats.trash);

        // Category bars
        const maxCatCount = Math.max(...stats.by_category.map(c => c.count), 1);
        let catHtml = '';
        stats.by_category.forEach(cat => {
            const pct = Math.round((cat.count / maxCatCount) * 100);
            catHtml += '<div class="d5tm-stats-bar-row">' +
                '<span class="d5tm-stats-bar-label">' + cat.name + '</span>' +
                '<div class="d5tm-stats-bar-track"><div class="d5tm-stats-bar-fill" style="width:' + pct + '%;background:' + cat.color + ';"></div></div>' +
                '<span class="d5tm-stats-bar-count">' + cat.count + '</span>' +
            '</div>';
        });
        $('#d5tm-stats-categories').html(catHtml || '<p style="color:var(--text-3)">No categories found</p>');

        // Type bars
        const maxTypeCount = Math.max(...stats.by_type.map(t => t.count), 1);
        let typeHtml = '';
        stats.by_type.forEach(type => {
            const pct = Math.round((type.count / maxTypeCount) * 100);
            typeHtml += '<div class="d5tm-stats-bar-row">' +
                '<span class="d5tm-stats-bar-label"><i class="bi ' + type.icon + '"></i> ' + type.name + '</span>' +
                '<div class="d5tm-stats-bar-track"><div class="d5tm-stats-bar-fill" style="width:' + pct + '%;"></div></div>' +
                '<span class="d5tm-stats-bar-count">' + type.count + '</span>' +
            '</div>';
        });
        $('#d5tm-stats-types').html(typeHtml || '<p style="color:var(--text-3)">No types found</p>');

        // Monthly bars
        const maxMonthCount = Math.max(...stats.by_month.map(m => m.count), 1);
        let monthHtml = '';
        stats.by_month.slice().reverse().forEach(month => {
            const pct = Math.round((month.count / maxMonthCount) * 100);
            monthHtml += '<div class="d5tm-stats-bar-row">' +
                '<span class="d5tm-stats-bar-label">' + month.label + '</span>' +
                '<div class="d5tm-stats-bar-track"><div class="d5tm-stats-bar-fill d5tm-stats-bar-monthly" style="width:' + pct + '%;"></div></div>' +
                '<span class="d5tm-stats-bar-count">' + month.count + '</span>' +
            '</div>';
        });
        $('#d5tm-stats-monthly').html(monthHtml);

        // Recent layouts
        let recentHtml = '';
        stats.recent.forEach(r => {
            const statusBadge = r.status === 'publish' ? 'd5tm-stats-badge-publish' : (r.status === 'draft' ? 'd5tm-stats-badge-draft' : 'd5tm-stats-badge-trash');
            recentHtml += '<div class="d5tm-stats-recent-item">' +
                '<span class="d5tm-stats-recent-title">' + r.title + '</span>' +
                '<span class="d5tm-stats-badge ' + statusBadge + '">' + r.status + '</span>' +
                '<span class="d5tm-stats-recent-date">' + r.date + '</span>' +
            '</div>';
        });
        $('#d5tm-stats-recent').html(recentHtml || '<p style="color:var(--text-3)">No layouts yet</p>');
    }


    // ===== Low-Quality Progressive Preview =====
    // Intersection Observer for lazy loading with blur-up effect
    (function() {
        var lowqObserver = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    var img = entry.target;
                    var fullSrc = img.getAttribute('data-full-src');
                    
                    if (fullSrc && img.classList.contains('d5tm-thumb-lowq')) {
                        // Preload full-res image
                        var preloader = new Image();
                        preloader.onload = function() {
                            img.src = fullSrc;
                            img.classList.add('d5tm-thumb-loaded');
                        };
                        preloader.onerror = function() {
                            // If full-res fails, still show medium quality
                            img.classList.add('d5tm-thumb-loaded');
                        };
                        preloader.src = fullSrc;
                    } else {
                        img.classList.add('d5tm-thumb-loaded');
                    }
                    
                    lowqObserver.unobserve(img);
                }
            });
        }, { rootMargin: '100px' });
        
        // Observe all thumbnail images
        $(document).ready(function() {
            document.querySelectorAll('.d5tm-thumb-img').forEach(function(img) {
                // For low-quality images, show blur immediately
                if (img.classList.contains('d5tm-thumb-lowq')) {
                    img.classList.add('d5tm-thumb-loaded'); // Show blurred version immediately
                }
                lowqObserver.observe(img);
            });
        });
    })();

    // ============================================================
    // v3.7 — Feature #6: Layout Health Check, Keyboard Navigation, Bulk Rename
    // ============================================================

    // ===== Layout Health Check =====
    const $healthOverlay = $('#d5tm-health-overlay');
    const $healthLoading = $('#d5tm-health-loading');
    const $healthResults = $('#d5tm-health-results');

    function runHealthCheck() {
        $healthLoading.show();
        $healthResults.hide();
        $healthOverlay.addClass('active');

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'd5tm_health_check',
                nonce: d5tm_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    const r = response.data.results;
                    const pct = r.total > 0 ? Math.round((r.healthy / r.total) * 100) : 100;

                    $('#d5tm-health-pct').text(pct + '%');
                    $('#d5tm-health-healthy').text(r.healthy);
                    $('#d5tm-health-total').text(r.total);

                    // Empty content
                    $('#d5tm-health-empty-count').text(r.empty_content.length + ' layout' + (r.empty_content.length !== 1 ? 's' : ''));
                    renderHealthList('#d5tm-health-empty-list', r.empty_content);

                    // No category
                    $('#d5tm-health-nocat-count').text(r.no_category.length + ' layout' + (r.no_category.length !== 1 ? 's' : ''));
                    renderHealthList('#d5tm-health-nocat-list', r.no_category);

                    // Oversized
                    $('#d5tm-health-oversized-count').text(r.oversized.length + ' layout' + (r.oversized.length !== 1 ? 's' : ''));
                    var oversizedHtml = '';
                    r.oversized.forEach(function(item) {
                        oversizedHtml += '<li><a href="#" class="d5tm-health-jump" data-id="' + item.id + '">' + item.title + '</a> <span style="color:var(--text-3);font-size:0.78rem;">(' + item.size + ')</span></li>';
                    });
                    $('#d5tm-health-oversized-list').html(oversizedHtml);

                    // No type
                    $('#d5tm-health-notype-count').text(r.no_type.length + ' layout' + (r.no_type.length !== 1 ? 's' : ''));
                    renderHealthList('#d5tm-health-notype-list', r.no_type);

                    // Color the score ring
                    var $ring = $('.d5tm-health-score-ring');
                    $ring.removeClass('d5tm-health-good d5tm-health-warn d5tm-health-bad');
                    if (pct >= 80) $ring.addClass('d5tm-health-good');
                    else if (pct >= 50) $ring.addClass('d5tm-health-warn');
                    else $ring.addClass('d5tm-health-bad');

                    $healthLoading.hide();
                    $healthResults.show();
                } else {
                    showToast(response.data.message || 'Health check failed', 'error');
                    $healthOverlay.removeClass('active');
                }
            },
            error: function() {
                showToast('Network error during health check', 'error');
                $healthOverlay.removeClass('active');
            }
        });
    }

    function renderHealthList(selector, items) {
        var html = '';
        items.forEach(function(item) {
            html += '<li><a href="#" class="d5tm-health-jump" data-id="' + item.id + '">' + item.title + '</a></li>';
        });
        $(selector).html(html);
    }

    // Open health check from toolbar button
    $(document).on('click', '.d5tm-action-health-check', function(e) {
        e.preventDefault();
        runHealthCheck();
    });

    // Re-check button
    $('#d5tm-health-recheck').on('click', function() {
        runHealthCheck();
    });

    // Close health check
    $('#d5tm-health-close, #d5tm-health-done').on('click', function() {
        $healthOverlay.removeClass('active');
    });

    $healthOverlay.on('click', function(e) {
        if ($(e.target).is($healthOverlay)) {
            $healthOverlay.removeClass('active');
        }
    });

    // Health check: jump to a layout card
    $(document).on('click', '.d5tm-health-jump', function(e) {
        e.preventDefault();
        var id = $(this).data('id');
        $healthOverlay.removeClass('active');
        var $card = $('.d5tm-card[data-layout-id="' + id + '"]');
        if ($card.length) {
            // Make sure it's visible
            if ($card.is(':hidden')) {
                // Reset filters
                searchTerm = '';
                activeFilterVal = 'all';
                activeFilterType = 'cat';
                $('.d5tm-sidebar-link').removeClass('active');
                $('.d5tm-sidebar-link[data-filter-val="all"]').addClass('active');
                applyFilters();
            }
            setTimeout(function() {
                $card[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
                $card.addClass('d5tm-card-focused');
                setTimeout(function() { $card.removeClass('d5tm-card-focused'); }, 2000);
            }, 300);
        }
    });

    // ===== Keyboard Navigation =====
    var focusedCardIndex = -1;

    $(document).on('keydown', function(e) {
        var tag = document.activeElement.tagName.toLowerCase();
        if (tag === 'input' || tag === 'textarea' || tag === 'select') return;

        var $visibleCards = $('.d5tm-card:visible');
        if (!$visibleCards.length) return;

        // Arrow Down / Arrow Right — next card
        if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
            e.preventDefault();
            focusedCardIndex = Math.min(focusedCardIndex + 1, $visibleCards.length - 1);
            focusCard($visibleCards, focusedCardIndex);
        }

        // Arrow Up / Arrow Left — previous card
        if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
            e.preventDefault();
            focusedCardIndex = Math.max(focusedCardIndex - 1, 0);
            focusCard($visibleCards, focusedCardIndex);
        }

        // Enter — open preview of focused card
        if (e.key === 'Enter' && focusedCardIndex >= 0) {
            e.preventDefault();
            var $card = $visibleCards.eq(focusedCardIndex);
            $card.find('.d5tm-action-live-preview').trigger('click');
        }

        // Escape — close any open modal
        if (e.key === 'Escape') {
            var $activeModal = $('.d5tm-modal-overlay.active');
            if ($activeModal.length) {
                $activeModal.removeClass('active');
            }
        }
    });

    function focusCard($cards, index) {
        $cards.removeClass('d5tm-card-focused');
        var $card = $cards.eq(index);
        $card.addClass('d5tm-card-focused');
        $card[0].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    // Reset focus index when filters change
    $(document).on('click', '.d5tm-sidebar-link, .d5tm-clickable-filter', function() {
        focusedCardIndex = -1;
    });
    $('#d5tm-search-input').on('input', function() {
        focusedCardIndex = -1;
    });

    // ===== Bulk Rename =====
    var $renameOverlay = $('#d5tm-rename-overlay');

    // Open rename modal
    $(document).on('click', '#d5tm-bulk-rename', function() {
        var selectedIds = [];
        $('.d5tm-card-checkbox:checked').each(function() {
            selectedIds.push($(this).val());
        });
        if (selectedIds.length === 0) {
            showToast('Please select layouts first.', 'warning');
            return;
        }
        $('#d5tm-rename-count').text(selectedIds.length);
        // Reset form
        $('#d5tm-rename-mode').val('prefix').trigger('change');
        $('#d5tm-rename-value').val('');
        $('#d5tm-rename-replace').val('');
        $('#d5tm-rename-status').text('');
        $renameOverlay.addClass('active');
    });

    // Mode change handler
    $(document).on('change', '#d5tm-rename-mode', function() {
        var mode = $(this).val();
        if (mode === 'replace') {
            $('#d5tm-rename-value-label').text('Find Text');
            $('#d5tm-rename-value').attr('placeholder', 'Text to find...');
            $('#d5tm-rename-replace-group').show();
        } else if (mode === 'suffix') {
            $('#d5tm-rename-value-label').text('Suffix Text');
            $('#d5tm-rename-value').attr('placeholder', 'Enter suffix...');
            $('#d5tm-rename-replace-group').hide();
        } else {
            $('#d5tm-rename-value-label').text('Prefix Text');
            $('#d5tm-rename-value').attr('placeholder', 'Enter prefix...');
            $('#d5tm-rename-replace-group').hide();
        }
    });

    // Close rename modal
    $('#d5tm-rename-close, #d5tm-rename-cancel').on('click', function() {
        $renameOverlay.removeClass('active');
    });

    $renameOverlay.on('click', function(e) {
        if ($(e.target).is($renameOverlay)) {
            $renameOverlay.removeClass('active');
        }
    });

    // Apply rename
    $('#d5tm-rename-apply').on('click', function() {
        var $btn = $(this);
        var selectedIds = [];
        $('.d5tm-card-checkbox:checked').each(function() {
            selectedIds.push(parseInt($(this).val()));
        });

        if (selectedIds.length === 0) {
            showToast('No layouts selected.', 'warning');
            return;
        }

        var mode = $('#d5tm-rename-mode').val();
        var value = $('#d5tm-rename-value').val().trim();
        var replace = $('#d5tm-rename-replace').val().trim();

        if (!value) {
            showToast('Please enter a value.', 'warning');
            return;
        }

        var $status = $('#d5tm-rename-status');
        $btn.prop('disabled', true).html('<i class="bi bi-hourglass-split"></i> Renaming...');
        $status.text('');

        $.ajax({
            url: d5tm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'd5tm_bulk_rename',
                nonce: d5tm_ajax.nonce,
                ids: selectedIds,
                mode: mode,
                value: value,
                replace: replace
            },
            success: function(response) {
                if (response.success) {
                    $status.text(response.data.message).css('color', 'var(--green)');
                    showToast(response.data.message, 'success');

                    // Update card titles in DOM
                    selectedIds.forEach(function(id) {
                        var $card = $('.d5tm-card[data-layout-id="' + id + '"]');
                        if ($card.length) {
                            // Re-fetch title from server would be ideal, but for now
                            // we can calculate it client-side or just reload
                        }
                    });

                    setTimeout(function() {
                        location.reload();
                    }, 1200);
                } else {
                    $status.text(response.data.message).css('color', 'var(--red)');
                    showToast(response.data.message, 'error');
                    $btn.prop('disabled', false).html('<i class="bi bi-check-lg"></i> Apply Rename');
                }
            },
            error: function() {
                $status.text('Network error').css('color', 'var(--red)');
                showToast('Network error during rename', 'error');
                $btn.prop('disabled', false).html('<i class="bi bi-check-lg"></i> Apply Rename');
            }
        });
    });

});
