<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class D5TM_Import_Handler {

    public function __construct() {
        add_action( 'wp_ajax_d5tm_import_layout', array( $this, 'handle_import' ) );
    }

    public function handle_import() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'divi5-tm' ) ) );
        }

        if ( ! isset( $_FILES['file'] ) || $_FILES['file']['error'] !== UPLOAD_ERR_OK ) {
            wp_send_json_error( array( 'message' => __( 'File upload failed.', 'divi5-tm' ) ) );
        }

        $file = $_FILES['file'];
        $ext  = pathinfo( $file['name'], PATHINFO_EXTENSION );

        if ( strtolower( $ext ) !== 'json' ) {
            wp_send_json_error( array( 'message' => __( 'Invalid file type. Please upload a JSON file.', 'divi5-tm' ) ) );
        }

        $json_data = file_get_contents( $file['tmp_name'] );
        $data      = json_decode( $json_data, true );

        if ( json_last_error() !== JSON_ERROR_NONE || empty( $data ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid JSON format.', 'divi5-tm' ) ) );
        }

        $layouts_array = array();
        if ( isset( $data['data']['et_pb_layout'] ) && is_array( $data['data']['et_pb_layout'] ) ) {
            $layouts_array = $data['data']['et_pb_layout'];
        } elseif ( isset( $data['data'] ) && is_array( $data['data'] ) ) {
            $layouts_array = $data['data'];
        }

        $imported_count = 0;

        foreach ( $layouts_array as $layout_id => $layout_data ) {
            if ( ! is_array( $layout_data ) ) continue;

            $title   = isset( $layout_data['post_title'] ) ? $layout_data['post_title'] : ( isset( $layout_data['title'] ) ? $layout_data['title'] : 'Imported Divi 5 Layout' );
            $content = isset( $layout_data['post_content'] ) ? $layout_data['post_content'] : ( isset( $layout_data['content'] ) ? $layout_data['content'] : '' );
            
            $title   = sanitize_text_field( $title );
            $content = wp_slash( $content ); 

            $post_args = array(
                'post_title'   => $title,
                'post_content' => $content,
                'post_status'  => 'publish',
                'post_type'    => 'et_pb_layout',
            );

            $post_id = wp_insert_post( $post_args );

            if ( $post_id && ! is_wp_error( $post_id ) ) {
                if ( isset( $layout_data['post_meta'] ) && is_array( $layout_data['post_meta'] ) ) {
                    $allowed_meta = array(
                        '_et_pb_built_for_post_type',
                        '_et_pb_show_page_creation',
                        '_et_pb_page_layout',
                        '_et_pb_side_nav',
                        '_et_pb_use_builder',
                        '_et_pb_post_type_cache',
                        '_et_pb_layout_type',
                        '_et_pb_template_type',
                        '_et_pb_module_type',
                        '_et_pb_module_is_global',
                    );

                    foreach ( $layout_data['post_meta'] as $meta_key => $meta_values ) {
                        if ( ! in_array( $meta_key, $allowed_meta, true ) ) {
                            continue;
                        }
                        if ( is_array( $meta_values ) ) {
                            foreach ( $meta_values as $val ) {
                                add_post_meta( $post_id, $meta_key, sanitize_text_field( (string) $val ) );
                            }
                        } else {
                            add_post_meta( $post_id, $meta_key, sanitize_text_field( (string) $meta_values ) );
                        }
                    }
                }

                if ( ! get_post_meta( $post_id, '_et_pb_built_for_post_type', true ) ) {
                    update_post_meta( $post_id, '_et_pb_built_for_post_type', 'page' );
                }
                
                $supported_taxes = array( 'layout_category', 'layout_tag', 'layout_type', 'scope', 'module_width' );
                $terms_to_assign = array();

                // 1. "terms" object
                if ( isset( $layout_data['terms'] ) && is_array( $layout_data['terms'] ) ) {
                    foreach ( $layout_data['terms'] as $original_term_id => $term_data ) {
                        if ( ! is_array( $term_data ) || empty( $term_data['name'] ) || empty( $term_data['taxonomy'] ) ) {
                            continue;
                        }

                        $tax = $term_data['taxonomy'];
                        if ( in_array( $tax, $supported_taxes ) && taxonomy_exists( $tax ) ) {
                            $raw_term_name = sanitize_text_field( $term_data['name'] );
                            $names_to_process = ( $tax === 'layout_tag' ) ? explode( ',', $raw_term_name ) : array( $raw_term_name );

                            foreach ( $names_to_process as $term_name ) {
                                $term_name = trim( $term_name );
                                if ( empty( $term_name ) ) continue;

                                $existing = term_exists( $term_name, $tax );
                                if ( ! $existing ) {
                                    $existing = wp_insert_term( $term_name, $tax );
                                }
                                
                                $term_id_to_add = 0;
                                if ( is_array( $existing ) && isset( $existing['term_id'] ) ) {
                                    $term_id_to_add = (int) $existing['term_id'];
                                } elseif ( is_numeric( $existing ) ) {
                                    $term_id_to_add = (int) $existing;
                                }

                                if ( $term_id_to_add > 0 ) {
                                    $terms_to_assign[ $tax ][] = $term_id_to_add;
                                }
                            }
                        }
                    }
                }

                // 2. "tax_input"
                if ( isset( $layout_data['tax_input'] ) && is_array( $layout_data['tax_input'] ) ) {
                    foreach ( $supported_taxes as $tax ) {
                        if ( isset( $layout_data['tax_input'][ $tax ] ) && taxonomy_exists( $tax ) ) {
                            $raw_terms = $layout_data['tax_input'][ $tax ];
                            if ( is_array( $raw_terms ) ) {
                                foreach ( $raw_terms as $term_item ) {
                                    $term_name_raw = is_array( $term_item ) ? ( isset( $term_item['name'] ) ? sanitize_text_field( $term_item['name'] ) : '' ) : sanitize_text_field( (string) $term_item );
                                    if ( ! empty( $term_name_raw ) ) {
                                        $names_to_process = ( $tax === 'layout_tag' ) ? explode( ',', $term_name_raw ) : array( $term_name_raw );
                                        foreach ( $names_to_process as $term_name ) {
                                            $term_name = trim( $term_name );
                                            if ( empty( $term_name ) ) continue;
                                            $existing = term_exists( $term_name, $tax );
                                            if ( ! $existing ) $existing = wp_insert_term( $term_name, $tax );
                                            
                                            $term_id_to_add = 0;
                                            if ( is_array( $existing ) && isset( $existing['term_id'] ) ) {
                                                $term_id_to_add = (int) $existing['term_id'];
                                            } elseif ( is_numeric( $existing ) ) {
                                                $term_id_to_add = (int) $existing;
                                            }
                                            if ( $term_id_to_add > 0 ) $terms_to_assign[ $tax ][] = $term_id_to_add;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. Auto-Detect Type
                if ( taxonomy_exists( 'layout_type' ) ) {
                    $detect_type = '';
                    if ( strpos( $content, 'wp:divi/section' ) !== false ) $detect_type = 'section';
                    elseif ( strpos( $content, 'wp:divi/row' ) !== false ) $detect_type = 'row';
                    elseif ( strpos( $content, 'wp:divi/layout' ) !== false ) $detect_type = 'layout';
                    elseif ( strpos( $content, 'wp:divi/' ) !== false ) $detect_type = 'module';

                    if ( ! empty( $detect_type ) ) {
                        $existing = term_exists( $detect_type, 'layout_type' );
                        if ( ! $existing ) {
                            $existing = wp_insert_term( ucfirst( $detect_type ), 'layout_type', array( 'slug' => $detect_type ) );
                        }
                        
                        $term_id_to_add = 0;
                        if ( is_array( $existing ) && isset( $existing['term_id'] ) ) {
                            $term_id_to_add = (int) $existing['term_id'];
                        } elseif ( is_numeric( $existing ) ) {
                            $term_id_to_add = (int) $existing;
                        }
                        if ( $term_id_to_add > 0 ) $terms_to_assign['layout_type'][] = $term_id_to_add;
                    }
                }

                // Assign terms
                foreach ( $terms_to_assign as $tax => $term_ids ) {
                    if ( ! empty( $term_ids ) ) {
                        $ids = array_unique( $term_ids );
                        if ( $tax === 'layout_type' ) $ids = array( end( $ids ) );
                        wp_set_object_terms( $post_id, $ids, $tax );
                    }
                }

                if ( isset( $_FILES['thumbnail'] ) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK ) {
                    require_once( ABSPATH . 'wp-admin/includes/image.php' );
                    require_once( ABSPATH . 'wp-admin/includes/file.php' );
                    require_once( ABSPATH . 'wp-admin/includes/media.php' );
                    $attachment_id = media_handle_upload( 'thumbnail', $post_id );
                    if ( ! is_wp_error( $attachment_id ) ) set_post_thumbnail( $post_id, $attachment_id );
                }
                
                $imported_count++;
            }
        }

        if ( $imported_count > 0 ) {
            wp_send_json_success( array( 'message' => sprintf( __( 'Successfully imported %d layout(s).', 'divi5-tm' ), $imported_count ) ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'Failed to import layouts.', 'divi5-tm' ) ) );
        }
    }
}
