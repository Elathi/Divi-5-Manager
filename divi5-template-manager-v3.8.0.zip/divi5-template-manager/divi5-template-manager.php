<?php
/**
 * Plugin Name:       Divi 5 Template Manager
 * Plugin URI:        https://divi.elathi.xyz
 * Description:       A professional asset library to browse, manage, preview, import, and export Divi 5 layouts and templates.
 * Version:           3.8.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Tested up to:      6.7
 * Stable tag:        3.8.0
 * Author:            S. Anand Kumar
 * Author URI:        https://elathi.xyz
 * License:           GPL-2.0+
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       divi5-tm
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

define( 'DIVI5_TM_VERSION', '3.8.0' );
define( 'DIVI5_TM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'DIVI5_TM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Include necessary files
require_once DIVI5_TM_PLUGIN_DIR . 'includes/class-layout-manager.php';
require_once DIVI5_TM_PLUGIN_DIR . 'includes/class-import-handler.php';
require_once DIVI5_TM_PLUGIN_DIR . 'includes/class-skeleton-generator.php';

class Divi5_Template_Manager {

    private static $instance = null;
    public $layout_manager;
    public $import_handler;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->layout_manager = new D5TM_Layout_Manager();
        $this->import_handler = new D5TM_Import_Handler();

        add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
        add_action( 'wp_ajax_d5tm_get_layout_data', array( $this, 'ajax_get_layout_data' ) );
        add_action( 'wp_ajax_d5tm_quick_edit_layout', array( $this, 'ajax_quick_edit_layout' ) );
        add_action( 'wp_ajax_d5tm_download_layout', array( $this, 'ajax_download_layout' ) );
        add_action( 'wp_ajax_d5tm_trash_layout', array( $this, 'ajax_trash_layout' ) );
        add_action( 'wp_ajax_d5tm_restore_layout', array( $this, 'ajax_restore_layout' ) );
        add_action( 'wp_ajax_d5tm_delete_layout', array( $this, 'ajax_delete_layout' ) );
        add_action( 'wp_ajax_d5tm_update_term_color', array( $this, 'ajax_update_term_color' ) );
        add_action( 'wp_ajax_d5tm_delete_empty_cats', array( $this, 'ajax_delete_empty_cats' ) );
        add_action( 'wp_ajax_d5tm_toggle_favorite', array( $this, 'ajax_toggle_favorite' ) );

        // v3.7 Health Check add_action( 'wp_ajax_d5tm_toggle_favorite', array( $this, 'ajax_toggle_favorite' ) ); Bulk Rename
        add_action( 'wp_ajax_d5tm_health_check', array( $this, 'ajax_health_check' ) );
        add_action( 'wp_ajax_d5tm_bulk_rename', array( $this, 'ajax_bulk_rename' ) );

        // v3.0 Batch Editor Hooks
        add_action( 'wp_ajax_d5tm_batch_update', array( $this, 'ajax_batch_update' ) );
        add_action( 'wp_ajax_d5tm_batch_trash', array( $this, 'ajax_batch_trash' ) );
        add_action( 'wp_ajax_d5tm_duplicate_layout', array( $this, 'ajax_duplicate_layout' ) );
        add_action( 'wp_ajax_d5tm_bulk_export', array( $this, 'ajax_bulk_export' ) );
        add_action( 'wp_ajax_d5tm_get_stats', array( $this, 'ajax_get_stats' ) );

        // Ensure Taxonomies exist (Fail-safe for AJAX)
        add_action( 'init', array( $this, 'ensure_taxonomies' ), 5 );

        // Performance: Clear transients when layouts change
        add_action( 'save_post_et_pb_layout', array( $this, 'clear_layout_transients' ) );
        add_action( 'delete_post', array( $this, 'clear_layout_transients' ) );
        add_action( 'trashed_post', array( $this, 'clear_layout_transients' ) );
        add_action( 'untrashed_post', array( $this, 'clear_layout_transients' ) );
        add_action( 'created_layout_category', array( $this, 'clear_layout_transients' ) );
        add_action( 'edited_layout_category', array( $this, 'clear_layout_transients' ) );
        add_action( 'delete_layout_category', array( $this, 'clear_layout_transients' ) );
        add_action( 'created_layout_tag', array( $this, 'clear_layout_transients' ) );
        add_action( 'edited_layout_tag', array( $this, 'clear_layout_transients' ) );
        add_action( 'delete_layout_tag', array( $this, 'clear_layout_transients' ) );
    }

    /**
     * Helper to get icon for layout type
     */
    public static function get_type_icon( $type_name ) {
        $type_name = strtolower( (string) $type_name );
        switch ( $type_name ) {
            case 'section': return 'bi-view-stacked';
            case 'row':     return 'bi-distribute-horizontal';
            case 'module':  return 'bi-box-seam';
            case 'layout':  return 'bi-file-earmark-richtext';
            default:        return 'bi-layers';
        }
    }

    public function ensure_taxonomies() {
        $taxonomies = array(
            'layout_category' => 'Layout Categories',
            'layout_tag'      => 'Layout Tags',
            'layout_type'     => 'Layout Types',
        );

        foreach ( $taxonomies as $tax => $label ) {
            if ( ! taxonomy_exists( $tax ) ) {
                register_taxonomy( $tax, 'et_pb_layout', array(
                    'labels'            => array( 'name' => $label ),
                    'hierarchical'      => ( $tax === 'layout_category' ),
                    'show_ui'           => true,
                    'show_admin_column' => true,
                    'query_var'         => true,
                    'rewrite'           => array( 'slug' => $tax ),
                ) );
            }
        }
    }

    /**
     * Bulk Update: Assign Term to multiple layouts
     */
    public function ajax_batch_update() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_send_json_error( array( 'message' => 'Permission denied.' ) );

        $ids     = isset( $_POST['ids'] ) ? array_map( 'intval', $_POST['ids'] ) : array();
        $term_id = isset( $_POST['term_id'] ) ? intval( $_POST['term_id'] ) : 0;
        $tax     = isset( $_POST['tax'] ) ? sanitize_text_field( $_POST['tax'] ) : 'layout_category';

        // Security: Whitelist allowed taxonomies
        $allowed_taxes = array( 'layout_category', 'layout_tag' );
        if ( ! in_array( $tax, $allowed_taxes, true ) ) {
            wp_send_json_error( array( 'message' => 'Invalid taxonomy.' ) );
        }

        if ( empty( $ids ) || ! $term_id ) {
            wp_send_json_error( array( 'message' => 'Invalid data.' ) );
        }

        foreach ( $ids as $id ) {
            wp_set_object_terms( $id, array( $term_id ), $tax, true ); // true = append
        }

        wp_send_json_success( array( 'message' => 'Batch update complete.' ) );
    }

    /**
     * Bulk Trash: Move multiple layouts to trash
     */
    public function ajax_batch_trash() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'delete_posts' ) ) wp_send_json_error( array( 'message' => 'Permission denied.' ) );

        $ids = isset( $_POST['ids'] ) ? array_map( 'intval', $_POST['ids'] ) : array();

        if ( empty( $ids ) ) {
            wp_send_json_error( array( 'message' => 'No items selected.' ) );
        }

        foreach ( $ids as $id ) {
            wp_trash_post( $id );
        }

        wp_send_json_success( array( 'message' => 'Items moved to trash.' ) );
    }

    public function ajax_get_layout_data() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ) );
        }
        
        $layout_id = isset( $_POST['layout_id'] ) ? intval( $_POST['layout_id'] ) : 0;
        if ( ! $layout_id ) {
            wp_send_json_error( array( 'message' => 'Invalid layout ID.' ) );
        }

        $post = get_post( $layout_id );
        if ( ! $post || $post->post_type !== 'et_pb_layout' ) {
            wp_send_json_error( array( 'message' => 'Layout not found.' ) );
        }

        // Divi 5 relies on Gutenberg-like Block structures.
        // We just need the raw block markup text. 
        $raw_content = $post->post_content;

        // Gather terms in standard Divi format
        $terms_data = array();
        $taxonomies = array( 'layout_category', 'layout_tag', 'layout_type' );
        foreach ( $taxonomies as $tax ) {
            $terms = get_the_terms( $layout_id, $tax );
            if ( $terms && ! is_wp_error( $terms ) ) {
                foreach ( $terms as $term ) {
                    $terms_data[ $term->term_id ] = array(
                        'term_id'          => $term->term_id,
                        'name'             => $term->name,
                        'slug'             => $term->slug,
                        'term_group'       => $term->term_group,
                        'term_taxonomy_id' => $term->term_taxonomy_id,
                        'taxonomy'         => $term->taxonomy,
                        'description'      => $term->description,
                        'parent'           => $term->parent,
                        'count'            => $term->count,
                        'filter'           => $term->filter,
                    );
                }
            }
        }

        // Gather post meta
        $raw_meta = get_post_meta( $layout_id );
        $meta_data = array();
        foreach ( $raw_meta as $key => $values ) {
            // Unserialize if needed, though get_post_meta with false usually does it or returns array
            $meta_data[ $key ] = maybe_unserialize( $values[0] );
        }

        // Package as Divi JSON structure - exact match for export format
        $json_export = array(
            'context' => 'et_builder_layouts',
            'data'    => array(
                $layout_id => array(
                    'ID'           => $layout_id,
                    'post_title'   => $post->post_title,
                    'post_content' => $post->post_content,
                    'post_excerpt' => $post->post_excerpt,
                    'post_name'    => $post->post_name,
                    'post_date'    => $post->post_date,
                    'post_status'  => 'publish',
                    'post_type'    => 'et_pb_layout',
                    'guid'         => $post->guid,
                    'menu_order'   => $post->menu_order,
                    'post_meta'    => $meta_data,
                    'terms'        => $terms_data
                )
            )
        );

        wp_send_json_success( array( 
            'layout_data' => wp_json_encode( $json_export, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ),
            'message'     => 'Success' 
        ) );
    }

    public function ajax_download_layout() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) { wp_send_json_error( array( 'message' => 'Permission denied.' ) ); }

        $layout_id = isset( $_POST['layout_id'] ) ? intval( $_POST['layout_id'] ) : 0;
        $post = get_post( $layout_id );
        
        if ( ! $post || $post->post_type !== 'et_pb_layout' ) {
            wp_send_json_error( array( 'message' => 'Layout not found.' ) );
        }

        // Package as Divi JSON
        $json_export = array(
            'context' => 'et_builder_layouts',
            'data'    => array(
                $post->ID => array(
                    'post_title'   => $post->post_title,
                    'post_content' => $post->post_content,
                    'post_status'  => 'publish',
                    'post_type'    => 'et_pb_layout'
                )
            )
        );

        wp_send_json_success( array(
            'filename' => sanitize_title( $post->post_title ) . '.json',
            'json'     => wp_json_encode( $json_export )
        ) );
    }

    public function ajax_trash_layout() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'delete_posts' ) ) { wp_send_json_error( array( 'message' => 'Permission denied.' ) ); }

        $layout_id = isset( $_POST['layout_id'] ) ? intval( $_POST['layout_id'] ) : 0;
        $trashed = wp_trash_post( $layout_id );
        if ( $trashed ) {
            wp_send_json_success( array( 'message' => 'Moved to trash' ) );
        }
        wp_send_json_error( array( 'message' => 'Failed to trash layout' ) );
    }

    public function ajax_restore_layout() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) { wp_send_json_error( array( 'message' => 'Permission denied.' ) ); }

        $layout_id = isset( $_POST['layout_id'] ) ? intval( $_POST['layout_id'] ) : 0;
        $restored = wp_untrash_post( $layout_id );
        if ( $restored ) {
            wp_send_json_success( array( 'message' => 'Restored successfully' ) );
        }
        wp_send_json_error( array( 'message' => 'Failed to restore layout' ) );
    }

    public function ajax_delete_layout() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'delete_posts' ) ) { wp_send_json_error( array( 'message' => 'Permission denied.' ) ); }

        $layout_id = isset( $_POST['layout_id'] ) ? intval( $_POST['layout_id'] ) : 0;
        $deleted = wp_delete_post( $layout_id, true ); // true = force delete
        if ( $deleted ) {
            wp_send_json_success( array( 'message' => 'Deleted permanently' ) );
        }
        wp_send_json_error( array( 'message' => 'Failed to delete layout' ) );
    }

    public function ajax_quick_edit_layout() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ) );
        }

        $layout_id = isset( $_POST['layout_id'] ) ? intval( $_POST['layout_id'] ) : 0;
        if ( ! $layout_id || ! current_user_can( 'edit_post', $layout_id ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied or invalid layout ID.' ) );
        }

        $post_title  = isset( $_POST['post_title'] ) ? sanitize_text_field( $_POST['post_title'] ) : '';
        $post_status = isset( $_POST['post_status'] ) ? sanitize_text_field( $_POST['post_status'] ) : 'publish';
        $thumbnail_id= isset( $_POST['thumbnail_id'] ) ? intval( $_POST['thumbnail_id'] ) : 0;
        
        // Update basic post data
        $post_data = array(
            'ID'          => $layout_id,
            'post_status' => $post_status,
        );
        if ( ! empty( $post_title ) ) {
            $post_data['post_title'] = $post_title;
        }

        wp_update_post( $post_data );

        // Update Thumbnail
        if ( $thumbnail_id > 0 ) {
            set_post_thumbnail( $layout_id, $thumbnail_id );
        } elseif ( $thumbnail_id === -1 ) {
            delete_post_thumbnail( $layout_id );
        }

        // Update Categories
        if ( isset( $_POST['layout_categories'] ) && is_array( $_POST['layout_categories'] ) ) {
            $cats = array_map( 'intval', $_POST['layout_categories'] );
            wp_set_object_terms( $layout_id, $cats, 'layout_category' );
        } else {
            wp_set_object_terms( $layout_id, array(), 'layout_category' );
        }

        // Update Tags
        if ( isset( $_POST['layout_tags'] ) ) {
            $tags = sanitize_text_field( $_POST['layout_tags'] );
            wp_set_object_terms( $layout_id, $tags, 'layout_tag' );
        }

        wp_send_json_success( array( 'message' => 'Layout updated successfully.' ) );
    }
    public function ajax_update_term_color() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
        }

        $term_id = isset( $_POST['term_id'] ) ? intval( $_POST['term_id'] ) : 0;
        $color   = isset( $_POST['color'] ) ? sanitize_hex_color( $_POST['color'] ) : '';

        if ( ! $term_id || ! $color ) {
            wp_send_json_error( array( 'message' => 'Invalid data.' ) );
        }

        update_term_meta( $term_id, 'd5tm_color', $color );
        wp_send_json_success( array( 'message' => 'Color updated.' ) );
    }

    public function ajax_delete_empty_cats() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
        }

        $deleted = 0;
        foreach ( array( 'layout_category', 'layout_tag' ) as $taxonomy ) {
            $empty_terms = get_terms( array(
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
                'fields'     => 'all',
            ) );
            if ( ! is_wp_error( $empty_terms ) ) {
                foreach ( $empty_terms as $term ) {
                    if ( $term->count === 0 ) {
                        wp_delete_term( $term->term_id, $taxonomy );
                        $deleted++;
                    }
                }
            }
        }

        wp_send_json_success( array(
            'message' => $deleted > 0
                ? sprintf( '%d empty %s deleted.', $deleted, _n( 'term', 'terms', $deleted, 'divi5-tm' ) )
                : 'No empty categories or tags found.',
            'count'   => $deleted,
        ) );
    }

    /**
     * Layout Health Check: Scan layouts for potential issues
     */
    public function ajax_health_check() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ) );
        }

        $results = array(
            'empty_content' => array(),
            'no_category'   => array(),
            'oversized'     => array(),
            'no_type'       => array(),
            'total'         => 0,
            'healthy'       => 0,
        );

        $layouts = get_posts( array(
            'post_type'      => 'et_pb_layout',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'no_found_rows'  => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => true,
        ) );

        $results['total'] = count( $layouts );

        foreach ( $layouts as $layout ) {
            $issues = array();
            $content_len = strlen( $layout->post_content );

            // Check empty content
            if ( empty( trim( $layout->post_content ) ) ) {
                $issues[] = 'empty_content';
                $results['empty_content'][] = array(
                    'id'    => $layout->ID,
                    'title' => $layout->post_title,
                );
            }

            // Check oversized (>1MB)
            if ( $content_len > 1048576 ) {
                $issues[] = 'oversized';
                $results['oversized'][] = array(
                    'id'    => $layout->ID,
                    'title' => $layout->post_title,
                    'size'  => size_format( $content_len ),
                );
            }

            // Check no category
            $cats = get_the_terms( $layout->ID, 'layout_category' );
            if ( ! $cats || is_wp_error( $cats ) || empty( $cats ) ) {
                $issues[] = 'no_category';
                $results['no_category'][] = array(
                    'id'    => $layout->ID,
                    'title' => $layout->post_title,
                );
            }

            // Check no type
            $types = get_the_terms( $layout->ID, 'layout_type' );
            if ( ! $types || is_wp_error( $types ) || empty( $types ) ) {
                $issues[] = 'no_type';
                $results['no_type'][] = array(
                    'id'    => $layout->ID,
                    'title' => $layout->post_title,
                );
            }

            if ( empty( $issues ) ) {
                $results['healthy']++;
            }
        }

        wp_send_json_success( array( 'results' => $results ) );
    }

    /**
     * Bulk Rename: Add prefix/suffix or find-and-replace across selected layouts
     */
    public function ajax_bulk_rename() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ) );
        }

        $ids     = isset( $_POST['ids'] ) ? array_map( 'intval', $_POST['ids'] ) : array();
        $mode    = isset( $_POST['mode'] ) ? sanitize_text_field( $_POST['mode'] ) : 'prefix';
        $value   = isset( $_POST['value'] ) ? sanitize_text_field( $_POST['value'] ) : '';
        $replace = isset( $_POST['replace'] ) ? sanitize_text_field( $_POST['replace'] ) : '';

        if ( empty( $ids ) || empty( $value ) ) {
            wp_send_json_error( array( 'message' => 'Missing required parameters.' ) );
        }

        $renamed = 0;
        foreach ( $ids as $id ) {
            $post = get_post( $id );
            if ( ! $post || $post->post_type !== 'et_pb_layout' ) continue;

            $title = $post->post_title;
            switch ( $mode ) {
                case 'prefix':
                    $title = $value . $title;
                    break;
                case 'suffix':
                    $title = $title . $value;
                    break;
                case 'replace':
                    if ( ! empty( $value ) ) {
                        $title = str_replace( $value, $replace, $title );
                    }
                    break;
            }

            if ( $title !== $post->post_title ) {
                wp_update_post( array(
                    'ID'         => $id,
                    'post_title' => $title,
                ) );
                $renamed++;
            }
        }

        wp_send_json_success( array(
            'message' => sprintf( '%d layout%s renamed.', $renamed, $renamed !== 1 ? 's' : '' ),
            'renamed' => $renamed,
        ) );
    }

    /**
     * Toggle Favorite: Add/remove a layout from favorites
     */
    public function ajax_toggle_favorite() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
        }

        $layout_id = isset( $_POST['layout_id'] ) ? intval( $_POST['layout_id'] ) : 0;
        if ( ! $layout_id ) {
            wp_send_json_error( array( 'message' => 'Invalid layout ID.' ) );
        }

        $current = get_post_meta( $layout_id, 'd5tm_favorite', true );
        $new_val = ( $current === '1' ) ? '0' : '1';
        update_post_meta( $layout_id, 'd5tm_favorite', $new_val );

        wp_send_json_success( array(
            'message'  => $new_val === '1' ? 'Added to favorites' : 'Removed from favorites',
            'favorite' => $new_val === '1',
        ) );
    }

    public function register_admin_menu() {
        add_menu_page(
            __( 'Divi 5 Manager', 'divi5-tm' ),
            __( 'Divi 5 Manager', 'divi5-tm' ),
            'manage_options',
            'divi5-template-manager',
            array( $this, 'render_admin_page' ),
            'dashicons-layout',
            60
        );
    }

    public function enqueue_admin_scripts( $hook ) {
        if ( 'toplevel_page_divi5-template-manager' !== $hook ) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style( 'd5tm-bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css', array(), null );
        wp_enqueue_style( 'd5tm-admin-style', DIVI5_TM_PLUGIN_URL . 'admin/css/admin-style.css', array( 'd5tm-bootstrap-icons' ), DIVI5_TM_VERSION );
        wp_enqueue_script( 'd5tm-admin-script', DIVI5_TM_PLUGIN_URL . 'admin/js/admin-scripts.js', array( 'jquery' ), DIVI5_TM_VERSION, true );
        
        wp_localize_script( 'd5tm-admin-script', 'd5tm_ajax', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'd5tm_import_nonce' )
        ) );
    }

    /**
     * Duplicate/Clone a layout as a new post
     */
    public function ajax_duplicate_layout() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ) );
        }

        $layout_id = isset( $_POST['layout_id'] ) ? intval( $_POST['layout_id'] ) : 0;
        $post = get_post( $layout_id );

        if ( ! $post || $post->post_type !== 'et_pb_layout' ) {
            wp_send_json_error( array( 'message' => 'Layout not found.' ) );
        }

        // Create new post as a copy
        $new_post = array(
            'post_title'  => $post->post_title . ' (Copy)',
            'post_status' => 'publish',
            'post_type'   => 'et_pb_layout',
            'post_content'=> $post->post_content,
            'post_excerpt'=> $post->post_excerpt,
        );

        $new_id = wp_insert_post( $new_post );

        if ( is_wp_error( $new_id ) ) {
            wp_send_json_error( array( 'message' => 'Failed to duplicate layout.' ) );
        }

        // Copy post meta
        $meta_keys = get_post_custom_keys( $layout_id );
        if ( $meta_keys ) {
            // Whitelist of allowed meta keys for security
            $allowed_meta = array(
                '_et_pb_built_for_post_type',
                '_et_pb_layout_type',
                '_et_pb_template_type',
                '_et_pb_module_type',
                '_et_pb_module_is_global',
                '_et_pb_layout_parent',
                '_et_pb_layout_shortcode',
                '_et_pb_old_content',
            );
            foreach ( $meta_keys as $key ) {
                if ( in_array( $key, $allowed_meta, true ) ) {
                    $values = get_post_meta( $layout_id, $key );
                    foreach ( $values as $value ) {
                        add_post_meta( $new_id, $key, maybe_unserialize( $value ) );
                    }
                }
            }
        }

        // Copy taxonomies
        $taxonomies = array( 'layout_category', 'layout_tag', 'layout_type' );
        foreach ( $taxonomies as $tax ) {
            $terms = get_the_terms( $layout_id, $tax );
            if ( $terms && ! is_wp_error( $terms ) ) {
                $term_ids = wp_list_pluck( $terms, 'term_id' );
                wp_set_object_terms( $new_id, $term_ids, $tax );
            }
        }

        // Copy featured image
        $thumb_id = get_post_thumbnail_id( $layout_id );
        if ( $thumb_id ) {
            set_post_thumbnail( $new_id, $thumb_id );
        }

        wp_send_json_success( array(
            'message'   => 'Layout duplicated successfully.',
            'new_id'    => $new_id,
            'new_title' => $post->post_title . ' (Copy)',
        ) );
    }

    /**
     * Bulk Export: Download multiple layouts as a single combined JSON
     */
    public function ajax_bulk_export() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ) );
        }

        $ids = isset( $_POST['ids'] ) ? array_map( 'intval', $_POST['ids'] ) : array();
        if ( empty( $ids ) ) {
            wp_send_json_error( array( 'message' => 'No items selected.' ) );
        }

        $export_data = array(
            'context' => 'et_builder_layouts',
            'data'    => array(),
        );

        foreach ( $ids as $id ) {
            $post = get_post( $id );
            if ( ! $post || $post->post_type !== 'et_pb_layout' ) continue;

            // Gather terms
            $terms_data = array();
            $taxonomies = array( 'layout_category', 'layout_tag', 'layout_type' );
            foreach ( $taxonomies as $tax ) {
                $terms = get_the_terms( $id, $tax );
                if ( $terms && ! is_wp_error( $terms ) ) {
                    foreach ( $terms as $term ) {
                        $terms_data[ $term->term_id ] = array(
                            'term_id'          => $term->term_id,
                            'name'             => $term->name,
                            'slug'             => $term->slug,
                            'term_group'       => $term->term_group,
                            'term_taxonomy_id' => $term->term_taxonomy_id,
                            'taxonomy'         => $term->taxonomy,
                            'description'      => $term->description,
                            'parent'           => $term->parent,
                            'count'            => $term->count,
                            'filter'           => $term->filter,
                        );
                    }
                }
            }

            // Gather post meta
            $raw_meta = get_post_meta( $id );
            $meta_data = array();
            foreach ( $raw_meta as $key => $values ) {
                $meta_data[ $key ] = maybe_unserialize( $values[0] );
            }

            $export_data['data'][ $id ] = array(
                'ID'           => $id,
                'post_title'   => $post->post_title,
                'post_content' => $post->post_content,
                'post_excerpt' => $post->post_excerpt,
                'post_name'    => $post->post_name,
                'post_date'    => $post->post_date,
                'post_status'  => 'publish',
                'post_type'    => 'et_pb_layout',
                'guid'         => $post->guid,
                'menu_order'   => $post->menu_order,
                'post_meta'    => $meta_data,
                'terms'        => $terms_data,
            );
        }

        wp_send_json_success( array(
            'filename' => 'divi5-layouts-export-' . count( $ids ) . '-' . date( 'Y-m-d' ) . '.json',
            'json'     => wp_json_encode( $export_data ),
        ) );
    }

    /**
     * Get layout statistics for the Stats dashboard
     */
    public function ajax_get_stats() {
        check_ajax_referer( 'd5tm_import_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ) );
        }

        $stats_cache = get_transient( 'd5tm_stats' );
        if ( false !== $stats_cache ) {
            wp_send_json_success( array( 'stats' => $stats_cache ) );
            return;
        }

        $stats = array(
            'total'       => 0,
            'published'   => 0,
            'draft'       => 0,
            'trash'       => 0,
            'by_type'     => array(),
            'by_category' => array(),
            'by_month'    => array(),
            'recent'      => array(),
        );

        // Total counts by status
        $statuses = array( 'publish', 'draft', 'trash' );
        foreach ( $statuses as $status ) {
            $query = new WP_Query( array(
                'post_type'      => 'et_pb_layout',
                'post_status'    => $status,
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ) );
            $count = $query->found_posts;
            $stats['total'] += $count;
            $stats[ $status === 'publish' ? 'published' : $status ] = $count;
        }

        // By category
        $categories = get_terms( array(
            'taxonomy'   => 'layout_category',
            'hide_empty' => true,
        ) );
        if ( ! is_wp_error( $categories ) ) {
            foreach ( $categories as $cat ) {
                $stats['by_category'][] = array(
                    'name'  => $cat->name,
                    'count' => $cat->count,
                    'color' => get_term_meta( $cat->term_id, 'd5tm_color', true ) ?: '#6366f1',
                );
            }
        }

        // By type
        $types = get_terms( array(
            'taxonomy'   => 'layout_type',
            'hide_empty' => true,
        ) );
        if ( ! is_wp_error( $types ) ) {
            foreach ( $types as $type ) {
                $stats['by_type'][] = array(
                    'name'  => $type->name,
                    'count' => $type->count,
                    'icon'  => self::get_type_icon( $type->name ),
                );
            }
        }

        // By month (last 6 months)
        for ( $i = 0; $i < 6; $i++ ) {
            $month = date( 'Y-m', strtotime( "-$i months" ) );
            $month_label = date( 'M Y', strtotime( "-$i months" ) );
            $query = new WP_Query( array(
                'post_type'      => 'et_pb_layout',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'date_query'     => array(
                    array(
                        'year'  => date( 'Y', strtotime( "-$i months" ) ),
                        'month' => date( 'n', strtotime( "-$i months" ) ),
                    ),
                ),
                'no_found_rows'  => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ) );
            $stats['by_month'][] = array(
                'month' => $month,
                'label' => $month_label,
                'count' => $query->found_posts,
            );
        }

        // Recent 5 layouts
        $recent = new WP_Query( array(
            'post_type'      => 'et_pb_layout',
            'post_status'    => 'any',
            'posts_per_page' => 5,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ) );
        if ( $recent->have_posts() ) {
            foreach ( $recent->posts as $p ) {
                $stats['recent'][] = array(
                    'id'    => $p->ID,
                    'title' => $p->post_title,
                    'date'  => get_the_date( 'M j, Y', $p->ID ),
                    'status'=> $p->post_status,
                );
            }
        }

        set_transient( 'd5tm_stats', $stats, HOUR_IN_SECONDS );
        wp_send_json_success( array( 'stats' => $stats ) );
    }

    public function render_admin_page() {
        include DIVI5_TM_PLUGIN_DIR . 'admin/views/main-dashboard.php';
    }

    /**
     * Clear layout-related transients when data changes
     */
    public function clear_layout_transients() {
        delete_transient( 'd5tm_sidebar_counts_active' );
        delete_transient( 'd5tm_sidebar_counts_trash' );
        delete_transient( 'd5tm_stats' );
    }
}

// Register default options on activation
register_activation_hook( __FILE__, 'd5tm_activate_defaults' );
function d5tm_activate_defaults() {
    if ( get_option( 'd5tm_low_quality_preview' ) === false ) {
        add_option( 'd5tm_low_quality_preview', 'off' );
    }
}

// Initialize the plugin
add_action( 'plugins_loaded', array( 'Divi5_Template_Manager', 'get_instance' ) );
