<?php
/**
 * Divi 5 Template Manager — Uninstall Script
 *
 * Runs when the plugin is deleted via the WordPress admin.
 * Cleans up all plugin options and term meta.
 *
 * @package Divi5_Template_Manager
 * @version 3.6.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Delete plugin options
$options = array(
    'd5tm_thumbnail_mode',
    'd5tm_skeleton_branding',
    'd5tm_tag_branding',
    'd5tm_show_action_builder',
    'd5tm_skeleton_shimmer',
    'd5tm_show_action_download',
    'd5tm_show_action_quick_edit',
    'd5tm_show_action_trash',
    'd5tm_hide_empty_cats',
);

foreach ( $options as $option ) {
    delete_option( $option );
}

// Delete d5tm_favorite post meta from all layout posts
$layout_ids = get_posts( array(
    'post_type'      => 'et_pb_layout',
    'post_status'    => 'any',
    'posts_per_page' => -1,
    'fields'         => 'ids',
    'no_found_rows'  => true,
    'update_post_meta_cache' => false,
    'update_post_term_cache' => false,
) );

if ( ! empty( $layout_ids ) ) {
    foreach ( $layout_ids as $pid ) {
        delete_post_meta( $pid, 'd5tm_favorite' );
    }
}

// Delete term meta (d5tm_color) from all layout_category and layout_tag terms
$taxonomies = array( 'layout_category', 'layout_tag' );

foreach ( $taxonomies as $taxonomy ) {
    $terms = get_terms( array(
        'taxonomy'   => $taxonomy,
        'hide_empty' => false,
        'fields'     => 'ids',
    ) );

    if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
        foreach ( $terms as $term_id ) {
            delete_term_meta( $term_id, 'd5tm_color' );
        }
    }
}
