<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php
/**
 * Divi 5 Template Manager â€” Changelog
 * Full version history for Divi 5 Template Manager by S. Anand Kumar / Elathi Digital
 */
$d5tm_changelog = array(

    array(
        'version'     => '3.9.0',
        'date'        => '2026-04-19',
        'label'       => 'Major Update',
        'label_class' => 'major',
        'title'       => 'UI Redesign, Design Extract Fix & Bug Fixes',
        'changes'     => array(
            'new' => array(
                'Enhanced Design Extract: Completely rewrote the color and font extraction engine. Colors are now extracted from dynamic key matching (not just hardcoded keys), inline CSS styles, gradient values, and HSL/HSLA formats. Fonts are extracted from Google Fonts URLs, inline font-family declarations, and extended Divi attribute keys. Added new Layout Structure section showing sections, rows, and modules count, and a Spacing & Dimensions section extracting padding, margin, width, and border-radius values.',
                'Settings Page Redesign: Reorganized settings into a logical 5-section flow — General (Thumbnail Display), Appearance (Skeleton Colors + Tag Branding), Card Actions, Performance, and Category Management. Added missing Tag Branding toggle with iOS-style switch UI.',
            ),
            'improved' => array(
                'List View Complete Redesign: Replaced the broken list view CSS with a professional horizontal card layout featuring proper thumbnail alignment, inline metadata pills, right-aligned action buttons, alternating row colors, and responsive wrapping for smaller screens.',
                'Grid View Card Title Visibility: Increased card title font weight to 700 and size to 0.95rem, added a subtle bottom border separator under the title row for better visual hierarchy and readability.',
                'JSON Inspector Default View: Changed the default view from Tree to Table when opening the JSON Inspector, providing a more accessible flat key-value overview as the first impression.',
                'Sidebar Types Count: Added count badges next to each Type in the sidebar filter panel, matching the existing count display for Categories and Tags.',
            ),
            'fixed' => array(
                'Stats Page Showing Zeros: The Stats dashboard was displaying zero for Total Layouts, Published, Drafts, In Trash, and Monthly Activity because WP_Query was called with no_found_rows=true but then used found_posts for the count. Fixed by using count($query->posts) instead.',
                'Refresh Button Layout Shift: The refresh button icon was expanding from 14px to 32px during spin animation, causing adjacent toolbar elements to jump. Fixed by adding fixed dimensions to the button and overriding the spin font-size for the refresh context.',
                'Card Favorite Data Bug: The $is_fav PHP variable was used in the card data-fav attribute before being defined, causing incorrect favorite state on initial page load. Moved the variable definition to before the card markup.',
                'Gallery View Residual Code: Removed all remaining CSS, JS, and documentation references to the deprecated Gallery view mode.',
                'JSON Inspector Chart View: Removed the unused renderJsonChart function and all chart view CSS that was no longer accessible from the UI.',
            ),
            'removed' => array(
                'Gallery View: Completely removed all Gallery view code and references from CSS, JavaScript, changelog, and readme.',
                'JSON Inspector Chart View: Removed the chart view tab, renderer function, and associated CSS from the JSON Inspector.',
            ),
        ),
    ),

    array(
        'version'     => '3.8.0',
        'date'        => '2026-04-18',
        'label'       => 'Major Release',
        'label_class' => 'major',
        'title'       => 'Performance, Health Check & Productivity Features',
        'changes'     => array(
            'new' => array(
                'Layout Health Check: A new heart-pulse icon in the toolbar scans all layouts for potential issues — empty content, missing categories, oversized layouts over 1MB, and orphaned layouts without a type. Results are displayed in a modal with a health score ring, color-coded categories, and clickable layout names for quick navigation.',
                'Keyboard Navigation: Use Arrow keys (Up/Down/Left/Right) to browse through visible layout cards with a focused card highlight. Press Enter to open the live preview of the focused card. Press Escape to close any open modal. This makes the entire library navigable without a mouse.',
                'Bulk Rename: A new Rename button in the bulk action bar opens a modal with three renaming modes — Add Prefix, Add Suffix, and Find & Replace. Rename dozens of selected layouts in a single operation with instant visual feedback.',
                'Low-Quality Preview Mode: A new settings toggle enables progressive image loading for layout thumbnails. When enabled, thumbnails load at WordPress medium size with a CSS blur effect, then progressively upgrade to full resolution as they enter the viewport using an IntersectionObserver. This dramatically improves page load speed for libraries with many thumbnail images.',
            ),
            'improved' => array(
                'Sidebar Performance: Replaced the N+1 query pattern (one WP_Query per category + one per tag) with a single efficient batch SQL query that counts all term relationships in one database hit. This reduces 150+ queries to just 1 on libraries with many categories and tags.',
                'Transient Caching: Sidebar category and tag counts are now cached using WordPress transients with a 1-hour TTL. The Stats dashboard is also cached. Caches are automatically invalidated when layouts are created, updated, deleted, trashed, or when categories/tags are modified.',
                'Stats Dashboard Caching: The Stats AJAX endpoint now serves cached results, reducing server load for repeated analytics views.',
            ),
            'fixed' => array(
                'N+1 Sidebar Queries: Each category and tag in the sidebar was executing a separate WP_Query to count its layouts, causing severe database load with many terms. Replaced with a single JOIN query grouped by term_id and taxonomy.',
                'No Cache Invalidation: Layout changes (save, delete, trash, untrash) and taxonomy changes were not clearing cached sidebar counts. Added 10 cache invalidation hooks for all relevant post and taxonomy actions.',
            ),
        ),
    ),

    array(
        'version'     => '3.7.0',
        'date'        => '2026-04-18',
        'label'       => 'Major Release',
        'label_class' => 'major',
        'title'       => 'Multi-View Inspector, Design Extract & UX Overhaul',
        'changes'     => array(
            'new' => array(
                'JSON Inspector Multi-View: The JSON inspector now offers four view modes — Tree, Table, Chart, and Raw — each optimized for a different analysis workflow. Tree shows the interactive hierarchy, Table gives a flat key-value overview with expandable content, Chart visualizes Divi module distribution with a bar chart, and Raw provides syntax-highlighted JSON with line numbers.',
                'Design Extract: A new palette icon on each card opens a Design Inspector that extracts and displays all colors used in the layout as a clickable color palette, all fonts used with preview text, and a module breakdown chart showing the composition of Divi modules.',
                'View Mode Toggle: Two layout views are now available in the toolbar — Grid (default masonry) and List (compact table rows). Preference is saved to localStorage.',
                'Expand Full Content: Long string values in both the JSON Tree and Table views now show a "Show Full" button instead of silently truncating, ensuring the complete post_content and other large fields are always accessible.',
            ),
            'improved' => array(
                'Favorites Button Fix: The favorite/star button on cards was not clickable because the thumb overlay was intercepting pointer events. Fixed by making the overlay pointer-events-transparent except for its child buttons, and promoting the fav-btn to z-index:10.',
                'Card Grid Reflow: Replaced CSS columns masonry with CSS Grid, which properly reflows when cards are hidden by filters — no more gaps after filtering by category.',
                'Sidebar Active Highlight: The selected sidebar filter link now shows a prominent accent-colored left border, accent background, and bold text, making it immediately obvious which filter is active.',
                'JSON Tree Content Limits: Increased MAX_STRING_LEN from 5,000 to 50,000 characters, MAX_DEPTH from 12 to 15, and MAX_CHILDREN from 200 to 500, ensuring even the largest Divi layouts display complete data in the tree view.',
            ),
            'fixed' => array(
                'Favorites Not Clickable: The thumb overlay with backdrop-filter created a stacking context that blocked clicks on the star button. Added pointer-events:none to overlay and promoted fav-btn z-index.',
                'Grid Gaps After Filtering: CSS columns masonry left gaps where hidden cards used to be. Switched to CSS Grid which handles hidden items correctly.',
                'JSON Tree Truncation: The 5,000 character limit was cutting off the most important data — the post_content field. Now shows full content with expand buttons for very large strings.',
            ),
        ),
    ),

    array(
        'version'     => '3.6.0',
        'date'        => '2026-04-18',
        'label'       => 'Major Release',
        'label_class' => 'major',
        'title'       => 'Visual Polish, Favorites & Bug Fixes',
        'changes'     => array(
            'new' => array(
                'Layout Favorites: Star your most-used layouts for quick access. A dedicated Favorites section appears in the sidebar with a live count.',
                'Layout Size Indicator: Each card now displays the approximate content size (e.g. 12 KB, 2 MB) so you can spot heavy templates at a glance.',
                'Animated Gradient Header: A subtle rainbow-accent line flows across the top of the header, adding visual polish without impacting performance.',
                'Card Entry Stagger Animation: Cards now fade in with a gentle staggered cascade on page load for a smoother first impression.',
                'Enhanced Toast Slide-In: Notification toasts now slide in from the right with a spring-physics curve for a more tactile feel.',
                'Stat Card Hover Accents: Hovering over a statistics card reveals a gradient accent bar at the top edge.',
            ),
            'improved' => array(
                'JSON Tree View — Complete Data Rendering: Rewrote the tree builder with proper brace-matching for Divi block attributes, multi-block content expansion, HTML escaping, depth limiting, and long-string truncation. All data now displays correctly in the tree view.',
                'Bulk Select Cancel — Now Functional: The Cancel button in the bottom bulk-action bar was not working due to a missing CSS class. Fixed by binding to both class and ID, and ensuring the handler properly resets all selection state.',
                'Card Selected State: Selected cards in bulk mode now show an indigo glow border for clearer visual feedback.',
                'Import Dropzone: Added a hover state and dragover scaling animation to the import dropzone for better affordance.',
                'Scrollbar Consistency: Unified 5px custom scrollbars across sidebar, content area, and modal bodies.',
            ),
            'fixed' => array(
                'JSON Tree View Truncation: Block attribute regex was using non-greedy matching that stopped at the first closing brace instead of the matching one. Replaced with a balanced-brace parser that correctly captures the full JSON payload.',
                'Bulk Cancel Button: The Cancel button in the bulk action bar had only an ID attribute but no class matching the JS event handler. Added the missing class and rewrote the handler to be more robust.',
                'XSS in Tree View: Long string values containing HTML characters were rendered raw into the DOM. Added HTML escaping via a dedicated escapeHtml() helper function.',
            ),
        ),
    ),

    array(
        'version'     => '3.4.0',
        'date'        => '2026-04-16',
        'label'       => 'Major Release',
        'label_class' => 'major',
        'title'       => 'The Unified Inspector Update',
        'changes'     => array(
            'new' => array(
                'Unified JSON Power-Inspector: A professional, IDE-grade data workspace.',
                'Smart Block Expansion: Decodes and expands Divi 5 blocks into interactive sub-trees.',
                'Tag Hover Reveal: High-density metadata tagging on layout cards.',
            ),
            'improved' => array(
                'Monokai Syntax Highlighting: High-fidelity tree visuals with data type icons.',
                'JSON Search Engine: Real-time key/value filtering with auto-expansion.',
                'Data Depth: Added full transparency for guid, excerpts, and unescaped block contents.',
            ),
            'removed' => array(
                'Deprecated Style Palette feature to streamline core auditing workflows.',
            ),
        ),
    ),

    array(
        'version'     => '3.3.0',
        'date'        => '2026-04-16',
        'label'       => 'Major Re-engineering',
        'label_class' => 'major',
        'title'       => 'Unified JSON Inspector & Data Depth',
        'changes'     => array(
            'new' => array(
                'Unified JSON "Power-Inspector" with Smart Block Expansion.',
                'Monokai-style high-fidelity JSON Tree visuals with data type icons.',
                'JSON Search & Filter: Highlighting keys/values with auto-expand functionality.',
            ),
            'improved' => array(
                'Full Metadata Transparency: JSON inspector now includes post_excerpt, guid, and full block contents.',
            ),
        ),
    ),

    array(
        'version'     => '3.2.7',
        'date'        => '2026-04-16',
        'label'       => 'Refinement',
        'label_class' => 'patch',
        'title'       => 'Style Palette & UI Cleanup',
        'changes'     => array(
            'new' => array(
                'Added Style Palette Explorer: Visual design token auditing from the card footer.',
            ),
            'improved' => array(
                'Cleaned up card metadata: Removed redundant Tags and simplified tooltips (Name-only).',
            ),
        ),
    ),

    array(
        'version'     => '3.2.3',
        'date'        => '2026-04-16',
        'label'       => 'Bug Fix & UI',
        'label_class' => 'patch',
        'title'       => 'Tag Splitting & Trash Restoration',
        'changes'     => array(
            'fixed' => array(
                'Tag Import: Resolved an issue where multiple tags were merged into a single term; they are now correctly split by commas.',
                'Trash Action: Restored functionality of the "Move to Trash" card action button.',
            ),
            'improved' => array(
                'Card Layout: Redesigned the tag display system to show a clean primary tag and a "+X more" indicator with hovering tooltip.',
                'Metadata Styling: Added professional pill styling for all layout metadata on the dashboard.',
            ),
        ),
    ),

    array(
        'version'     => '3.2.2',
        'date'        => '2026-04-16',
        'label'       => 'Security & Fixes',
        'label_class' => 'patch',
        'title'       => 'Security Hardening & Logic Fixes',
        'changes'     => array(
            'new' => array(
                'Metadata Whitelist: Implemented a strict whitelist for post meta during import to block arbitrary meta injection.',
            ),
            'improved' => array(
                'Permission Hardening: Enforcement of stricter capability checks (delete_posts vs edit_posts) and per-post access control for quick edits.',
                'Import Security: Removed insecure unserialization of untrusted data from JSON imports.',
                'Quick Edit UX: Improved thumbnail handling with clearer "No Preview" states and better image sanitization.',
            ),
            'fixed' => array(
                'Duplicate Modals: Resolved a markup issue where the JSON inspector modal was being defined twice in the dashboard.',
            ),
        ),
    ),

    array(
        'version'     => '3.2.1',
        'date'        => '2026-04-16',
        'label'       => 'Production Sync',
        'label_class' => 'patch',
        'title'       => 'Documentation & Versioning Sync',
        'changes'     => array(
            'improved' => array(
                'Changelog Consistency: Synchronized version history across readme.txt and the internal dashboard.',
                'Versioning: Plugin version bumped to 3.2.1 for production readiness.',
            ),
        ),
    ),
    
    array(
        'version'     => '3.1.5',
        'date'        => '2026-04-14',
        'label'       => 'Maintenance',
        'label_class' => 'patch',
        'title'       => 'Internal Refinement & Gap Correction',
        'changes'     => array(
            'fixed' => array(
                'In-between Correction: Resolved minor alignment issues in the skeleton previews found during the 3.1.x sprint.',
                'Logic Sweep: General stability improvements to the AJAX import handler.',
            ),
        ),
    ),

    array(
        'version'     => '3.2.0',
        'date'        => '2026-04-15',
        'label'       => 'Performance & Clean UI',
        'label_class' => 'feature',
        'title'       => 'Removing Redundancy & Modernizing Control',
        'changes'     => array(
            'new' => array(
                'Shimmer Control: Added a user-controlled toggle for the skeleton loading shimmer animation in the settings panel.',
            ),
            'improved' => array(
                'JSON Structure Accuracy: Refined the inspector to display the exact, raw layout data structure used for file exports.',
                'Bulk Action Pill: Redesigned the bulk action bar as a floating, centered pill for better ergonomics.',
                'Global Consistency: Standardized button padding and spacing across the entire dashboard.',
            ),
            'fixed' => array(
                'Audit Removal: Completely removed the unreliable Layout Usage Audit feature to improve system performance.',
                'Selection Logic: Resolved minor bugs in the layout bulk selection and interaction flow.',
            ),
        ),
    ),

    array(
        'version'     => '3.1.4',
        'date'        => '2026-04-14',
        'label'       => 'UI Hotfix',
        'label_class' => 'fix',
        'title'       => 'Cleanup of Redundant Elements',
        'changes'     => array(
            'fix' => array(
                'Duplicate Bar: Removed the legacy bulk action code that was causing a second, misaligned bar to appear at the top of the browser view.',
            ),
        ),
    ),

    array(
        'version'     => '3.1.3',
        'date'        => '2026-04-14',
        'label'       => 'UI Hotfix',
        'label_class' => 'fix',
        'title'       => 'Bulk Bar Polish & Shimmer Fix',
        'changes'     => array(
            'improved' => array(
                'Centering & Alignment: The bulk action drawer is now anchored middle-center with a solid, high-contrast background.',
                'Button Padding: Restored comfortable click-targets for Assign, Trash, and Cancel buttons.',
            ),
            'fix' => array(
                'Shimmer Visibility: Fixed a logic race condition where the shimmering animation would persist even when disabled in settings.',
            ),
        ),
    ),

    array(
        'version'     => '3.1.2',
        'date'        => '2026-04-14',
        'label'       => 'Settings & Logic Patch',
        'label_class' => 'fix',
        'title'       => 'Dynamic Taxonomies & UI Shimmer Option',
        'changes'     => array(
            'new' => array(
                'Added a new setting to toggle the Shimmering Animation on Skeleton Preview cards, returning control to the user over dashboard CSS animations.',
            ),
            'fix' => array(
                'Fixed a bug where newly imported categories (like Testimonials) and tags were completely hidden from the sidebar due to relying on WordPress\'s cached core taxonomy counts, which often ignore backend layout imports.',
            ),
        ),
    ),

    array(
        'version'     => '3.1.1',
        'date'        => '2026-04-14',
        'label'       => 'UI Polish & Hotfix',
        'label_class' => 'fix',
        'title'       => 'Selection & Modal Fixes',
        'changes'     => array(
            'improved' => array(
                'Redesigned the card Bulk Select Checkbox with a modern SVG-powered aesthetic, overriding old Windows-native inputs.',
                'Added glassmorphic dark-ghost styling to the Bulk Action Bar buttons to perfectly match the sleek bottom drawer.',
            ),
            'fix' => array(
                'Fixed an issue where the Quick Preview live-iframe click interaction failed to trigger.',
                'Fixed CSS text-overflow where layout names were being pushed out of the bounds of the card.',
                'Resolved a critical PHP syntax bug in main-dashboard.php that occurred during the layout reconstruction.',
            ),
        ),
    ),

    array(
        'version'     => '3.1.0',
        'date'        => '2026-04-14',
        'label'       => 'High-Fidelity Redesign',
        'label_class' => 'feature',
        'title'       => 'Visual Overhaul & Site-Wide Auditing',
        'changes'     => array(
            'new' => array(
                'Comprehensive Usage Audit Tab: A new top-level view to track every layout across the entire site in a clean table.',
                'Centered Hover Preview: Refined the thumbnail hover state to feature a single, large centered eye icon.',
                'High-Priority Icon Row: Moved JSON, Usage, Download, Edit, and Trash actions to the card footer for better accessibility.',
                'Monochrome Pill Metadata: Simplified tags and categories into clean, professional monochrome labels.',
            ),
            'improved' => array(
                'Card redesign to match high-fidelity marketplace standards.',
                'Bulk Action Bar styling updated with 1:1 match to professional design specs.',
            ),
        ),
    ),

    array(
        'version'     => '3.0.0',
        'date'        => '2026-04-14',
        'label'       => 'Major Release',
        'label_class' => 'feature',
        'title'       => 'Productivity & Insights',
        'changes'     => array(
            'new' => array(
                'Multi-Layout Batch Editor: Select multiple layouts to perform bulk actions like trashing or assigning categories.',
                'Layout Usage Audit: Instantly scan your site to see which pages or posts are using a specific layout.',
                'JSON Structure Inspector: View the raw Divi 5 module tree and block data directly from the dashboard.',
                'Bulk Action Bar: A new floating interface for fast administrative workflows.',
            ),
            'improved' => array(
                'Dashboard card layout optimized for high-density asset management.',
                'Performance improvements in layout metadata retrieval.',
            ),
        ),
    ),

    array(
        'version'     => '2.8.0',
        'date'        => '2026-04-14',
        'label'       => 'Fix & Polish',
        'label_class' => 'fix',
        'title'       => 'Sort Fix, Tag Counts & Settings Polish',
        'changes'     => array(
            'new' => array(
                'Settings: Replaced two separate checkboxes with a single elegant iOS-style toggle switch for Skeleton Color Theme (Gray Monochrome ↔ Category Colors).',
                'Hide WP Footer: The WordPress admin footer is now hidden on the plugin page for a cleaner, more focused interface.',
            ),
            'fixed' => array(
                'Sort Order was broken due to an ID mismatch between the HTML element and the JS handler. Now all four sort modes (A-Z, Z-A, Newest, Oldest) work correctly.',
                'Tag Count in the sidebar always showed 0 — fixed by computing accurate counts directly from et_pb_layout posts instead of the default WordPress term count.',
            ),
            'improved' => array(
                'Settings page now has proper top and bottom padding, reducing the cramped appearance.',
                'Tags in the sidebar now also respect the "Hide empty categories & tags" setting.',
            ),
        ),
    ),

    array(
        'version'     => '2.7.0',
        'date'        => '2026-04-14',
        'label'       => 'Major Update',
        'label_class' => 'feature',
        'title'       => 'UX Polish & Category Management',
        'changes'     => array(
            'new' => array(
                'Skeleton Shimmer: Added a subtle animated light-sweep effect to all skeleton preview cards for a modern, alive feel.',
                'Search Highlighting: Matching text in layout title cards is now highlighted in yellow when using the search box.',
                'Keyboard Shortcuts: Press "/" to instantly focus the search input. Press "Esc" to clear all active filters and search term.',
                'Copy Layout ID: A small clipboard icon now appears on each card on hover, allowing one-click copy of the Layout ID.',
                'Illustrated Empty State: Replaced the plain-text "No layouts found" message with a themed SVG folder illustration.',
                'Category Management Settings: Added a toggle to "Hide Empty Categories & Tags" from the sidebar.',
                'Delete Empty Categories: Added a "Danger Zone" button in settings to permanently remove all unused categories and tags via AJAX.',
            ),
            'improved' => array(
                'Card transitions are now smoother when toggling filters or search.',
            ),
        ),
    ),

    array(
        'version'     => '2.6.0',
        'date'        => '2026-04-14',
        'label'       => 'Refinement',
        'label_class' => 'feature',
        'title'       => 'High-Contrast Monochrome Defaults',
        'changes'     => array(
            'new' => array(
                'High-Contrast Gray Skeletons: Monochrome gray is now the default skeleton theme, featuring a new high-contrast shading engine for better visibility of wireframe structures.',
                'Sidebar Simplification: Removed color pickers for Tags entirely and conditionally hide Category pickers when skeleton branding is disabled.',
                'Refined Shading Engine: Upgraded the SVG generator with smarter light/dark interpolation logic for all color modes.',
            ),
            'improved' => array(
                'Cleaned up sidebar interface to prevent accidental color changes when using the default theme.',
                'Increased contrast for all skeleton preview elements (sections, rows, modules).',
            ),
            'fixed' => array(
                'Fixed "dull gray" issues by implementing a more vibrant, high-contrast base palette for the default view.',
            ),
        ),
    ),

    array(
        'version'     => '2.5.0',
        'date'        => '2026-04-14',
        'label'       => 'Major Update',
        'label_class' => 'feature',
        'title'       => 'Customizable UI & Refined Branding',
        'changes'     => array(
            'new' => array(
                'Added Granular Settings: Users can now toggle "Skeleton Branding" and "Tag Branding" independently.',
                'Added Action Button Visibility Controls: Toggle Open in Builder, Download JSON, Quick Edit, and Trash buttons individually via settings.',
                'Refined Card Visuals: Categories and Tags now have a distinct design. Categories feature folder icons and solid styling; Tags feature tag icons and outlined styling.',
                'Professionalized Settings Layout: Implemented a clean toggle grid for better management of plugin preferences.',
            ),
            'improved' => array(
                'Added neutral gray fallback theme for skeletons when branding is disabled.',
                'Enhanced mobile responsiveness for the settings panel.',
            ),
            'fixed' => array(
                'Corrected variable scoping issues to ensure new settings are applied instantly upon saving.',
            ),
        ),
    ),

    array(
        'version'     => '2.4.0',
        'date'        => '2026-04-14',
        'label'       => 'Major Update',
        'label_class' => 'feature',
        'title'       => 'Visual Branding & Global Portal Tooltips',
        'changes'     => array(
            'new' => array(
                'Implemented "Global Floating Tooltips" (Portal Mode) — tooltips now reside in the document body, ensuring they are never clipped by sidebars or headers.',
                'Added Category Color Management: Users can now assign custom colors to categories and tags via interactive sidebar pickers.',
                'Introduced "Dynamic Monochrome Skeletons" — skeleton placeholders now automatically generate shades based on the primary category color for better library organization.',
                'Added Automatic Color Assignment logic that gives every new category a professional brand color from a curated palette.',
            ),
            'improved' => array(
                'Global Z-Index audit: Tooltips and modals updated to use a prioritized stacking context (1,000,000+) to prevent layering issues with sticky headers.',
                'Added real-time UI feedback for category colors: folder icons in the sidebar update instantly when a new color is selected.',
            ),
            'fixed' => array(
                'Resolved an issue where tooltips were occasionally cut off by restricted `overflow` settings in the WordPress admin area.',
            ),
        ),
    ),

    array(
        'version'     => '2.3.0',
        'date'        => '2026-04-14',
        'label'       => 'Enhancement',
        'label_class' => 'feature',
        'title'       => 'Grid Controls & Deep Data Import',
        'changes'     => array(
            'new' => array(
                'Added a dedicated Feature Guide & Help lightbox accessible via the question mark icon in the header.',
                'Added Grid Column Adjuster to the toolbar (Auto, 1, 2, 3, 4, or 5 columns). Setting is remembered across sessions.',
                'Replaced the simple Sort toggle button with a clean Dropdown menu select for better UX.',
                'Added formal Readme.txt and LICENSE for WordPress repository compliance.',
            ),
            'improved' => array(
                'Import Handler now perfectly preserves `post_meta` data (which natively handles the layout `Type`, built-for flags, and template flags in Divi 5).',
                'Taxonomy importer enhanced to support `layout_type`, `scope`, and `module_width` terms directly out of the imported JSON.',
                'Search box styling fixed so that the new Bootstrap search icon sits perfectly aligned without disrupting the input field.',
                'Logo grid icon changed to solid white so it pops properly against the purple accent background.',
            ),
            'fixed' => array(
                '"Type" column showing blank (—) on imported layouts has been fixed. Divi will now properly recognize the type (Layout, Section, Row, etc.).',
            ),
        ),
    ),

    array(
        'version'     => '2.2.0',
        'date'        => '2026-04-14',
        'label'       => 'Feature',
        'label_class' => 'feature',
        'title'       => 'Modern Icon System â€” Phosphor Icons',
        'changes'     => array(
            'new' => array(
                'Replaced all WordPress Dashicons with Phosphor Icons â€” a modern, MIT-licensed open-source icon set with clean strokes and a consistent design language.',
                'Enqueues @phosphor-icons/web@2.1.0 from jsDelivr CDN with no additional plugin files required.',
                'Spinner animation added for the Live Preview loader (replaced the Dashicons spin hack).',
                'Sun/Moon theme toggle icon now updates dynamically using the ph-sun / ph-moon classes.',
            ),
            'improved' => array(
                'Tab nav icons updated: Browse (browser), Import (upload-simple), Settings (sliders), Changelog (clock-counter-clockwise).',
                'Card action icons updated: Eye (eye), Builder (pencil-ruler), Download (download-simple), Quick Edit (pencil-simple), Trash (trash), Restore (arrow-u-up-left).',
                'Sidebar: category uses ph-folder, tags use ph-tag for better semantic clarity.',
                'Live Preview modal: desktop/tablet/mobile device buttons now use ph-monitor / ph-device-tablet / ph-device-mobile.',
                'Changelog labels use ph-plus (New), ph-arrow-up (Improved), ph-check-circle (Fixed).',
                'Added scoped CSS size overrides so all icons render at the correct size per context without affecting the WordPress admin globally.',
            ),
            'fixed' => array(),
        ),
    ),

    array(
        'version'     => '2.1.0',
        'date'        => '2026-04-14',
        'label'       => 'Patch',
        'label_class' => 'patch',
        'title'       => 'Hover Preview Fixes â€” Eye Icon & White Gap',
        'changes'     => array(
            'fixed' => array(
                'Eye icon (ðŸ‘ Live Preview button) was hidden when hover preview was active â€” fixed by setting z-index:2 on the overlay, placing it correctly above the iframe layer (z-index:1).',
                'White gap appearing at the bottom of the hover preview â€” iframe source height was hardcoded to 700px causing a short scaled result. Now calculated dynamically from the actual card height so the scaled iframe always fills 100% of the card.',
                'Preview was only 70% wide â€” removed stale hardcoded scale(0.2) and replaced with a dynamic JS calculation of scale = cardWidth / 1200, ensuring the preview always fills the full card width.',
                'Backdrop-filter blur was fogging the iframe content â€” disabled blur on the overlay (backdrop-filter: none) when live preview is active, keeping the overlay at 25% opacity so the eye button remains visible and usable.',
            ),
            'improved' => array(
                'Removed scroll animation entirely â€” hover preview now shows a clean static snapshot of the layout top, faster and more reliable.',
                'Iframe source height is now computed per-card from outerHeight() so each card renders its preview to exactly the right dimensions.',
                'Cleanup: removed redundant wrap height / min-height JS overrides that were causing layout shifts on mouse-leave.',
            ),
            'new' => array(),
        ),
    ),

    array(
        'version' => '2.0.0',
        'date'    => '2026-04-14',
        'label'   => 'Major Release',
        'label_class' => 'major',
        'title'   => 'Live Hover Preview & Plugin Branding',
        'changes' => array(
            'new'  => array(
                'Added live hover preview â€” hovering a card now lazy-loads a real scaled-down iframe of the layout that auto-scrolls from top to bottom, showing the full layout in context.',
                'Added a clean generic skeleton wireframe placeholder for cards without a custom thumbnail.',
                'Added plugin branding: Plugin URI (divi.elathi.xyz), Author URI (elathi.xyz), Author Name updated to S. Anand Kumar.',
                'Settings page: added "Card Thumbnail Display" toggle â€” choose between Skeleton Preview or Blank Placeholder.',
                'Added Changelog tab to the plugin dashboard (this page).',
            ),
            'improved' => array(
                'Simplified skeleton generator â€” no longer attempts unreliable content parsing; uses a consistent, beautiful generic SVG instead.',
                'Lazy iframe inject: iframes are only created on hover and destroyed on mouse-leave, preserving browser memory.',
                'Skeleton fades out smoothly when live preview activates.',
            ),
            'fixed' => array(),
        ),
    ),

    array(
        'version' => '1.7.0',
        'date'    => '2026-04-14',
        'label'   => 'Feature',
        'label_class' => 'feature',
        'title'   => 'Live Preview Fix & Smart Image Uploader',
        'changes' => array(
            'new' => array(
                'Smart Batch Import: drag-and-drop multiple JSON + image files simultaneously. Files are auto-paired by filename (e.g. Team-1.json + Team-1.jpg) and imported together.',
                'Matched image is automatically uploaded to the WP Media Library and set as the layout featured thumbnail.',
            ),
            'fixed' => array(
                'Live Preview 404 Fix: the preview URL now uses the WordPress native preview system (preview_id, preview_nonce, preview=true) identical to Divi\'s own library â€” no more 404 errors.',
                'Removed custom template_include interceptor that was incorrectly overriding the WordPress query too late.',
                'Fixed: get_permalink() returning false for non-publicly-queryable post types; now constructs the permalink manually from post_name.',
            ),
            'improved' => array(
                'File input now accepts .json, .jpg, .jpeg, .png, .webp simultaneously.',
                'Upload progress shows "Uploading X of Y: filename..." during batch imports.',
            ),
        ),
    ),

    array(
        'version' => '1.6.0',
        'date'    => '2026-04-14',
        'label'   => 'Feature',
        'label_class' => 'feature',
        'title'   => 'Skeleton Previews & Settings Page',
        'changes' => array(
            'new' => array(
                'Skeleton Preview Generator: automatically generates a unique SVG wireframe from each layout\'s Divi 5 block structure.',
                'Settings Page added via new "Settings" header tab â€” control card thumbnail display mode.',
                'Thumbnail Priority system: Custom Image > Skeleton Preview > Blank Placeholder.',
                'First-time attempt at Divi 5 block format parser (wp:divi/ comment blocks).',
            ),
            'improved' => array(
                'Added CSS classes d5tm-thumb--skeleton and d5tm-thumb-skeleton for clean skeleton rendering.',
            ),
            'fixed' => array(),
        ),
    ),

    array(
        'version' => '1.5.0',
        'date'    => '2026-04-14',
        'label'   => 'Feature',
        'label_class' => 'feature',
        'title'   => 'Masonry Grid, Action Icons & Dashboard Refresh',
        'changes' => array(
            'new' => array(
                'Masonry grid layout: cards now use CSS column-width and break-inside: avoid, allowing thumbnails to render at their natural aspect ratios (Pinterest style).',
                'Refresh Dashboard button added to the toolbar â€” forces a full state reload.',
                'Live Preview Modal: full-screen dark-mode iframe with Desktop / Tablet / Mobile responsive toggles.',
                'Trash workflow: Active / Trash tab switcher added to browse bar.',
                'Download JSON: extracts and exports Divi 5 layout blocks as a portable .json file.',
            ),
            'improved' => array(
                'Icon reorganization: Live Preview eye icon moved to card overlay only. Builder, Quick Edit, Download, and Trash actions moved to the card footer bar for cleaner hover states.',
                'All action buttons are icon-only with tooltip title attributes.',
                'Removed Copy Layout option (deprecated).',
            ),
            'fixed' => array(
                'Fixed Quick Edit modal appearing with transparent/broken background.',
                'Fixed WP Media Library opening behind the Quick Edit modal (z-index layering corrected).',
                'Fixed category and tag data not being detected from imported JSON (now reads from terms[] key).',
                'Fixed hover overlay not showing action buttons (blur applied without opacity transition).',
            ),
        ),
    ),

    array(
        'version' => '1.4.0',
        'date'    => '2026-04-13',
        'label'   => 'Feature',
        'label_class' => 'feature',
        'title'   => 'Quick Edit, Trash / Restore & Secure AJAX',
        'changes' => array(
            'new' => array(
                'Quick Edit Modal: edit layout title, status, categories, tags, and set preview thumbnail via WP Media Library.',
                'Move to Trash action with confirmation.',
                'Restore from Trash action.',
                'Permanent Delete action (with confirmation).',
                'Active / Trash tab filtering in the layout grid.',
            ),
            'improved' => array(
                'All AJAX endpoints now use check_ajax_referer() for nonce verification.',
                'All AJAX endpoints check current_user_can("edit_posts") before executing.',
            ),
            'fixed' => array(),
        ),
    ),

    array(
        'version' => '1.3.0',
        'date'    => '2026-04-13',
        'label'   => 'Feature',
        'label_class' => 'feature',
        'title'   => 'Category / Tag Import & Layout Filter',
        'changes' => array(
            'new' => array(
                'Import now reads layout_category and layout_tag taxonomy terms from exported JSON and assigns them automatically.',
                'Sidebar filter panel: browse layouts by Category or Tag.',
                'Search bar added for live text filtering across layout titles, categories, and tags.',
                'Sort Aâ†’Z / Zâ†’A button.',
            ),
            'improved' => array(
                'Import handler refactored to handle nested terms[] JSON key.',
            ),
            'fixed' => array(),
        ),
    ),

    array(
        'version' => '1.0.0',
        'date'    => '2026-04-13',
        'label'   => 'Initial Release',
        'label_class' => 'initial',
        'title'   => 'Initial Release â€” Core Plugin',
        'changes' => array(
            'new' => array(
                'Browse all et_pb_layout post types in a structured card grid.',
                'Import Divi 5 layouts via JSON file drag-and-drop or file picker.',
                'Open layout in Divi Builder directly from a card.',
                'Custom preview thumbnail support via WP Media Library.',
                'Light / Dark mode toggle.',
                'Header count display showing total layouts.',
                'Secure AJAX architecture with nonce verification.',
            ),
            'improved' => array(),
            'fixed'    => array(),
        ),
    ),
);
?>

<div class="d5tm-changelog-wrap">

    <div class="d5tm-changelog-header">
        <div class="d5tm-changelog-title-row">
            <div>
                <h2 data-tooltip="<?php esc_attr_e( 'Chronological history of improvements', 'divi5-tm' ); ?>">
                    <i class="bi bi-clock-history"></i>
                    Changelog
                </h2>
                <p>Full version history of Divi 5 Template Manager</p>
            </div>
            <div class="d5tm-plugin-meta">
                <div class="d5tm-meta-row">
                    <span class="d5tm-meta-label">Current Version</span>
                    <span class="d5tm-version-badge"><?php echo esc_html( DIVI5_TM_VERSION ); ?></span>
                </div>
                <div class="d5tm-meta-row">
                    <span class="d5tm-meta-label">Author</span>
                    <a href="https://elathi.xyz" target="_blank" rel="noopener" class="d5tm-meta-link">S. Anand Kumar</a>
                </div>
                <div class="d5tm-meta-row">
                    <span class="d5tm-meta-label">Plugin Site</span>
                    <a href="https://divi.elathi.xyz" target="_blank" rel="noopener" class="d5tm-meta-link">divi.elathi.xyz</a>
                </div>
            </div>
        </div>
    </div>

    <div class="d5tm-changelog-list">
        <?php foreach ( $d5tm_changelog as $release ) : ?>
        <div class="d5tm-cl-entry<?php echo $release['version'] === DIVI5_TM_VERSION ? ' d5tm-cl-current' : ''; ?>">

            <div class="d5tm-cl-aside">
                <div class="d5tm-cl-version">v<?php echo esc_html( $release['version'] ); ?></div>
                <div class="d5tm-cl-date"><?php echo esc_html( date_format( date_create( $release['date'] ), 'M j, Y' ) ); ?></div>
                <span class="d5tm-cl-label d5tm-cl-label--<?php echo esc_attr( $release['label_class'] ); ?>">
                    <?php echo esc_html( $release['label'] ); ?>
                </span>
                <?php if ( $release['version'] === DIVI5_TM_VERSION ) : ?>
                <span class="d5tm-cl-current-badge">Current</span>
                <?php endif; ?>
            </div>

            <div class="d5tm-cl-body">
                <h3 class="d5tm-cl-title"><?php echo esc_html( $release['title'] ); ?></h3>

                <?php if ( ! empty( $release['changes']['new'] ) ) : ?>
                <div class="d5tm-cl-group">
                    <div class="d5tm-cl-group-label d5tm-cl-new">
                        <i class="bi bi-plus-circle"></i> New
                    </div>
                    <ul>
                        <?php foreach ( $release['changes']['new'] as $item ) : ?>
                        <li><?php echo esc_html( $item ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if ( ! empty( $release['changes']['improved'] ) ) : ?>
                <div class="d5tm-cl-group">
                    <div class="d5tm-cl-group-label d5tm-cl-improved">
                        <i class="bi bi-arrow-up-circle"></i> Improved
                    </div>
                    <ul>
                        <?php foreach ( $release['changes']['improved'] as $item ) : ?>
                        <li><?php echo esc_html( $item ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if ( ! empty( $release['changes']['fixed'] ) ) : ?>
                <div class="d5tm-cl-group">
                    <div class="d5tm-cl-group-label d5tm-cl-fixed">
                        <i class="bi bi-check-circle"></i> Fixed
                    </div>
                    <ul>
                        <?php foreach ( $release['changes']['fixed'] as $item ) : ?>
                        <li><?php echo esc_html( $item ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>

        </div>
        <?php endforeach; ?>
    </div>

    <div class="d5tm-changelog-footer">
        Built by <a href="https://elathi.xyz" target="_blank" rel="noopener">S. Anand Kumar</a> &mdash;
        <a href="https://elathi.xyz" target="_blank" rel="noopener">Elathi Digital</a> &mdash;
        <a href="https://divi.elathi.xyz" target="_blank" rel="noopener">divi.elathi.xyz</a>
    </div>

</div>

<style>
/* Changelog Styles */
.d5tm-changelog-wrap { max-width: 820px; margin: 0 auto; padding: 28px 24px 40px; }
.d5tm-changelog-header { margin-bottom: 28px; padding-bottom: 20px; border-bottom: 1px solid var(--border); }
.d5tm-changelog-title-row { display:flex; justify-content:space-between; align-items:flex-start; gap:20px; flex-wrap:wrap; }
.d5tm-changelog-header h2 { display:flex; align-items:center; gap:8px; font-size:1.25rem; color:var(--text); margin:0 0 5px; }
.d5tm-changelog-header p { color:var(--text-2); font-size:0.85rem; margin:0; }
.d5tm-plugin-meta { display:flex; flex-direction:column; gap:6px; text-align:right; }
.d5tm-meta-row { display:flex; align-items:center; justify-content:flex-end; gap:8px; font-size:0.82rem; }
.d5tm-meta-label { color:var(--text-3); }
.d5tm-meta-link { color:#818cf8; text-decoration:none; }
.d5tm-meta-link:hover { text-decoration:underline; }
.d5tm-version-badge { background:linear-gradient(135deg,#6366f1,#818cf8); color:#fff; font-size:0.75rem; font-weight:700; padding:3px 10px; border-radius:99px; }

/* Entry */
.d5tm-cl-entry { display:flex; gap:24px; padding:22px 0; border-bottom:1px solid var(--border); }
.d5tm-cl-entry:last-child { border-bottom:none; }
.d5tm-cl-current { background:rgba(99,102,241,0.05); margin:0 -12px; padding:22px 12px; border-radius:10px; border-bottom-color:transparent; }

/* Aside */
.d5tm-cl-aside { min-width:110px; max-width:110px; display:flex; flex-direction:column; gap:5px; align-items:flex-start; padding-top:2px; }
.d5tm-cl-version { font-size:1rem; font-weight:700; color:var(--text); font-family:monospace; }
.d5tm-cl-date { font-size:0.72rem; color:var(--text-3); }
.d5tm-cl-label { font-size:0.65rem; font-weight:700; text-transform:uppercase; letter-spacing:.07em; padding:2px 7px; border-radius:4px; margin-top:4px; }
.d5tm-cl-label--major   { background:rgba(99,102,241,0.15); color:#818cf8; }
.d5tm-cl-label--feature { background:rgba(34,197,94,0.12);  color:#22c55e; }
.d5tm-cl-label--patch   { background:rgba(251,191,36,0.12); color:#f59e0b; }
.d5tm-cl-label--initial { background:rgba(156,163,175,0.15);color:#9ca3af; }
.d5tm-cl-current-badge { font-size:0.65rem; font-weight:700; text-transform:uppercase; letter-spacing:.07em; padding:2px 7px; border-radius:4px; background:rgba(99,102,241,0.25); color:#818cf8; margin-top:2px; }

/* Body */
.d5tm-cl-body { flex:1; }
.d5tm-cl-title { font-size:0.95rem; font-weight:600; color:var(--text); margin:0 0 12px; }
.d5tm-cl-group { margin-bottom:10px; }
.d5tm-cl-group-label { font-size:0.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.07em; display:flex; align-items:center; gap:4px; margin-bottom:5px; }
.d5tm-cl-new .dashicons     { color:#22c55e; }
.d5tm-cl-new                { color:#22c55e; }
.d5tm-cl-improved .dashicons{ color:#f59e0b; }
.d5tm-cl-improved           { color:#f59e0b; }
.d5tm-cl-fixed .dashicons   { color:#818cf8; }
.d5tm-cl-fixed              { color:#818cf8; }
.d5tm-cl-group ul { margin:0; padding:0 0 0 16px; list-style:disc; }
.d5tm-cl-group ul li { font-size:0.83rem; color:var(--text-2); line-height:1.55; margin-bottom:3px; }

/* Footer */
.d5tm-changelog-footer { text-align:center; margin-top:24px; font-size:0.8rem; color:var(--text-3); }
.d5tm-changelog-footer a { color:#818cf8; text-decoration:none; }
.d5tm-changelog-footer a:hover { text-decoration:underline; }
</style>

