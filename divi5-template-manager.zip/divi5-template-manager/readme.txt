=== Divi 5 Template Manager ===
Contributors: elathidigital
Tags: divi, divi 5, layout manager, template manager, elathi digital
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 3.9.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A professional asset library to browse, manage, preview, import, and export Divi 5 layouts and templates.

== Description ==

Divi 5 Template Manager is a high-performance, purpose-built asset library designed specifically for the new modular architecture of Divi 5. 

It upgrades the standard WordPress layout interface into a modern, masonry-styled dashboard. It introduces a Live Hover Preview system that renders dynamic, scaled iframe previews of your layouts without touching your live pages, ensuring you always know exactly what you are importing or editing.

### Key Features
*   **Modern Dashboard UI / Dark Mode**: Browse your layouts in a sleek, visually appealing interface that supports automatic dark mode toggling.
*   **Live Iframe Previews**: Hover over any layout card to see a live top-of-fold rendering, perfectly scaled to fit.
*   **Drag & Drop Importer**: Seamlessly import Divi JSON export files directly into the manager. Full deep-data support for importing categories, tags, types, and Divi metadata.
*   **Fully Responsive Masonry Grid**: Choose between Auto, 1, 2, 3, 4, or 5 grid columns directly from the toolbar.
*   **Quick Actions**: Instantly view, edit in Builder, quick edit details, download the raw JSON, or send layouts to the trash.
*   **Skeleton Previews**: Fall back to customizable smart skeleton SVGs when no snapshot is provided.
*   **Layout Health Check**: Scan your library for empty content, missing categories, oversized layouts, and orphaned items.
*   **Keyboard Navigation**: Browse layouts with arrow keys and open previews with Enter.
*   **Bulk Rename**: Prefix, suffix, or find-and-replace across selected layouts.
*   **Progressive Image Loading**: Optional low-quality preview mode with blur-up animation for faster page loads.
*   **Performance Optimized**: Batch SQL queries and transient caching for libraries with 1000+ layouts.

== Installation ==

1. Upload the `divi5-template-manager` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Access the dashboard via the **Divi 5 Manager** menu item in your WordPress admin sidebar.

== Frequently Asked Questions ==

= Does this plugin work with Divi 4? =
It is highly optimized and specifically built to read the JSON structures and metadata signatures produced by the Divi 5 framework. While some Divi 4 layouts may import, it is strictly intended for Divi 5.

= Why are my thumbnails showing skeleton placeholders? =
If you didn't supply a custom thumbnail when saving your layout in the Divi Builder, the plugin will seamlessly fall back to a generic interface skeleton or a live hover preview. You can manage this fallback behavior in the plugin settings.

= Can I mass import layouts? =
Yes. You can drag and drop multiple `.json` format Divi layout files into the Import tab, and the plugin will process them iteratively, preserving their internal categories, tags, and types.

== Screenshots ==

1. **Dashboard** - The main masonry grid showing available layouts with grid-column and sorting controls.
2. **Import Tab** - The drag-and-drop uploader for Divi JSON files.
3. **Settings & Changelog** - In-built controls and an active changelog of latest features.

== Changelog ==

= 3.9.0 =
* New: Enhanced Design Extract — completely rewrote color/font extraction with dynamic key matching, inline CSS parsing, HSL/HSLA support, Google Fonts URL parsing, and new Layout Structure and Spacing & Dimensions sections.
* New: Settings Page Redesign — reorganized into 5 logical sections (General, Appearance, Card Actions, Performance, Category Management) with added Tag Branding toggle.
* Improved: List View completely redesigned with professional horizontal card layout, proper alignment, alternating rows, and responsive wrapping.
* Improved: Grid View card titles now more visible with increased font weight (700) and subtle bottom border separator.
* Improved: JSON Inspector now defaults to Table view instead of Tree view for better first impression.
* Improved: Sidebar Types section now shows count badges like Categories and Tags.
* Fixed: Stats page showing zeros for Total, Published, Drafts, Trash, and Monthly Activity due to WP_Query no_found_rows bug — now uses count($query->posts).
* Fixed: Refresh button causing toolbar layout shift during spin animation — added fixed dimensions and spin font-size override.
* Fixed: Card favorite state bug — $is_fav variable was used before definition, causing incorrect data-fav attribute.
* Removed: Gallery View — completely removed all CSS, JS, and documentation references.
* Removed: JSON Inspector Chart View — removed unused renderer function and CSS.

= 3.8.0 =
* Major New Feature: Layout Health Check — toolbar button scans for empty content, missing categories, oversized layouts, and orphaned layouts with a health score ring.
* Major New Feature: Keyboard Navigation — Arrow keys browse cards, Enter opens preview, Escape closes modals.
* Major New Feature: Bulk Rename — prefix, suffix, or find-and-replace across selected layouts.
* Major New Feature: Low-Quality Preview Mode — progressive blur-up image loading with IntersectionObserver for faster page loads.
* Performance: Eliminated N+1 sidebar queries — replaced per-category and per-tag WP_Query loops with a single batch SQL query.
* Performance: Added transient caching for sidebar counts and stats dashboard (1-hour TTL with automatic invalidation).
* Performance: 10 cache invalidation hooks for layout and taxonomy changes.
* Improved: Stats AJAX endpoint now serves cached results.
* Fixed: N+1 database queries on sidebar load causing severe performance degradation with many categories/tags.
* Fixed: No cache invalidation when layouts or terms were modified.

= 3.7.0 =
* Major New Feature: JSON Inspector Multi-View — Tree, Table, and Raw view modes for complete layout data analysis.
* Major New Feature: Design Extract — palette icon on each card extracts colors, fonts, and module breakdown from any layout.
* New: View Mode Toggle — Grid and List layout views accessible from the toolbar.
* New: Expand Full Content buttons on truncated strings in JSON Tree and Table views.
* Improved: Favorites button now clickable — fixed pointer-events blocking from thumb overlay.
* Improved: Card grid uses CSS Grid instead of CSS columns, eliminating gaps after filtering.
* Improved: Sidebar active filter shows prominent accent-colored left border highlight.
* Improved: JSON Tree content limits increased — MAX_STRING_LEN to 50,000, MAX_DEPTH to 15, MAX_CHILDREN to 500.
* Fixed: Favorites/Star button not clickable due to thumb overlay z-index and pointer-events conflict.
* Fixed: Card grid gaps after filtering by category — CSS Grid properly reflows hidden items.
* Fixed: JSON Tree view truncating post_content and other large fields — now shows full content.

= 3.6.0 =
* Major New Feature: Layout Favorites — star your most-used layouts with a dedicated sidebar section.
* Major New Feature: Layout Size Indicator on each card showing approximate content size.
* New: Animated gradient accent line across the header for visual polish.
* New: Card entry stagger animation for smoother page loads.
* New: Enhanced toast slide-in with spring-physics curve.
* New: Stat card hover gradient accents.
* Improved: JSON Tree View completely rewritten with proper brace-matching, HTML escaping, depth limiting, and long-string truncation for complete data display.
* Improved: Bulk Select Cancel button now functional — fixed missing CSS class and rewrote handler.
* Improved: Selected cards now show indigo glow border for clarity.
* Improved: Import dropzone hover and dragover animations.
* Fixed: JSON Tree View truncation — block attribute regex was using non-greedy matching; replaced with balanced-brace parser.
* Fixed: Bulk Cancel button not working — added missing class and robust handler.
* Fixed: XSS vulnerability in JSON tree view — added HTML escaping.

= 3.4.0 =
* Major New Feature: Unified JSON "Power-Inspector" Workspace.
* Major New Feature: Smart Block Expansion - Decoder for Divi 5 block comments.
* Added: Monokai-style high-fidelity JSON Tree visuals with data type icons.
* Added: JSON Search & Filter with auto-expand on match.
* Added: Tag collection icon on cards with hover-reveal for full tag list.
* Improved: Metadata Transparency - guid, post_excerpt, and deep-block payloads.
* Removed: Legacy Style Palette feature in favor of high-fidelity JSON inspection.

= 3.2.5 =
* Major New Feature: Multi-Level JSON Tree View Inspector (Recursive)
* Major UI Hotfix: Icon-based metadata system (Type icons + Tag icons)
* Added: Sidebar "Filter by Layout Type" support
* Added: Fail-safe Taxonomy registration on init for better import stability
* Fixed: JSON Raw View truncation on complex templates
* Fixed: Layout Type auto-detection logic during AJAX imports

= 3.2.2 =
* Security: Implemented a metadata whitelist during layout import to prevent arbitrary meta injection.
* Security: Hardened the import process by removing potentially unsafe unserialization of untrusted data.
* Security: Tightened permission checks across AJAX handlers, ensuring per-post access control for quick edits and proper capability requirements for bulk actions.
* UI: Removed duplicate markup for the JSON Inspector modal to ensure DOM integrity.
* Enhancement: Improved the Quick Edit thumbnail display logic with better sanitization and a cleaner "No Preview" initial state.

= 3.2.1 =
* Enhancement: Synchronized version history across all documentation files for better developer transparency.
* UI: Minor CSS refinements for the dashboard's responsive grid.

= 3.2.0 =
* Feature: Added user-controlled toggle for shimmer loading animations in settings.
* Enhancement: JSON Structure Inspector now shows raw export-ready data for better debugging.
* Enhancement: Bulk Action Bar redesigned as a floating, centered pill for better visibility.
* Enhancement: Global button padding and dashboard spacing standardized for a premium feel.
* Fix: Removed unreliable "Layout Usage Audit" to improve performance and stability.
* Fix: Resolved selection logic bugs in the bulk management system.

= 3.1.5 =
* Fix: In-between correction for minor skeleton alignment issues found during the 3.1.x sprint.
* Enhancement: General stability sweep of the AJAX import handler.

= 3.1.4 =
* Fix: Cleanup of redundant UI elements and legacy bulk action bar.

= 3.1.3 =
* Fix: Bulk Bar centering and Shimmer persistent visibility fix.

= 3.1.0 =
* Major UI: High-fidelity card redesign to match premium marketplace standards.
* Feature: Monochrome Pill Metadata for a cleaner, professional asset organization.

= 3.0.0 =
* Feature: Multi-Layout Batch Editor for bulk trashing and category assignment.
* Feature: JSON Structure Inspector for auditing Divi 5 module tree.

= 2.7.0 =
* Feature: Introduced Skeleton Shimmer animation and Search Highlighting.
* Feature: Keyboard Shortcuts implemented (Press "/" for search).

= 2.4.0 =
* Feature: Global Floating Tooltips and Category Color Management system.
* Feature: Dynamic Monochrome Skeletons that adapt to category branding.

= 2.3.0 =
* Enhancement: Added Grid Column Adjuster to the toolbar (Auto, 1, 2, 3, 4, or 5 columns). Setting is remembered across sessions.
* Enhancement: Replaced the simple Sort toggle button with a clean Dropdown menu select for better UX.
* Enhancement: Import Handler perfectly preserves `post_meta` data natively.
* Enhancement: Taxonomy importer enhanced to support `layout_type`, `scope`, and `module_width` terms.
* Fix: "Type" natively recognized correctly for imported layouts.

= 2.2.0 =
* Feature: Replaced all WordPress Dashicons with Bootstrap Icons for a modern, sleek aesthetic. Supported by seamless jsDelivr CDN integration.

= 2.1.0 =
* Feature: Implemented a highly optimized `<iframe>` based Live Hover Preview system that intelligently scales its contents to fit card contours.
* Enhancement: Upgraded UI to professional SaaS-grade styling with advanced transitions.

= 1.0.0 =
* Initial Release.
